//
//  AppDelegate.m
//  AD_BL
//
//  Created by 3013 on 14-6-5.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//


//ibtool Main.storyboard --generate-strings-file Localizable.strings
//
//cd /Users/apple/Downloads/InternationalStoryboard/InternationalStoryboard/Base.lproj
//cd /Users/apple/快盘/外包项目一/AD_BL-2/AD_BL/Base.lproj


//NSLog(@"彩要改成英文模式下的判断");
//NSLog(@"白和照明要改成英文模式下的判断");

#import "AppDelegate.h"
#import "ViewController.h"
#import "MeunViewController.h"
#import "MMDrawerController.h"
#import "MMNavigationController.h"
#import "MMExampleDrawerVisualStateManager.h"
#import <QuartzCore/QuartzCore.h>
#import "PopupView.h"
#import "CommentManager.h"

#define TRANSFER_CHARACTERISTIC_UUID_6    @"FFF6"

@interface AppDelegate ()
{
    int m;
    int j;
}
@end
@implementation AppDelegate
@synthesize viewController = _viewController;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    
    
    _viewController = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"ViewControll"];
    _leftMenu = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"menuControll"];
    
    
//    
    
    
    UIViewController * leftSideDrawerViewController = _leftMenu;
    UIViewController * centerViewController = _viewController;
    
    UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:centerViewController];
    [navigationController setRestorationIdentifier:@"MMExampleCenterNavigationControllerRestorationKey"];
    if(IS_IOS_7){
        [leftSideDrawerViewController setRestorationIdentifier:@"MMExampleLeftNavigationControllerRestorationKey"];
        self.drawerController = [[MMDrawerController alloc] initWithCenterViewController:navigationController leftDrawerViewController:leftSideDrawerViewController rightDrawerViewController:nil];
        [self.drawerController setShowsShadow:NO];
    }else{
        self.drawerController = [[MMDrawerController alloc] initWithCenterViewController:navigationController leftDrawerViewController:leftSideDrawerViewController rightDrawerViewController:nil];
    }

    [self.drawerController setRestorationIdentifier:@"MMDrawer"];
    [self.drawerController setMaximumRightDrawerWidth:200.0];
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    [self.drawerController
     setDrawerVisualStateBlock:^(MMDrawerController *drawerController, MMDrawerSide drawerSide, CGFloat percentVisible) {
         MMDrawerControllerDrawerVisualStateBlock block;
         block = [[MMExampleDrawerVisualStateManager sharedManager]
                  drawerVisualStateBlockForDrawerSide:drawerSide];
         if(block){
             block(drawerController, drawerSide, percentVisible);
         }
     }];
    if(IS_IOS_7){
        UIColor * tintColor = [UIColor colorWithRed:29.0/255.0 green:173.0/255.0 blue:234.0/255.0 alpha:1.0];
        [self.window setTintColor:tintColor];
    }
    [self.window setRootViewController:self.drawerController];
    
    
    
    
    [[UINavigationBar appearance] setBackgroundImage:[[UIImage imageNamed:@"top"] stretchableImageWithLeftCapWidth:0 topCapHeight:1] forBarMetrics:UIBarMetricsDefault];
    
    [UINavigationBar appearance].titleTextAttributes = [NSDictionary dictionaryWithObject:[UIColor whiteColor] forKey:UITextAttributeTextColor];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    
   
    
    
#ifdef __IPHONE_8_0
    if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }  else {
        UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:myTypes];
    }
#else
    UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:myTypes];
#endif
    
    
    
//    接收通知参数
    UILocalNotification *notification=[launchOptions valueForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    NSDictionary *userInfo= notification.userInfo;
    if(userInfo)
//        NSLog(@"appdelegate收到userInfo:%@",userInfo);
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            // 处理耗时操作的代码块...
//            while (YES) {
//                [NSThread sleepForTimeInterval:8];
//            }
//        //通知主线程刷新
//        dispatch_async(dispatch_get_main_queue(), ^{
//            //回调或者说是通知主线程刷新，
//        });
    });
    
    return YES;
}
#pragma mark 调用过用户注册通知方法之后执行（也就是调用完registerUserNotificationSettings:方法之后执行）
-(void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings{
    NSLog(@"didRegisterUserNotificationSettings");
    if (notificationSettings.types!=UIUserNotificationTypeNone) {
//        [self addLocalNotification];
    }
}

#pragma mark 进入前台后设置消息信息
-(void)applicationWillEnterForeground:(UIApplication *)application{
    [[UIApplication sharedApplication]setApplicationIconBadgeNumber:0];//进入前台取消应用消息图标
}



#pragma mark 移除本地通知，在不需要此通知时记得移除
-(void)removeNotification{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}
#pragma mark 在后台时，接收本地通知时触发
-(void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
//    当软件正在打开时，收到单次闹钟，应该设置闹钟为关闭
//    NSLog(@"在后台时，接收本地通知时触发");
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:NSLocalizedStringFromTable(@"twenty-EIGHT", @"Localizable", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
    AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"playMusicNotification" object:nil];
    if (notification) {
//        NSDictionary *userInfo =  notification.userInfo;
//        NSString *obj = [userInfo objectForKey:@"user"];
//        NSLog(@"在后台时，接收本地通知时触发:%@",obj);
    }
    
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
//    self.bgTaskId = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
//        [[UIApplication sharedApplication] endBackgroundTask:self.bgTaskId];
//        self.bgTaskId = UIBackgroundTaskInvalid;
//    }];
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
    [NSTimer scheduledTimerWithTimeInterval:60.0f target:self selector:@selector(tik) userInfo:nil repeats:YES];
//    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(updateAction:) userInfo:nil repeats:YES];
}
- (void)tik{
    if ([[UIApplication sharedApplication] backgroundTimeRemaining] < 61.0) {
        [[CommentManager sharedManager] play];
        
        NSLog(@"j = %d", j++);
        [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
    }
}
//- (void)updateAction:(id)sender
//{
//    NSLog(@"i = %d", m++);
//}
- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
@end

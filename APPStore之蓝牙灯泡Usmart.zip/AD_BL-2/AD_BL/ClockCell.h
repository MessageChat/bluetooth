//
//  ClockCell.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/22.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClockCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *AMPMLabel;
@property (weak, nonatomic) IBOutlet UILabel *DetailTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *EventAndTimeLabel;
@property (weak, nonatomic) IBOutlet UISwitch *MySwith;

@end

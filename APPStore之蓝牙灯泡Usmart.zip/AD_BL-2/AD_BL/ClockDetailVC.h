//
//  ClockDetailVC.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/22.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClockDetailVC : UIViewController

@property (weak, nonatomic) IBOutlet UIDatePicker *MyDatePick;
@property (weak, nonatomic) IBOutlet UITableView *MyClockDetailTableView;
@property (strong,nonatomic)NSDictionary *dic;

@property (assign,nonatomic)int typeID;
@property (assign,nonatomic)int row;
- (IBAction)GoBackAction:(id)sender;
- (IBAction)ResaveAction:(id)sender;

@end

//
//  ClockDetailVC.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/22.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "ClockDetailVC.h"
#import "DetailOneCell.h"
#import "LabelViewController.h"

@interface ClockDetailVC ()<LabelTextDelegate>{
    NSMutableArray *dataArray;
    LabelViewController *labelVC;
    int SelectMusicID;
}

@end

@implementation ClockDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    SelectMusicID=0;
    // Do any additional setup after loading the view.
    NSArray *arrayTitle=[[NSArray alloc]initWithObjects:NSLocalizedStringFromTable(@"thirteen", @"Localizable", nil),NSLocalizedStringFromTable(@"fourteen", @"Localizable", nil),NSLocalizedStringFromTable(@"fifteen", @"Localizable", nil), nil];
    NSArray *array =[[NSMutableArray alloc] initWithObjects:@"0",@"0",@"0",@"0",@"0",@"0",@"0",nil];
    NSDictionary *dicTitleOne=[[NSDictionary alloc]initWithObjectsAndKeys:NSLocalizedStringFromTable(@"seventeen", @"Localizable", nil),@"Title",array,@"Data",nil];
    NSDictionary *dicTitleTwo=[[NSDictionary alloc]initWithObjectsAndKeys:NSLocalizedStringFromTable(@"sixteen", @"Localizable", nil),@"Title",nil];
    NSDictionary *dicTitleThree=[[NSDictionary alloc]initWithObjectsAndKeys:@"Music1",@"Title",nil];
    NSArray *dicTitle=[[NSArray alloc]initWithObjects:dicTitleOne,dicTitleTwo,dicTitleThree, nil];
    dataArray=[[NSMutableArray alloc]initWithObjects:arrayTitle,dicTitle, nil];
    
    labelVC=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"detailViewLabel"];
    labelVC.LabelDelegate=self;
    
    NSLog(@"addObserver");
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(GetRepeatDate:) name:@"RepeatNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(change:) name:@"TypeNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(ClockMusicAction:) name:@"ClockMusicNotification" object:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)change:(NSNotification*)notification{
    self.typeID=[[[notification userInfo] objectForKey:@"editType"] intValue];
    self.row=[[[notification userInfo] objectForKey:@"rowNumber"] intValue];
//    NSLog(@"编辑:%d,%d",self.typeID,self.row);
}
-(void)ClockMusicAction:(NSNotification*)notification{
    SelectMusicID=[[[notification userInfo] objectForKey:@"selectMusicID"] intValue];
    NSLog(@"----SelectMusicID:%d",SelectMusicID);
    NSMutableArray *mutablleDic=[[NSMutableArray alloc]initWithArray:[dataArray objectAtIndex:1]];
    NSDictionary *dicTitleTwo=[[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"Music%d",SelectMusicID+1],@"Title",nil];
    NSLog(@"----dicTitleTwo:%@",dicTitleTwo);
    [mutablleDic replaceObjectAtIndex:2 withObject:dicTitleTwo];
    [dataArray replaceObjectAtIndex:1 withObject:mutablleDic];
    [_MyClockDetailTableView reloadData];
}

#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}


-(void)GetRepeatDate:(NSNotification*)notification{
    NSLog(@"GetRepeatDate selectArray:%@",[[notification userInfo] objectForKey:@"selectArray"]);
    NSArray *array=[[notification userInfo] objectForKey:@"selectArray"];
    int j=0;
    NSMutableString *showStr=[[NSMutableString alloc]initWithString:NSLocalizedStringFromTable(@"seventeen", @"Localizable", nil)];
    NSMutableString *tempStr=[[NSMutableString alloc]init];
    for (int i=0; i<[array count]; i++) {
        if ([[array objectAtIndex:i] boolValue]) {
            j++;
            switch (i) {
                case 0:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week1", @"Localizable", nil)];
                    break;
                case 1:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week2", @"Localizable", nil)];
                    break;
                case 2:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week3", @"Localizable", nil)];
                    break;
                case 3:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week4", @"Localizable", nil)];
                    break;
                case 4:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week5", @"Localizable", nil)];
                    break;
                case 5:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week6", @"Localizable", nil)];
                    break;
                case 6:
                    [tempStr appendString:NSLocalizedStringFromTable(@"week7", @"Localizable", nil)];
                    break;
                default:
                    break;
            }
        }
    }
    if (j==7) {
        showStr=[NSMutableString stringWithString:NSLocalizedStringFromTable(@"nineteen", @"Localizable", nil)];
    }else if(j==5&&![[array objectAtIndex:0] boolValue]&&![[array objectAtIndex:6] boolValue]){
        showStr=[NSMutableString stringWithString:NSLocalizedStringFromTable(@"twenty", @"Localizable", nil)];
    }else if(j!=0){
        showStr=tempStr;
    }
    NSMutableArray *mutablleDic=[[NSMutableArray alloc]initWithArray:[dataArray objectAtIndex:1]];
    NSDictionary *dicTitleTwo=[[NSDictionary alloc]initWithObjectsAndKeys:showStr,@"Title",array,@"Data",nil];
    [mutablleDic replaceObjectAtIndex:0 withObject:dicTitleTwo];
    [dataArray replaceObjectAtIndex:1 withObject:mutablleDic];
    [_MyClockDetailTableView reloadData];
}

-(void)getLabelText:(NSString *)labelStr{
//    NSLog(@"收到TEXT:%@",labelStr);
    NSMutableArray *mutablleDic=[[NSMutableArray alloc]initWithArray:[dataArray objectAtIndex:1]];
    NSDictionary *dicTitleTwo=[[NSDictionary alloc]initWithObjectsAndKeys:labelStr,@"Title",nil];
    [mutablleDic replaceObjectAtIndex:1 withObject:dicTitleTwo];
    [dataArray replaceObjectAtIndex:1 withObject:mutablleDic];
    [_MyClockDetailTableView reloadData];
}

- (IBAction)GoBackAction:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)ResaveAction:(id)sender {
    if (self.typeID) {
        NSDate *localeDate=_MyDatePick.date;
        [dataArray addObject:localeDate];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:dataArray,@"selectArray",[NSNumber numberWithInt:self.row],@"row",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ClockEditNotification" object:nil userInfo:dic];
    }else{
        NSDate *localeDate=_MyDatePick.date;
        [dataArray addObject:localeDate];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:dataArray,@"selectArray",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ClockDetailLocationNotification" object:nil userInfo:dic];
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
//改变行的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
//返回TableView中有多少数据
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
    
}
//返回有多少个TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
//组装每一条的数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CustomCellIdentifierOne =@"DetailWithLabel";
    static NSString *CustomCellIdentifierTwo =@"DetailWithLabel";
    UITableViewCell *cell;
    if (indexPath.row<4) {
        cell = [tableView dequeueReusableCellWithIdentifier: CustomCellIdentifierOne];
        if (cell ==nil) {
            cell = [[DetailOneCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CustomCellIdentifierOne];
        }
        ((DetailOneCell*)cell).TitleLabel.text=[[dataArray objectAtIndex:0] objectAtIndex:indexPath.row];
        ((DetailOneCell*)cell).DetailLabel.text=[[[dataArray objectAtIndex:1] objectAtIndex:indexPath.row] objectForKey:@"Title"];
    }else{
        cell = [tableView dequeueReusableCellWithIdentifier: CustomCellIdentifierTwo];
        if (cell ==nil) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CustomCellIdentifierTwo];
        }
    }
    return cell;
}
//选中Cell响应事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row==0) {
        [self performSegueWithIdentifier:@"detailViewRepeat" sender:nil];
    }else if(indexPath.row==1){
        labelVC.LabelStr=[[[dataArray objectAtIndex:1] objectAtIndex:indexPath.row] objectForKey:@"Title"];
        [self.navigationController pushViewController:labelVC animated:YES];
    }else if (indexPath.row==2){
        [self performSegueWithIdentifier:@"SelectMusicView" sender:nil];
    }
}
@end

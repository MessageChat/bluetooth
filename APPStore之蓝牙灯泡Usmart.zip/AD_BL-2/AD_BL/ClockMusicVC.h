//
//  ClockMusicVC.h
//  ADMBL
//
//  Created by 陈双超 on 15/1/12.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ClockMusicVC : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *MyMusicTableView;

@end

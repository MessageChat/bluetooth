//
//  ClockMusicVC.m
//  ADMBL
//
//  Created by 陈双超 on 15/1/12.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//

#import "ClockMusicVC.h"

@interface ClockMusicVC (){
    NSArray *repeatDataArray;
    NSInteger selectID;
    AVAudioPlayer *avAudioPlayer;
}

@end

@implementation ClockMusicVC

- (void)viewDidLoad {
    [super viewDidLoad];
    selectID=0;
    // Do any additional setup after loading the view.
    repeatDataArray=[[NSArray alloc]initWithObjects:@"Music 1",@"Music 2",@"Music 3",@"Music 4",@"Music 5",@"Music 6", @"Music 7",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicNotification" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillDisappear:(BOOL)animated{
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithInteger:selectID],@"selectMusicID",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ClockMusicNotification" object:nil userInfo:dic];
    avAudioPlayer=nil;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
//返回TableView中有多少数据
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
//返回有多少个TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//组装每一条的数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"RepeatCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text=[repeatDataArray objectAtIndex:indexPath.row];
    if (selectID == indexPath.row) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}
//选中Cell响应事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *string = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"Music%ld",(long)indexPath.row+1] ofType:@"caf"];
    //把音频文件转换成url格式
    NSURL *url = [NSURL fileURLWithPath:string];
    //初始化音频类 并且添加播放文件
    avAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
    //设置初始音量大小
    // avAudioPlayer.volume = 1;
    //        //设置音乐播放次数  -1为一直循环
    //        _avAudioPlayer.numberOfLoops = -1;
    //预播放
    [avAudioPlayer prepareToPlay];
    avAudioPlayer.volume=0.5;
    [avAudioPlayer play];
    
    selectID=indexPath.row;
    [tableView reloadData];
}
@end

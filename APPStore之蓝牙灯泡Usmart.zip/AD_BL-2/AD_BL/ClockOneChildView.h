//
//  ClockOneChildView.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/9.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClockOneChildView : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *MyClockTableView;

- (IBAction)AddClockAction:(id)sender;
@end

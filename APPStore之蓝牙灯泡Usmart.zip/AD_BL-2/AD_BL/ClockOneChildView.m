//
//  ClockOneChildView.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/9.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "ClockOneChildView.h"
#import "ClockCell.h"
#import "ClockDetailVC.h"

@interface ClockOneChildView (){
    NSMutableArray *ClockDataArray;
    NSUserDefaults *userDefaults;
}
@end

@implementation ClockOneChildView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    userDefaults= [NSUserDefaults  standardUserDefaults];
    ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
    if ([ClockDataArray count]) {
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(GetLocationDate:) name:@"ClockDetailLocationNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(editLocationDate:) name:@"ClockEditNotification" object:nil];
}
-(void)viewWillAppear:(BOOL)animated{
    for (NSInteger i=0; i<[ClockDataArray count]; i++) {
        //如果开关是开着，代表是有效的闹钟
        if([[[ClockDataArray objectAtIndex:i] objectForKey:@"type"] boolValue]){
            //判断是否是单次闹钟
            NSArray *WeekArray=[[[[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] objectAtIndex:1] objectAtIndex:0] objectForKey:@"Data"];
            int n=0;//一周有多少天
            for (NSInteger i=0; i<7; i++) {
                if([[WeekArray objectAtIndex:i] boolValue]){
                    n++;
                }
            }
            if (n) {
                //如果不是单次闹钟
            }else{
                //如果是单次闹钟
                NSDate *localDate=[[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] objectAtIndex:2];
                //判断闹钟时间是否过期
                if([localDate timeIntervalSinceNow]<0){
                    //已过期
//                    NSLog(@"时间过期");
                    NSMutableDictionary *ClockDic=[[NSMutableDictionary alloc]initWithDictionary:[ClockDataArray objectAtIndex:i]];
                    NSMutableDictionary *dataClockArray=[[NSMutableDictionary alloc]initWithDictionary:[ClockDic objectForKey:@"dataArray"]];
                    //改变本地数据
                    [ClockDic setObject:@"0" forKey:@"type"];
                    [dataClockArray setObject:[NSNumber numberWithBool:NO] forKey:@"Switch"];
                    [ClockDic setObject:dataClockArray forKey:@"dataArray"];
                    
                    [ClockDataArray removeObjectAtIndex:i];
                    [ClockDataArray addObject:ClockDic];
                    [userDefaults setObject:ClockDataArray forKey:@"ClockDataData"];
                    i--;
                }else{
                    //未过期
//                    NSLog(@"时间未过期");
                }
            }
        }else{
            //开关是关着的，不能在此处排序，否则会死循环
            break;
        }
    }
    [_MyClockTableView reloadData];
}

//增加闹钟方法执行入口
-(void)GetLocationDate:(NSNotification*)notification{
    NSLog(@"++++++++++++++++++++++++++++++++++++:%@",notification);
    NSMutableArray *dataArray=[[NSMutableArray alloc]initWithArray:[[notification userInfo] objectForKey:@"selectArray"]];
    if ([dataArray count]<3) {
//        NSLog(@"增加闹钟数据不对");
        return;
    }
   
    NSDate *localDate=[dataArray objectAtIndex:2];
    NSMutableDictionary *LocationDataDic=[[NSMutableDictionary alloc]init];
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"aaa"];
    NSString *strOne=[dateformat stringFromDate:localDate];
    [dateformat setDateFormat:@"h:mm"];
    NSString *strTwo=[dateformat stringFromDate:localDate];
    NSString *strThree=[NSString stringWithFormat:@"%@,%@",[[[dataArray objectAtIndex:1] objectAtIndex:1] objectForKey:@"Title"],[[[dataArray objectAtIndex:1] objectAtIndex:0] objectForKey:@"Title"]];
    [LocationDataDic setObject:strOne forKey:@"AMPMStr"];
    [LocationDataDic setObject:strTwo forKey:@"DetailTimeStr"];
    [LocationDataDic setObject:strThree forKey:@"EventAndTimeStr"];
    [LocationDataDic setObject:[NSNumber numberWithBool:YES] forKey:@"Switch"];
    NSDictionary *ClockDic=[[NSDictionary alloc]initWithObjectsAndKeys:LocationDataDic,@"dataArray",dataArray,@"selectArray",@"1",@"type", nil];
    ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
    [self addLocalNotification:dataArray :ClockDic :YES];
    
    
}
//编辑闹钟方法执行入口
-(void)editLocationDate:(NSNotification*)notification{
//    NSLog(@"编辑闹钟方法执行入口:%@",[[notification userInfo] objectForKey:@"row"]);
    
    ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
    int row=[[[notification userInfo] objectForKey:@"row"] intValue];
    //首先删除原来的本地闹钟
    NSArray * array = [[UIApplication sharedApplication] scheduledLocalNotifications];
    for (UILocalNotification *notification in array) {
        NSString *indentiString = [notification.userInfo objectForKey:@"DelID"];
        if ([indentiString isEqualToString:[NSString stringWithFormat:@"%@",[[[ClockDataArray objectAtIndex:row] objectForKey:@"selectArray"]objectAtIndex:2] ]] == YES) {
            [[UIApplication sharedApplication] cancelLocalNotification:notification];
            break;
        }
    }
    //如果开关是开的，删除原来的灯闹钟
    if([[[ClockDataArray objectAtIndex:row] objectForKey:@"type"] integerValue]){
//        NSLog(@"编辑的行是开着的");
        NSInteger  n1=(row<<3);
        char strcommand[9]={'A','T','#','T','*','0','0','0','0'};
        strcommand[4] = n1;
        strcommand[7] =0X0D;
        strcommand[8] =0X0A;
        NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    }
    
    
    NSMutableArray *dataArray=[[NSMutableArray alloc]initWithArray:[[notification userInfo] objectForKey:@"selectArray"]];
    NSLog(@"dataArray:%@",dataArray);
    
    //整理显示到界面的数据
    NSDate *localDate=[dataArray objectAtIndex:2];
    NSMutableDictionary *LocationDataDic=[[NSMutableDictionary alloc]init];
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"aaa"];
    NSString *strOne=[dateformat stringFromDate:localDate];
    [dateformat setDateFormat:@"h:mm"];
    NSString *strTwo=[dateformat stringFromDate:localDate];
    NSString *strThree=[NSString stringWithFormat:@"%@,%@",[[[dataArray objectAtIndex:1] objectAtIndex:1] objectForKey:@"Title"],[[[dataArray objectAtIndex:1] objectAtIndex:0] objectForKey:@"Title"]];
    [LocationDataDic setObject:strOne forKey:@"AMPMStr"];
    [LocationDataDic setObject:strTwo forKey:@"DetailTimeStr"];
    [LocationDataDic setObject:strThree forKey:@"EventAndTimeStr"];
    [LocationDataDic setObject:[NSNumber numberWithBool:YES] forKey:@"Switch"];
    NSDictionary *ClockDic=[[NSDictionary alloc]initWithObjectsAndKeys:LocationDataDic,@"dataArray",[[notification userInfo] objectForKey:@"selectArray"],@"selectArray",@"1",@"type", nil];
    [ClockDataArray removeObjectAtIndex:row];
   
    
    [self addLocalNotification:dataArray :ClockDic :YES];
}
#pragma mark 添加本地通知
-(void)addLocalNotification:(NSArray *)dataArray :(NSDictionary*)ClockDic :(BOOL)IsAdd{
    NSDate *localDate=[dataArray objectAtIndex:2];
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"HH"];
    int n2=[[dateformat stringFromDate:localDate] intValue];
    [dateformat setDateFormat:@"mm"];
    int n3=[[dateformat stringFromDate:localDate] intValue];
    
    [dateformat setDateFormat:@"ss"];
    int n4=[[dateformat stringFromDate:localDate] intValue];
    localDate = [NSDate  dateWithTimeInterval:-n4 sinceDate:localDate];
    
    NSArray *WeekArray=[[[dataArray objectAtIndex:1] objectAtIndex:0] objectForKey:@"Data"];
    int m=0;//一周有多少天
    int weakO=0;
    for (NSInteger i=0; i<7; i++) {
        if([[WeekArray objectAtIndex:i] boolValue]){
            weakO=weakO|(1<<i);
            NSLog(@"weak:%x",weakO);
            m++;
            
            //定义本地通知对象
            UILocalNotification *notification=[[UILocalNotification alloc]init];
            notification.fireDate=localDate;//通知触发的时间
            notification.repeatInterval=NSWeekCalendarUnit;//通知重复次数
            [notification setTimeZone:[NSTimeZone defaultTimeZone]];
            notification.alertBody=[[[dataArray objectAtIndex:1] objectAtIndex:1] objectForKey:@"Title"]; //通知主体
            notification.applicationIconBadgeNumber=1;//应用程序图标右上角显示的消息数
            notification.alertAction=NSLocalizedStringFromTable(@"twelve", @"Localizable", nil); //待机界面的滑动动作提示
            notification.alertLaunchImage=@"Default";//通过点击通知打开应用时的启动图片,这里使用程序启动图片
            //notification.soundName=UILocalNotificationDefaultSoundName;//收到通知时播放的声音，默认消息声音
            notification.soundName=[NSString stringWithFormat:@"%@.caf",[[[dataArray objectAtIndex:1] objectAtIndex:2] objectForKey:@"Title"]];//通知声音（需要真机才能听到声音）
//            NSLog(@"播放的音乐----------%@",notification.soundName);
            notification.userInfo=[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%@",localDate],@"DelID", nil];//绑定到通知上的其他附加信息//设置用户信息
            [[UIApplication sharedApplication] scheduleLocalNotification:notification];//调用通知
        }
    }
    
    
    if (m) {
        m=1;//有重复
    }else{//没有选择星期，默认执行一次
        if([localDate timeIntervalSinceNow]<0){
//            NSLog(@"单次闹钟时间已过，设置明天的同一时间");
            NSTimeInterval secondsPerDay = -24 * 60 * 60 ;
            int howMuchDay=[localDate timeIntervalSinceNow]/secondsPerDay+1;
            localDate = [NSDate  dateWithTimeInterval:secondsPerDay*howMuchDay sinceDate:localDate];
        }
        UILocalNotification *notification=[[UILocalNotification alloc]init];
        //设置调用时间
        notification.fireDate=localDate;//通知触发的时间
        [notification setTimeZone:[NSTimeZone defaultTimeZone]];
        //设置通知属性
        notification.alertBody=[[[dataArray objectAtIndex:1] objectAtIndex:1] objectForKey:@"Title"]; //通知主体
        notification.applicationIconBadgeNumber=1;//应用程序图标右上角显示的消息数
        notification.alertAction=NSLocalizedStringFromTable(@"twelve", @"Localizable", nil); //待机界面的滑动动作提示
        notification.alertLaunchImage=@"Default";//通过点击通知打开应用时的启动图片,这里使用程序启动图片
        //notification.soundName=UILocalNotificationDefaultSoundName;//收到通知时播放的声音，默认消息声音
        notification.soundName=[NSString stringWithFormat:@"%@.caf",[[[dataArray objectAtIndex:1] objectAtIndex:2] objectForKey:@"Title"]];//通知声音（需要真机才能听到声音）
//        NSLog(@"播放的音乐----------%@",notification.soundName);
        //设置用户信息
        notification.userInfo=[[NSDictionary alloc] initWithObjectsAndKeys:[NSString stringWithFormat:@"%@",localDate],@"DelID", nil];//绑定到通知上的其他附加信息
        //调用通知
        [[UIApplication sharedApplication] scheduleLocalNotification:notification];
    }
    
    NSInteger clockID=0;
    for (NSInteger i=[ClockDataArray count]-1; i>=0; i--) {
        if ([[[ClockDataArray objectAtIndex:i] objectForKey:@"type"] integerValue]) {
            clockID=i+1;
            break;
        }
    }
    NSLog(@"clockID:%ld",(long)clockID);
    
    
    NSInteger  n1=(clockID<<3)|(m<<2)|(1<<1)|1;
    
    
    char strcommand[9]={'A','T','#','T','*','*','*','*','*'};
    strcommand[4] = n1;
    strcommand[5] = n2;
    strcommand[6] = n3;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
    if (m) {
        //        AT#FFxx  Send（“AT#FF”,第几个闹钟,星期几, “\r\n”）；//星期1-5发送B00011111=0x1F.
        char strcommand1[9]={'A','T','#','F','F','*','*','*','*'};
        strcommand1[5] = clockID;//得变
        strcommand1[6] = weakO;
        strcommand1[7] =0X0D;
        strcommand1[8] =0X0A;
        NSData *cmdData1 = [NSData dataWithBytes:strcommand1 length:9];
        NSDictionary *dic1=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData1,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic1];
    }
//    NSLog(@"保存数据");
    [ClockDataArray insertObject:ClockDic atIndex:clockID];
    [userDefaults setObject:ClockDataArray forKey:@"ClockDataData"];
    [_MyClockTableView reloadData];
    
    
}
-(void)swithChange:(UISwitch*)MySwith{
    NSLog(@"MySwith:%ld,%d",(long)MySwith.tag,MySwith.on);
    ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
    NSMutableDictionary *ClockDic=[[NSMutableDictionary alloc]initWithDictionary:[ClockDataArray objectAtIndex:MySwith.tag]];
    NSMutableDictionary *dataArray=[[NSMutableDictionary alloc]initWithDictionary:[ClockDic objectForKey:@"dataArray"]];
    
    NSLog(@"ClockDic:%@",ClockDic);
    if (MySwith.on) {
        
        //增加本地通知与新加闹钟指令
        NSArray *selectArray=[ClockDic objectForKey:@"selectArray"];
        [ClockDataArray removeObjectAtIndex:MySwith.tag];
        //改变本地数据
        [ClockDic setObject:@"1" forKey:@"type"];
        [dataArray setObject:[NSNumber numberWithBool:YES] forKey:@"Switch"];
        [ClockDic setObject:dataArray forKey:@"dataArray"];
        NSLog(@"ClockDic:%@",ClockDic);
        [self addLocalNotification:selectArray :ClockDic :YES];
        
    }else{
        
        //取消本地通知
        NSArray * array = [[UIApplication sharedApplication] scheduledLocalNotifications];
        for (UILocalNotification *notification in array) {
            NSString *indentiString = [notification.userInfo objectForKey:@"DelID"];
            if ([indentiString isEqualToString:[NSString stringWithFormat:@"%@",[[[ClockDataArray objectAtIndex:MySwith.tag] objectForKey:@"selectArray"] objectAtIndex:2]]] == YES) {
                [[UIApplication sharedApplication] cancelLocalNotification:notification];
                break;
            }
        }
        
        
        //发送取消指令
        NSInteger  n1=((MySwith.tag)<<3);
        char strcommand[9]={'A','T','#','T','*','0','0','0','0'};
        strcommand[4] = n1;
        strcommand[7] =0X0D;
        strcommand[8] =0X0A;
        NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
        
        //改变本地数据
        [ClockDic setObject:@"0" forKey:@"type"];
        [dataArray setObject:[NSNumber numberWithBool:NO] forKey:@"Switch"];
        [ClockDic setObject:dataArray forKey:@"dataArray"];
        
        [ClockDataArray removeObjectAtIndex:(long)MySwith.tag];
        [ClockDataArray addObject:ClockDic];
        
        NSLog(@"ClockDic:%@",ClockDic);
        [userDefaults setObject:ClockDataArray forKey:@"ClockDataData"];
        [_MyClockTableView reloadData];
    }
    
    
    
    
}
- (IBAction)AddClockAction:(id)sender {
    UIViewController* clockDetailViewContrller=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"ClockDetail"];
    [self presentViewController:clockDetailViewContrller animated:YES completion:nil];
}

#pragma mark - TableView
//返回TableView中有多少数据
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [ClockDataArray count];
}

//返回有多少个TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//组装每一条的数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CustomClockCellIdentifier =@"ClockCell";
    ClockCell *cell = [tableView dequeueReusableCellWithIdentifier: CustomClockCellIdentifier];
    if (cell ==nil) {
        cell = [[ClockCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CustomClockCellIdentifier];
    }
    cell.contentView.tag=10000;
    ((ClockCell*)cell).AMPMLabel.text=[[[ClockDataArray objectAtIndex:indexPath.row] objectForKey:@"dataArray"]objectForKey:@"AMPMStr"];
    ((ClockCell*)cell).DetailTimeLabel.text=[[[ClockDataArray objectAtIndex:indexPath.row] objectForKey:@"dataArray"]  objectForKey:@"DetailTimeStr"];
    ((ClockCell*)cell).EventAndTimeLabel.text=[[[ClockDataArray objectAtIndex:indexPath.row]  objectForKey:@"dataArray"]objectForKey:@"EventAndTimeStr"];
    ((ClockCell*)cell).MySwith.on=[[[[ClockDataArray objectAtIndex:indexPath.row] objectForKey:@"dataArray"]  objectForKey:@"Switch"] boolValue];
    [((ClockCell*)cell).MySwith addTarget:self action:@selector(swithChange:) forControlEvents:UIControlEventValueChanged];
    ((ClockCell*)cell).MySwith.tag=indexPath.row;
    return cell;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
        if (indexPath.row<[ClockDataArray count]) {
            if ([[[ClockDataArray objectAtIndex:indexPath.row] objectForKey:@"type"] integerValue]) {
//                NSLog(@"进入");
                //开关必须是开的才删除
                NSInteger  n1=((indexPath.row)<<3);
                char strcommand[9]={'A','T','#','T','*','0','0','0','0'};
                strcommand[4] = n1;
                strcommand[7] =0X0D;
                strcommand[8] =0X0A;
                NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
                NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
                
                
                NSArray * array = [[UIApplication sharedApplication] scheduledLocalNotifications];
//                NSLog(@"已有的本地通知:%@",array);
                for (UILocalNotification *notification in array) {
                    NSString *indentiString = [notification.userInfo objectForKey:@"DelID"];
                    if ([indentiString isEqualToString:[NSString stringWithFormat:@"%@",[[[ClockDataArray objectAtIndex:indexPath.row] objectForKey:@"selectArray"] objectAtIndex:2] ]] == YES) {
                        [[UIApplication sharedApplication] cancelLocalNotification:notification];
                        break;
                    }
                }
            }
            
            [ClockDataArray removeObjectAtIndex:indexPath.row];
            [userDefaults setObject:ClockDataArray forKey:@"ClockDataData"];
            [tableView reloadData];
            
        }else{
//            NSLog(@"删除闹钟数组越界");
        }
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
    }
}

//选中Cell响应事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UIViewController* clockDetailViewContrller=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"ClockDetail"];
    [self presentViewController:clockDetailViewContrller animated:YES completion:nil];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:@"1",@"editType",[NSNumber numberWithInteger:indexPath.row],@"rowNumber", nil];
    dispatch_time_t time=dispatch_time(DISPATCH_TIME_NOW, 1ull*NSEC_PER_SEC);
    dispatch_after(time, dispatch_get_main_queue(), ^{
       [[NSNotificationCenter defaultCenter] postNotificationName:@"TypeNotification" object:nil userInfo:dic];
    });
    
}
@end

//
//  ClockTwoChildView.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/9.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "draw_graphic.h"

@interface ClockTwoChildView : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (weak, nonatomic) IBOutlet UIButton *fifteenButton;
@property (weak, nonatomic) IBOutlet UIButton *thirtyButton;
@property (weak, nonatomic) IBOutlet UIButton *fortyfiveButton;
@property (weak, nonatomic) IBOutlet UIButton *sixtyButton;
@property (weak, nonatomic) IBOutlet UILabel *DetailLabel;
@property (weak, nonatomic) IBOutlet draw_graphic *MiddleView;

- (IBAction)fifteenAction:(id)sender;
- (IBAction)thirtyAction:(id)sender;
- (IBAction)fortyfiveAction:(id)sender;
- (IBAction)sixtyAction:(id)sender;


@end

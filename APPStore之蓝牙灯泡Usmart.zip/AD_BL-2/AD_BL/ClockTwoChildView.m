//
//  ClockTwoChildView.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/9.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "ClockTwoChildView.h"
#import "CommonClass.h"

@interface ClockTwoChildView (){
    __block int timeout;
    dispatch_queue_t queue;
    dispatch_source_t _timer;
}

@end

@implementation ClockTwoChildView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    queue= dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(LabelTaped:)];
    _MiddleView.userInteractionEnabled=YES;
    [_MiddleView addGestureRecognizer:tapRecognizer];
    
}
-(void)LabelTaped:(UITapGestureRecognizer *)recognizer
{
//    NSLog(@"取消睡眠");
    if (_timer!=nil) {
        dispatch_source_cancel(_timer);
    }
    _timeLabel.text=@"00:00:00";
    _DetailLabel.text=NSLocalizedStringFromTable(@"twenty-two", @"Localizable", nil);
    [_fifteenButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_thirtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_fortyfiveButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_sixtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    
    
    //删除睡眠闹钟
    NSInteger  n1=(31<<3);
    char strcommand[9]={'A','T','#','T','*','0','0','0','0'};
    strcommand[4] = n1;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
}
-(void)sendMessage:(int)timeNumber{
//    NSLog(@"开始");
    timeout=timeNumber; //倒计时时间
    
    _DetailLabel.text=NSLocalizedStringFromTable(@"twenty-three", @"Localizable", nil);
    //设置睡眠指令:关灯
//    char strcommand[6]={'A','T','#','L','E','0'};
//    NSData *cmdData = [NSData dataWithBytes:strcommand length:6];
//    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
    
    NSDate *localDate=[NSDate date];
    NSTimeInterval secondsPerDay = timeNumber;
    
    NSDate *tomorrow = [NSDate  dateWithTimeInterval:secondsPerDay sinceDate:localDate];
    NSLog(@"targetDate:%@",tomorrow);
    
    NSInteger  n1=(31<<3)|(1<<2)|(1<<1)|0;
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"HH"];
    int n2=[[dateformat stringFromDate:tomorrow] intValue];
    [dateformat setDateFormat:@"mm"];
    int n3=[[dateformat stringFromDate:tomorrow] intValue];
    
    char strcommand[9]={'A','T','#','T','*','*','*','*','*'};
    strcommand[4] = n1;
    strcommand[5] = n2;
    strcommand[6] = n3;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSLog(@"cmdData:%@",cmdData);
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEAllDataNotification" object:nil userInfo:dic];
    
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _timeLabel.text=@"00:00:00";
                _DetailLabel.text=NSLocalizedStringFromTable(@"twenty-two", @"Localizable", nil);
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicNotification" object:nil];
                [_fifteenButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
                [_thirtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
                [_fortyfiveButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
                [_sixtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _timeLabel.text=[CommonClass formatTime:timeout];
//                NSLog(@"更新");
            });
            timeout--;
        }
    });
    dispatch_resume(_timer);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    [self sendMessage:1*60];
}
- (IBAction)fifteenAction:(id)sender {
    [_fifteenButton setBackgroundColor:[UIColor darkGrayColor]];
    [_thirtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_fortyfiveButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_sixtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    
    [self sendMessage:15*60];
}

- (IBAction)thirtyAction:(id)sender {
    [_fifteenButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_thirtyButton setBackgroundColor:[UIColor darkGrayColor]];
    [_fortyfiveButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_sixtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    
    [self sendMessage:30*60];
}

- (IBAction)fortyfiveAction:(id)sender {
    [_fifteenButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_thirtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_fortyfiveButton setBackgroundColor:[UIColor darkGrayColor]];
    [_sixtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    
    [self sendMessage:60*60];
}

- (IBAction)sixtyAction:(id)sender {
    [_fifteenButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_thirtyButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_fortyfiveButton setBackgroundColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1]];
    [_sixtyButton setBackgroundColor:[UIColor darkGrayColor]];
    
    [self sendMessage:2*60*60];
}
@end

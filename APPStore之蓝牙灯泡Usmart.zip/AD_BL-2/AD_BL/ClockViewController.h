//
//  ClockViewController.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/7.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClockViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *childView;

- (IBAction)segmentAction:(id)sender;

@end

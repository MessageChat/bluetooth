//
//  ClockViewController.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/7.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "ClockViewController.h"
#import "MMDrawerController.h"
#import "MMDrawerBarButtonItem.h"

#import "ClockOneChildView.h"
#import "ClockTwoChildView.h"

@interface ClockViewController (){
    ClockOneChildView *oneChildView;
    ClockTwoChildView *twoChildView;
    UIViewController *currentViewController;
}

@end

@implementation ClockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedStringFromTable(@"CLOCKPAGE", @"Localizable", nil);
    [self setupLeftMenuButton];
    
    oneChildView=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"clockOneChild"];
    
    twoChildView=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"clockTwoChild"];
    
    [self addChildViewController:oneChildView];
    [self addChildViewController:twoChildView];
    [self.childView  addSubview:oneChildView.view];
    currentViewController=oneChildView;
}

-(void)awakeFromNib{
    
}

-(void)viewDidAppear:(BOOL)animated{
    twoChildView.view.frame=CGRectMake(0, 0, self.childView.frame.size.width, self.childView.frame.size.height);
    oneChildView.view.frame=CGRectMake(0, 0, self.childView.frame.size.width, self.childView.frame.size.height);
    
//    33	AT#Dxxx		HAX	xxx=星期,小时，分钟，秒当前时间
    //AT#Dxxx
    //第一个x
    //Bit7:5	当前星期几	1-7
    //Bit4:0	当前小时	0-23
    //第二个x
    //Bit7:0	当前分钟	0-59
    //第三个x
    //Bit7:0	当前秒钟	0-59
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *nowDate=[NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    comps = [calendar components:unitFlags fromDate:nowDate];
    NSInteger week = [comps weekday];
    if (week==1) {
        week=7;
    }else{
        week--;
    }
    //Week:1 －－星期天 2－－星期一 3－－星期二 4－－星期三 5－－星期四 6－－星期五 7－－星期六
    
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"HH"];
    int n2=[[dateformat stringFromDate:nowDate] intValue];
    [dateformat setDateFormat:@"mm"];
    int n3=[[dateformat stringFromDate:nowDate] intValue];
    [dateformat setDateFormat:@"ss"];
    int n4=[[dateformat stringFromDate:nowDate] intValue];
    NSInteger  n1=(week<<5)|n2;
    
    char strcommand[9]={'A','T','#','D','*','*','*','0','0'};
    strcommand[4] = n1;
    strcommand[5] = n3;
    strcommand[6] = n4;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - Button Handlers
-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}

-(MMDrawerController*)mm_drawerController{
    UIViewController *parentViewController = self.parentViewController;
    while (parentViewController != nil) {
        if([parentViewController isKindOfClass:[MMDrawerController class]]){
            return (MMDrawerController *)parentViewController;
        }
        parentViewController = parentViewController.parentViewController;
    }
    return nil;
}

-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (IBAction)segmentAction:(id)sender {
    
    NSInteger Index = ((UISegmentedControl *)sender).selectedSegmentIndex;
    switch (Index)
    {
        case 0:
        {
            [self transitionFromViewController:currentViewController toViewController:oneChildView duration:1 options:UIViewAnimationOptionTransitionNone animations:^{
            }  completion:^(BOOL finished) {
                if (finished) {
                    currentViewController=oneChildView;
                }else{
                    currentViewController=twoChildView;
                }
            }];
        }
            break;
        case 1:
        {
            [self transitionFromViewController:currentViewController toViewController:twoChildView duration:1 options:UIViewAnimationOptionTransitionNone animations:^{
            }  completion:^(BOOL finished) {
                if (finished) {
                    currentViewController=twoChildView;
                }else{
                    currentViewController=oneChildView;
                }
            }];
        }
            
            break;
        
    }
    
    
}
@end

//
//  CommentManager.h
//  BackGroundTest
//
//  Created by gaowei on 15/1/11.
//  Copyright (c) 2015年 ios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface CommentManager : NSObject
{
    
}

+ (CommentManager *)sharedManager;

//播放
- (void)play;
//暂停
- (void)pause;
//停止
- (void)stop;


@end

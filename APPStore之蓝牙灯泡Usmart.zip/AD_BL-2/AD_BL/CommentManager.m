//
//  CommentManager.m
//  BackGroundTest
//
//  Created by gaowei on 15/1/11.
//  Copyright (c) 2015年 ios. All rights reserved.
//

#import "CommentManager.h"

@interface CommentManager ()
{
    
}
@property (nonatomic, strong) AVAudioPlayer *avAudioPlayer;

@end

static CommentManager *sharedManager = nil;

@implementation CommentManager


+ (CommentManager *)sharedManager
{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        sharedManager = [[self alloc] init];
    });
    return sharedManager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSString *string = [[NSBundle mainBundle] pathForResource:@"silent" ofType:@"mp3"];
        //把音频文件转换成url格式
        NSURL *url = [NSURL fileURLWithPath:string];
        //初始化音频类 并且添加播放文件
        _avAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        //设置初始音量大小
        // avAudioPlayer.volume = 1;
//        //设置音乐播放次数  -1为一直循环
//        _avAudioPlayer.numberOfLoops = -1;
        //预播放
        [_avAudioPlayer prepareToPlay];
        [[AVAudioSession sharedInstance] setActive:YES error:nil];
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:nil];
        
    }
    return self;
}

//播放
- (void)play
{
    if (_avAudioPlayer.isPlaying) {
        [_avAudioPlayer stop];
    }
    [_avAudioPlayer play];
}
//暂停
- (void)pause
{
    [_avAudioPlayer pause];
}
//停止
- (void)stop
{
    [_avAudioPlayer stop];
}

@end

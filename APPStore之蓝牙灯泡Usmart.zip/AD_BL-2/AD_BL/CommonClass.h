//
//  CommonClass.h
//  newProject2
//
//  Created by csc on 14-1-20.
//  Copyright (c) 2014年 csc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonClass : NSObject
//获取当前时间
+ (NSString *)getCurrentTime;

+(NSString *)getTimeSp;
//将NSDate按yyyy-MM-dd HH:mm:ss格式时间输出
+(NSString*)nsdateToString:(NSDate *)date;

//将时间戳转换成NSDate
+(NSDate *)changeSpToTime:(NSString*)spString;

//发送数据时,16进制数－>Byte数组->NSData
+(NSData *)hexToByteToNSData:(NSString *)str;



//接收数据时,NSData－>Byte数组->16进制数
+(NSString *)NSDataToByteTohex:(NSData *)data;

//发送数据时,16进制数－>Byte数组->NSArray
+(NSArray *)hexToByteToNSArray:(NSString *)str;

//发送数据时,16进制数－>Byte数组->NSString
+(NSString *)hexToByteToNSString:(NSString *)str;

//将汉字字符串转换成UTF8字符串
+(NSString *)chineseToUTf8Str:(NSString*)chineseStr;

//将十六进制字符串转换成汉字
+(NSString*)changeLanguage:(NSString*)chinese;

//正则表达式
+(BOOL)isValidateString:(NSString *)matchStr pattern:(NSString*)pattern;

//对字符串进行MD5加密
+ (NSString *)md5:(NSString *)str;

//将汉字字符串转换成16进制字符串
+(NSString *)chineseToHex:(NSString*)chineseStr;

//发送数据时,16进制数－>Byte数组->NSData,加上校验码部分
+(NSData *)hexToByteToNSData1:(NSString *)str;


//生成随机数
+(int)getRandomNumber:(int)from to:(int)to;

//存写随机数
+ (void)write_string:(int)aInt;

//获取保存的随机数
+(NSString *)getValid;

//将十进制转化为十六进制
+ (NSString *)ToHex:(uint16_t)tmpid;

//十六进制数转十进制数,个数不一样
+(int)TotexHex1:(NSString*)tmpid;

//十六进制数转十进制数
+(int)TotexHex:(NSString*)tmpid;

//获取系统版本号
+ (BOOL)getIOSVersion;

//反转字符串
+(NSString *)reverseString:(NSString *)aString;

//创建背景图片
+ (UIImageView *) createModelImageViewWith :(NSString *)aimage :(CGRect)aframe;

//创建标签
+ (UILabel *) createModelLabelWith :(CGRect)aframe :(NSString *)astring :(float)afont :(UIColor *)acolor :(NSInteger)aInteger;

+ (UIImage *)getImageBySmallPNG:(NSString *)name;
+ (UIImage *)getImageWithStretchableByBundlePathWithImageName:(NSString *)name :(float)leftCap :(float) topCap;
+ (UITextField *)createModelTextFieldWith :(CGRect)aframe :(NSString *)astring :(float)afont :(UIColor *)acolor :(NSInteger)aInteger :(NSInteger)aTag;

+ (UIButton *)creatModelButtonWith:(NSString *)normalImage :(NSString *)heigLightedImage :(int)aTag :(CGRect)aframe;

+ (NSString *) formatTime: (int) num;

@end

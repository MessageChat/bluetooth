//
//  CommonClass.m
//  newProject2
//
//  Created by csc on 14-1-20.
//  Copyright (c) 2014年 csc. All rights reserved.
//

#import "CommonClass.h"
#import <CommonCrypto/CommonCrypto.h>

@implementation CommonClass
//获取当前时间
+ (NSString *)getCurrentTime
{
    NSDate *dateNow = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat : @"yyyy-MM-dd HH:mm:ss"];
    return  [formatter stringFromDate:dateNow];
}


////发送数据时,16进制数－>Byte数组->NSData
+(NSData *)hexToByteToNSData:(NSString *)str{
    int j=0;
    Byte bytes[[str length]/2];
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        
        j++;
        if (j==[str length]/2) {
            int k=6;
            int_ch=bytes[4]^bytes[5];
            
            while (k<[str length]/2) {
                int_ch=int_ch^bytes[k];
                
                k++;
            }
            bytes[3] = int_ch;
        }
    }
    //    处理校验码
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:[str length]/2 ];
    return newData;
}
//将十进制转化为十六进制
+ (NSString *)ToHex:(uint16_t)tmpid
{
    NSString *nLetterValue;
    NSString *str =@"";
    uint16_t ttmpig;
    for (int i = 0; i<9; i++) {
        ttmpig=tmpid%16;
        tmpid=tmpid/16;
        switch (ttmpig)
        {
            case 10:
                nLetterValue =@"A";break;
            case 11:
                nLetterValue =@"B";break;
            case 12:
                nLetterValue =@"C";break;
            case 13:
                nLetterValue =@"D";break;
            case 14:
                nLetterValue =@"E";break;
            case 15:
                nLetterValue =@"F";break;
            default:
                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
                
        }
        str = [nLetterValue stringByAppendingString:str];
        if (tmpid == 0) {
            break;
        }
    }
    if ([str length]==2) {
        str=[NSString stringWithFormat:@"%@00",str];
    }else if ([str length]==1){
        str=[NSString stringWithFormat:@"0%@00",str];
    }else if ([str length]==3){
        str=[NSString stringWithFormat:@"%@0%@",[str substringFromIndex:1],[str substringToIndex:1]];
    }
    
    return str;
}



//接收数据时,NSData－>Byte数组->16进制数
+(NSString *)NSDataToByteTohex:(NSData *)data{
    Byte *bytes = (Byte *)[data bytes];
    NSString *hexStr=@"";
    for(int i=0;i<[data length];i++)
    {
        NSString *newHexStr= [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr;
}
//发送数据时,16进制数－>Byte数组->NSString
+(NSString *)hexToByteToNSString:(NSString *)str{
    int j=0;
    Byte bytes[[str length]/2];
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        j++;
    }
    NSString *astr=[[NSString alloc]initWithBytes:bytes length:[str length]/2 encoding:NSASCIIStringEncoding];
    return astr;
}

//发送数据时,16进制数－>Byte数组->NSArray
+(NSArray *)hexToByteToNSArray:(NSString *)str{
    
    int j=0;
    Byte bytes[[str length]/2];
    NSMutableArray *astr=[[NSMutableArray alloc]initWithCapacity:0];
    if ([str length]%2!=0) {
        return nil;
    }
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        if (bytes[j]==0) {
            NSStringEncoding encodingGB18030= CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            NSString* TemStr=[[NSString alloc]initWithBytes:bytes length:j encoding:encodingGB18030];
            
            
            [astr addObject:TemStr];
            
            j=-1;
            
        }
        j++;
    }
    
    
    return astr;
}

+(NSString *)getTimeSp{
    long time;
    NSDate *fromdate=[NSDate date];
    time=(long)[fromdate timeIntervalSince1970];
    NSString *tipString = [NSString stringWithFormat:@"%ld",time];
    return tipString;
}

//将NSDate按yyyy-MM-dd HH:mm:ss格式时间输出
+(NSString*)nsdateToString:(NSDate *)date{
    NSDateFormatter *dateFormat=[[NSDateFormatter alloc]init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString* string=[dateFormat stringFromDate:date];
    return string;
}

//将时间戳转换成NSDate
+(NSDate *)changeSpToTime:(NSString*)spString{
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[spString intValue]];
    return confromTimesp;
}

//将汉字字符串转换成UTF8字符串
+(NSString *)chineseToUTf8Str:(NSString*)chineseStr{
    NSStringEncoding encodingUTF8 = NSUTF8StringEncoding;
    NSData *responseData2 =[chineseStr dataUsingEncoding:encodingUTF8 ];
    NSString *string=[CommonClass NSDataToByteTohex:responseData2];
    return string;
}


//将十六进制字符串转换成汉字
+(NSString*)changeLanguage:(NSString*)chinese{
    NSString *strResult;
    if (chinese.length%2==0) {
        //第二次转换
        NSData *newData = [CommonClass hexToByteToNSData1:chinese];
        unsigned long encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        strResult = [[NSString alloc] initWithData:newData encoding:encode];
    }else{
        NSString *strResult = @"已假定是汉字的转换，所传字符串的长度必须是2的倍数!";
        NSLog(@"strResult:%@",strResult);
        return NULL;
    }
    return strResult;
}

//正则表达式
+(BOOL)isValidateString:(NSString *)matchStr pattern:(NSString*)pattern
{
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",pattern];
    return [emailTest evaluateWithObject:matchStr];
}

////将汉字字符串转换成16进制字符串
+(NSString *)chineseToHex:(NSString*)chineseStr{
    NSStringEncoding encodingGB18030= CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *responseData =[chineseStr dataUsingEncoding:encodingGB18030 ];
    NSString *string=[CommonClass NSDataToByteTohex:responseData];
    return string;
}
+ (NSString *)md5:(NSString *)str
{
    if(str == nil || [str length] == 0)
        return nil;
    
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, (int)strlen(cStr), result); // This is the md5 call
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}




//发送数据时,16进制数－>Byte数组->NSData
+(NSData *)hexToByteToNSData1:(NSString *)str{
    int j=0;
    Byte bytes[[str length]/2];
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        
        j++;
    }
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:[str length]/2 ];
    return newData;
}

//生成随机数
+(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from + 1)));
}

//存写随机数
+ (void)write_string:(int)aInt{
    NSString *string = [[NSString alloc] initWithFormat:@"%d",aInt];
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *fileName=[[paths objectAtIndex:0] stringByAppendingPathComponent:@"myValid"];
    NSData *contentData=[string dataUsingEncoding:NSASCIIStringEncoding];
    if ([contentData writeToFile:fileName atomically:YES]) {
        //        NSLog(@">>write ok.");
    }
}

//获取保存的随机数
+(NSString *)getValid{
    NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *fileName=[[paths objectAtIndex:0] stringByAppendingPathComponent:@"myValid"];
    
    NSString *documentsDirectory = [paths objectAtIndex:0];
    if (!documentsDirectory) {
        NSLog(@"Documents directory not found!");
        return NULL;
    }
    if([[NSFileManager defaultManager] fileExistsAtPath:fileName]){
        NSLog(@"File is found");
        NSString *str = [[NSString alloc]initWithContentsOfFile:fileName encoding:NSUTF8StringEncoding error:nil];
        return str;
    }else{
        return NULL;
    }
}

//十六进制数转十进制数
+(int)TotexHex1:(NSString*)tmpid
{
    int int_ch;  ///两位16进制数转化后的10进制数
    unichar hex_char1 = [tmpid characterAtIndex:0]; ////两位16进制数中的第一位(高位*16)
    int int_ch1;
    if(hex_char1 >= '0' && hex_char1 <='9')
        int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
    else if(hex_char1 >= 'A' && hex_char1 <='F')
        int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
    else
        int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
    unichar hex_char2 = [tmpid characterAtIndex:1]; ///两位16进制数中的第二位(低位)
    int int_ch2;
    if(hex_char2 >= '0' && hex_char2 <='9')
        int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
    else if(hex_char2 >= 'A' && hex_char2 <='F')
        int_ch2 = (hex_char2-55); //// A 的Ascll - 65
    else
        int_ch2 = (hex_char2-87); //// a 的Ascll - 97
    int_ch = int_ch1+int_ch2;
    
    return int_ch;
}
//十六进制数转十进制数
+(int)TotexHex:(NSString*)tmpid
{
    int int_ch;  ///两位16进制数转化后的10进制数
    unichar hex_char1 = [tmpid characterAtIndex:0]; ////两位16进制数中的第一位(高位*16)
    int int_ch1;
    if(hex_char1 >= '0' && hex_char1 <='9')
        int_ch1 = (hex_char1-48)*16*16;   //// 0 的Ascll - 48
    else if(hex_char1 >= 'A' && hex_char1 <='F')
        int_ch1 = (hex_char1-55)*16*16; //// A 的Ascll - 65
    else
        int_ch1 = (hex_char1-87)*16*16; //// a 的Ascll - 97
    unichar hex_char2 = [tmpid characterAtIndex:1]; ///两位16进制数中的第二位(低位)
    int int_ch2;
    if(hex_char2 >= '0' && hex_char2 <='9')
        int_ch2 = (hex_char2-48)*16; //// 0 的Ascll - 48
    else if(hex_char2 >= 'A' && hex_char2 <='F')
        int_ch2 = (hex_char2-55)*16; //// A 的Ascll - 65
    else
        int_ch2 = (hex_char2-87)*16; //// a 的Ascll - 97
    
    unichar hex_char3 = [tmpid characterAtIndex:2]; ///两位16进制数中的第二位(低位)
    int int_ch3;
    if(hex_char3 >= '0' && hex_char3 <='9')
        int_ch3 = (hex_char3-48); //// 0 的Ascll - 48
    else if(hex_char3 >= 'A' && hex_char3 <='F')
        int_ch3 = (hex_char3-55); //// A 的Ascll - 65
    else
        int_ch3 = (hex_char3-87); //// a 的Ascll - 97
    
    int_ch = int_ch1+int_ch2 +int_ch3;
    
    return int_ch;
}
//反转字符串
+(NSString *)reverseString:(NSString *)aString{
    NSString *string1 = [aString substringToIndex:2];
    //    NSLog(@"string1:%@",string1);
    NSString *string2 = [aString substringFromIndex:string1.length];
    //    NSLog(@"string2:%@",string2);
    NSString *string = [NSString stringWithFormat:@"%@%@",string2,string1];
    return [string substringFromIndex:1];
}

//创建背景图片
+ (UIImageView *) createModelImageViewWith :(NSString *)aimage :(CGRect)aframe{
    UIImageView *ModelImageView = [[UIImageView alloc]init];
    ModelImageView.frame = aframe;
    ModelImageView.image = [UIImage imageNamed:aimage];
    return ModelImageView;
}

//创建标签
+ (UILabel *) createModelLabelWith :(CGRect)aframe :(NSString *)astring :(float)afont :(UIColor *)acolor :(NSInteger)aInteger{
    UILabel *ModelLabel = [[UILabel alloc]init];
    ModelLabel.frame = aframe;
    ModelLabel.text = astring;
    ModelLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:afont];
    ModelLabel.backgroundColor = [UIColor clearColor];
    ModelLabel.textAlignment = aInteger;
    ModelLabel.textColor = acolor;
    return ModelLabel;
}

+ (UIImage *)getImageWithStretchableByBundlePathWithImageName:(NSString *)name :(float)leftCap :(float) topCap{
    UIImage *image = [self getImageBySmallPNG:name];
    image = [image stretchableImageWithLeftCapWidth:leftCap topCapHeight:topCap];
    return image;
}

+ (UIImage *)getImageBySmallPNG:(NSString *)name
{
    UIImage *image = [UIImage imageNamed:name];
    return image;
}

//获取系统版本号
+ (BOOL)getIOSVersion{
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    if (version>=7.0) {
        return YES;
    }else{
        return NO;
    }
    
}

+ (UITextField *)createModelTextFieldWith :(CGRect)aframe :(NSString *)astring :(float)afont :(UIColor *)acolor :(NSInteger)aInteger :(NSInteger)aTag{
    UITextField *textField = [[UITextField alloc]init];
    textField.frame = aframe;
    textField.textColor = acolor;
    textField.backgroundColor = [UIColor clearColor];
    textField.placeholder = astring;
    textField.enabled = YES;
    textField.font = [UIFont fontWithName:@"Helvetica-Bold" size:afont];
    textField.textAlignment = aInteger;
    textField.tag = aTag;
    return textField;
}
+ (UIButton *)creatModelButtonWith:(NSString *)normalImage :(NSString *)heigLightedImage :(int)aTag :(CGRect)aframe{
    UIButton *ModelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    ModelBtn.frame = aframe;
    //    ModelBtn. = 3;
    [ModelBtn setBackgroundImage:[UIImage imageNamed:normalImage] forState:UIControlStateNormal];
    [ModelBtn setBackgroundImage:[UIImage imageNamed:heigLightedImage] forState:UIControlStateHighlighted];
    ModelBtn.tag = aTag;
    return ModelBtn;
}
+ (NSString *) formatTime: (int) num
{
    int hour=num/3600;
    num=num%3600;
    int secs = num % 60;
    int min = num / 60;
    
    return	[NSString stringWithFormat:@"0%d:%02d:%02d",hour, min, secs];
}

@end

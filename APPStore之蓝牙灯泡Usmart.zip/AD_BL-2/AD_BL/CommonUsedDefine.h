//
//  CommonUsedDefine.h
//  jincheng
//
//  Created by csc on 14-3-12.
//  Copyright (c) 2014年 csc. All rights reserved.
//

#define IS_IOS_7 ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0)?YES:NO
#define IS_IOS_7_1 ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.1)?YES:NO

#define IS_IPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)


#define SCREENHIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width

//http://mapbar.ilutu.com:9090
#define YJDH_URL @"http://218.17.158.22:8181/ecar/tsp/"
#define YJDH_Get_PhoneNumer  @"uploadLocation?"
#define YJDH_Get_Location @"fetchDest?"

//#define HOST_IP @"192.168.0.240:8001"
#define HOST_IP @"119.145.230.122:8001"
#define PORT @"test"






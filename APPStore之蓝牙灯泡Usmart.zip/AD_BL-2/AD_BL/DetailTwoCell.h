//
//  DetailTwoCell.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/23.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTwoCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *TitleLabel;
@property (weak, nonatomic) IBOutlet UISwitch *Switch;

@end

//
//  DetailTwoCell.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/23.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "DetailTwoCell.h"

@implementation DetailTwoCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

//
//  GroupViewController.m
//  RESideMenuExample
//
//  Created by 3013 on 14-5-30.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "GroupViewController.h"
#import "PopupView.h"

#define IS_IOS_7 ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0)?YES:NO

@interface GroupViewController (){
    NSMutableDictionary *isSelectDic;
    NSMutableDictionary *lightNameArray;//灯和名称的对应关系
    NSUserDefaults *userDefaults;
}

@end

@implementation GroupViewController
@synthesize AllDataArray,cbCentralMgr;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    userDefaults = [NSUserDefaults standardUserDefaults];
    isSelectDic=[[NSMutableDictionary alloc]init];
    
    self.title=@"CreateGroup";
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"nav_Left.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(BackAction)];
    self.navigationItem.leftBarButtonItem.tintColor=[UIColor whiteColor];
    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"ok"] style:UIBarButtonItemStylePlain target:self action:@selector(selectOverAction)];
    self.navigationItem.rightBarButtonItem.tintColor=[UIColor whiteColor];
        
    lightNameArray=[[NSMutableDictionary alloc]initWithDictionary:[userDefaults objectForKey:@"lightNameArray"]];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}
-(void)BackAction{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//在此处确认是否有选择灯牌，若没选，则不让通过
-(void)selectOverAction{
    BOOL isSelectLight=NO;
    for (int i=0; i<[[isSelectDic allValues] count]; i++) {
        if ([[[isSelectDic allValues] objectAtIndex:i] intValue])
        {
            isSelectLight=YES;
            break;
        }
    }
    if (isSelectLight) {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:NSLocalizedStringFromTable(@"Notice", @"Localizable", nil) message:NSLocalizedStringFromTable(@"Rename_for_group", @"Localizable", nil) delegate:self cancelButtonTitle:NSLocalizedStringFromTable(@"Cancel", @"Localizable", nil) otherButtonTitles:NSLocalizedStringFromTable(@"OK", @"Localizable", nil), nil];
        alert.alertViewStyle=UIAlertViewStylePlainTextInput;
        [alert show];
        
    }else{
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"No Light Was Selected!" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
    }
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex){
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ADDGroupOpration" object:isSelectDic userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:buttonIndex],@"ISChangeName",[alertView textFieldAtIndex:0].text,@"name", nil]];
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return AllDataArray.count/2;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    char strcommand[8]={'A','T','#','F','L','S','0','0'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
    
    
    if (((CBPeripheral*)[AllDataArray objectAtIndex:indexPath.row*2]).state==2) {
        if ([[isSelectDic objectForKey:[NSNumber numberWithInt:(int)indexPath.row]] integerValue]) {
            [isSelectDic setObject:@"0" forKey:[NSNumber numberWithInt:(int)indexPath.row]];
        }else{
            [isSelectDic setObject:@"1" forKey:[NSNumber numberWithInt:(int)indexPath.row]];
        }
    }else{
        if ([AllDataArray count]/2>10) {
            int countConnected=0;
            for (int i=0; i<[AllDataArray count]/2; i++)
            {
                CBPeripheral * peripheral = [AllDataArray objectAtIndex:i*2];
                if (peripheral.state!=0)
                {
                    countConnected++;
                    if (countConnected>=10)
                    {
                        PopupView  *popUpView;
                        popUpView = [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
                        popUpView.ParentView = self.view;
                        [popUpView setText: NSLocalizedStringFromTable(@"Max_connect_number", @"Localizable", nil)];
                        [self.view addSubview:popUpView];
                        return;
                    }
                }
            }
        }
        [self.cbCentralMgr connectPeripheral:((CBPeripheral*)[AllDataArray objectAtIndex:indexPath.row*2]) options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
    }
    
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
    
    //点击完毕，立即恢复颜色
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellIdentifier = @"cell";
    UITableViewCell * cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    NSString *State=nil;
    CBPeripheral * peripheral=[AllDataArray objectAtIndex:indexPath.row*2];
    if (((CBPeripheral*)[AllDataArray objectAtIndex:indexPath.row*2]).state==0) {
        State=@"disconnected";
        cell.textLabel.textColor=[UIColor blackColor];
    }else if (((CBPeripheral*)[AllDataArray objectAtIndex:indexPath.row*2]).state==1){
        State=@"Connecting";
        cell.textLabel.textColor=[UIColor blueColor];
    }else{
        State=@"Connected";
        cell.textLabel.textColor=[UIColor blueColor];
    }
    
    NSString *nameStr=[NSString stringWithFormat:@"%@,%@  %@",[AllDataArray objectAtIndex:indexPath.row*2 + 1],[lightNameArray objectForKey:[peripheral.identifier UUIDString]]?[lightNameArray objectForKey:[peripheral.identifier UUIDString]]:NSLocalizedStringFromTable(@"twenty-Nine", @"Localizable", nil) ,State];
    
    
    
    
    cell.textLabel.text = nameStr;
//    cell.detailTextLabel.text = [((CBPeripheral*)[AllDataArray objectAtIndex:indexPath.row*2]).identifier UUIDString];
    if ([[isSelectDic objectForKey:[NSNumber numberWithInt:(int)indexPath.row]] integerValue]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

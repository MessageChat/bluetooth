//
//  LabelViewController.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/23.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LabelTextDelegate <NSObject>
-(void)getLabelText:(NSString *)labelStr;
@end

@interface LabelViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *MyLabelTextField;
@property (strong,nonatomic)NSString *LabelStr;

@property (nonatomic, weak) id<LabelTextDelegate> LabelDelegate;
@end

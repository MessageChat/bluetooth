//
//  LampsViewController.h
//  RESideMenuExample
//
//  Created by 3013 on 14-5-28.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LampsViewController :UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate,UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,UIActionSheetDelegate>

@property (strong,nonatomic)CBPeripheral * peripheralOpration;//一个灯时操作的蓝牙对象
@property (strong,nonatomic)NSMutableDictionary *openDic;//当前操作的分组

@end

//
//  LampsViewController.m
//  RESideMenuExample
//
//  Created by 3013 on 14-5-28.
//  Copyright (c) 2014年 Roman Efimov. All rights reserved.
//

#import "LampsViewController.h"
#import "SubCollectionsCell2.h"
#import "GroupViewController.h"
#import "PopupView.h"

#import "MMDrawerController.h"
#import "MMDrawerBarButtonItem.h"

#import "AppDelegate.h"
#import "MMNavigationController.h"
#import "MainCell.h"

#define SCREENHIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREENWIDTH [[UIScreen mainScreen] bounds].size.width

#define TRANSFER_CHARACTERISTIC_UUID_6    @"FFF6"
//#define rowcellCount 2

@interface LampsViewController ()
{
//    UIBarButtonItem *AllButton;//选择所有灯时的右侧导航按钮
    
    NSMutableArray *dataArray;//用于在all和group切换时保存所有蓝牙信息
    NSMutableArray *GroupArray;//用于在all和group切换时保存group信息
    NSMutableArray *lightConnectGroupArray;//灯和组的对应关系
    NSMutableDictionary *lightNameArray;//灯和名称的对应关系
    
    UISegmentedControl *segmentedContol;//分段控件
    
    NSMutableArray *AlreadyConnectedArray;//已经连过的数组
    
    NSUserDefaults *userDefaults;
    
    NSMutableArray *selectedArr;//二级列表是否展开状态
    NSMutableArray *GroupISOpenArray;//在分组界面操作的开关灯按钮对应关系。在最初的时候，是空的。在用户选择开关按钮之后，往里面增加删除元素，如果在里面则代表是关着的。
    
    BOOL isExit;
    
}

@property (strong,nonatomic) UITableView * tableViewPeripheral;//表视图

@property (strong,nonatomic) NSMutableArray *peripheralArray;//界面显示的数据源

@property (strong,nonatomic) CBCentralManager * cbCentralMgr;//蓝牙中心管理器


@end

@implementation LampsViewController
@synthesize peripheralOpration,openDic;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //蓝牙操作中心
    self.cbCentralMgr = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    self.cbCentralMgr.delegate=self;
    
    //标题
    self.title=NSLocalizedStringFromTable(@"LampsView_TITLE", @"Localizable", nil);
    //左导航栏按钮
    [self setupLeftMenuButton];
    //右导航栏按钮
//    AllButton=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStylePlain target:self action:@selector(seachAction)];
//    AllButton.tintColor=[UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = nil;
    
    //背景图片
    UIImageView *imaggeview=[[UIImageView alloc]initWithFrame:CGRectMake(0,64, SCREENWIDTH, SCREENHIGHT)];
    [imaggeview setImage:[UIImage imageNamed:@"bg_new"]];
    [self.view addSubview:imaggeview];
    
    //初始化tableview
    self.tableViewPeripheral=[[UITableView alloc]initWithFrame:CGRectMake(0,64, SCREENWIDTH, SCREENHIGHT-104) style:UITableViewStylePlain];
    self.tableViewPeripheral.dataSource=self;
    self.tableViewPeripheral.delegate=self;
    self.tableViewPeripheral.backgroundColor=[UIColor clearColor];
    self.tableViewPeripheral.separatorStyle=UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableViewPeripheral];
    
    //设置分段控件
    NSArray *segmentedArray = [[NSArray alloc]initWithObjects:NSLocalizedStringFromTable(@"LampsView_ALlLight", @"Localizable", nil),NSLocalizedStringFromTable(@"LampsView_Group", @"Localizable", nil),nil];
    segmentedContol = [[UISegmentedControl alloc]initWithItems:segmentedArray];
    segmentedContol.frame =CGRectMake(0, SCREENHIGHT-40, SCREENWIDTH, 40);
    segmentedContol.selectedSegmentIndex=0;
    [segmentedContol addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:segmentedContol];
    
    
    
    
    dataArray=[[NSMutableArray alloc] init];//用于在all和group切换时保存所有蓝牙信息
    GroupArray=[[NSMutableArray alloc]init];//用于在all和group切换时保存group信息
    selectedArr = [[NSMutableArray alloc] init];//二级列表是否展开状态
    openDic=[[NSMutableDictionary alloc]initWithCapacity:0];//当前操作的分组
    GroupISOpenArray=[[NSMutableArray alloc]initWithCapacity:0];//在分组界面操作的开关灯按钮对应关系。在最初的时候，是空的。在用户选择开关按钮之后，往里面增加删除元素，如果在里面则代表是关着的。
    self.peripheralArray = [[NSMutableArray alloc]initWithCapacity:0];//界面显示的数据源
    
    
    userDefaults = [NSUserDefaults standardUserDefaults];
    //获取所有分组对应关系
    lightConnectGroupArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"lightConnectGroup"]];
    lightNameArray=[[NSMutableDictionary alloc]initWithDictionary:[userDefaults objectForKey:@"lightNameArray"]];
    //已经连过的数组
    AlreadyConnectedArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"AlreadyConnected"]];
    
    
    //注册消息通知，接收分组返回的数据
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(ADDGroup:) name:@"ADDGroupOpration" object:nil];
    //给当前操作的蓝牙对象发送数据
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(sendBLEData:) name:@"BLEDataNotification" object:nil];
    //给所有灯发送数据
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(sendAllBLEData:) name:@"BLEAllDataNotification" object:nil];
    //发送音乐数据
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(sendMusicDataBLEData:) name:@"BLEMusicDataDataNotification" object:nil];
    
}

//给当前操作的蓝牙对象发送数据
-(void)sendBLEData:(NSNotification*) notification{
    if (segmentedContol.selectedSegmentIndex==1) {//分组灯
        if (openDic.count==0&&peripheralOpration!=nil) {
            NSLog(@"分组灯下的单个灯控制");
            [self sendDatawithperipheral:self.peripheralOpration characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:[[notification userInfo] objectForKey:@"tempData"] ];
        }else{
            NSArray *selectGroupArray=[openDic objectForKey:@"groupDic"];
            NSLog(@"分组数据openDic:%@",openDic);
            NSLog(@"向分组发送数据:%@",selectGroupArray);
            for (int i=0 ;i<[selectGroupArray count]; i++){//对每一个序号找到对应的蓝牙对象进行操作
                int m=[[selectGroupArray objectAtIndex:i] intValue];
                CBPeripheral *peripheral=[[openDic objectForKey:@"DataArray"] objectAtIndex:m];
                [self sendDatawithperipheral:peripheral characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:[[notification userInfo] objectForKey:@"tempData"] ];
            }
        }
        
    }else {//单个灯
        if (peripheralOpration.state==2){
            [self sendDatawithperipheral:self.peripheralOpration characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:[[notification userInfo] objectForKey:@"tempData"] ];
        }else{
            NSLog(@"没连接");
        }
    }
}

//给所有灯发送数据
-(void)sendAllBLEData:(NSNotification*) notification{
    NSLog(@"发送电源总开关蓝牙数据，dataArray:%@",dataArray);
    for (int i=0 ;i<[dataArray count]/2; i++)
    {
        CBPeripheral *peripheral=[dataArray objectAtIndex:i*2];
        [self sendDatawithperipheral:peripheral characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:[[notification userInfo] objectForKey:@"tempData"] ];
    }
    
}
//发送音乐数据
-(void)sendMusicDataBLEData:(NSNotification*) notification{
    NSLog(@"收到发送音乐数据通知");
    for (int i=0 ;i<[dataArray count]/2; i++){
        if([[dataArray objectAtIndex:i*2+1] rangeOfString:@"RGB"].location!=NSNotFound ||[[dataArray objectAtIndex:i*2+1] rangeOfString:@"LED"].location!=NSNotFound ){
            NSLog(@"发送音乐模式蓝牙数据");
            CBPeripheral *peripheral=[dataArray objectAtIndex:i*2];
            [self sendDatawithperipheral:peripheral characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:[[notification userInfo] objectForKey:@"tempData"] ];
        }
    }
}

//根据蓝牙对象和特性发送数据
-(void)sendDatawithperipheral:(CBPeripheral *)peripheral characteristic:(NSString*)characteristicStr data:(NSData*)data {
//    NSLog(@"发送data:%@",data);
    for(int i=0;i<peripheral.services.count;i++){
        for (CBCharacteristic *characteristic in [[peripheral.services objectAtIndex:i] characteristics]){
            //找到通信的的特性
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:characteristicStr]]){
                [peripheral setNotifyValue:YES forCharacteristic:characteristic];
                [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
            }
        }
    }
}
//处理分段控件事件
-(void)segmentAction:(UISegmentedControl *)Seg{
    NSInteger Index = Seg.selectedSegmentIndex;
    switch (Index){
        case 0:
            [self allButtonAction];
            break;
        case 1:
            [self groupButtonAction];
            break;
        default:
            break;
    }
}

//所有灯泡界面
-(void)allButtonAction{
    self.navigationItem.rightBarButtonItem=nil;
    self.peripheralArray=dataArray;
    NSLog(@"allButtonAction self.peripheralArray:%@",self.peripheralArray);
    [self.tableViewPeripheral reloadData];
}

//所有分组界面，切换到分组界面
-(void)groupButtonAction{
    //组模式时的右导航栏按钮
    UIBarButtonItem *GroupAddButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(groupAddAction)];
    GroupAddButton.tintColor=[UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = GroupAddButton;
    
    self.peripheralArray=[[NSMutableArray alloc]initWithArray:GroupArray];//显示分组信息
    NSLog(@"groupButtonAction self.peripheralArray:%@",self.peripheralArray);
    [self getGroupFromAllConnection];
    [self.tableViewPeripheral reloadData];
}

//右导航栏按钮，增加组方法，跳转到分组视图
-(void)groupAddAction{
    GroupViewController *groupView=[[GroupViewController alloc]init];
    groupView.AllDataArray=dataArray;
    groupView.cbCentralMgr=self.cbCentralMgr;
    [self.navigationController pushViewController:groupView animated:YES];
}

//响应分组视图返回时，传递的通知
-(void)ADDGroup:(NSNotification*) notification{
    NSDictionary *getDic=[[NSDictionary alloc]initWithDictionary:[notification object]];
    NSDictionary *userDic=[[NSDictionary alloc]initWithDictionary:[notification userInfo]];
    NSLog(@"响应创建分组:%@,%@",getDic,userDic);
    
    NSString *nameStr=[userDic objectForKey:@"name"];
    if(nameStr.length==0){
        nameStr=NSLocalizedStringFromTable(@"LampsView_NOName", @"Localizable", nil);
    }
    NSMutableArray *arrayTem=[[NSMutableArray alloc]init];//group页面打勾的数据
    [getDic enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop){
        if ([obj intValue])
        {
            CBPeripheral * peripheral =(CBPeripheral *) [dataArray objectAtIndex:[key integerValue]*2];
            if ([userDic objectForKey:@"ISChangeName"]) {
                [self ChangeGroupName:nameStr uuid:[peripheral.identifier UUIDString]];
                NSLog(@"ADDGroup====");
            }
            
            [arrayTem addObject:key];
        }
    }];
    
    self.peripheralArray=[[NSMutableArray alloc]initWithArray:GroupArray];//显示分组信息
    [self getGroupFromAllConnection];
    
    [self.tableViewPeripheral reloadData];//刷新表视图
}



-(void)seachAction{
    NSLog(@"搜索");
//    [self.cbCentralMgr stopScan];
    //将当前所有连接的蓝牙断开重新搜索
    for (int i=0; i<[dataArray count]; i=i+2) {
        CBPeripheral * peripheral=[dataArray objectAtIndex:i];
        if (peripheral.state!=0) {
            NSLog(@"取消连接:%@",peripheral.name);
            [self.cbCentralMgr cancelPeripheralConnection:peripheral];
        }
    }
    
    [self.peripheralArray removeAllObjects];
    [dataArray removeAllObjects];
    [self.tableViewPeripheral reloadData];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO],CBCentralManagerScanOptionAllowDuplicatesKey, nil];
    [self.cbCentralMgr scanForPeripheralsWithServices:nil options:dic];
    
}


#pragma mark - UITableViewDataSource
//返回几个表头
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (segmentedContol.selectedSegmentIndex==1) {//分组模式
        return self.peripheralArray.count;
    }else{
        return 1;
    }
}

//设置表头的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (segmentedContol.selectedSegmentIndex==1) {//分组模式
        return 60;
    }else{
        return 0;
    }
}
//展开或关闭分组
-(void)doButton:(UIButton *)sender
{
    NSString *string = [NSString stringWithFormat:@"%ld",(long)sender.tag-100];
    //数组selectedArr里面存的数据和表头想对应，方便以后做比较
    if ([selectedArr containsObject:string]){
        [selectedArr removeObject:string];
    }else{
        [selectedArr addObject:string];
    }
    [_tableViewPeripheral reloadData];
}

//选择某行分组
-(void)doGroup:(UIButton *)sender
{
    NSString *string = [NSString stringWithFormat:@"%ld",(long)sender.tag-200];
    NSLog(@"doGroup string：%@",string);
    openDic=[[NSMutableDictionary alloc]initWithDictionary:[self.peripheralArray objectAtIndex:sender.tag-200]];
    NSLog(@"openDic:%@",openDic);
    for (int i=0; i<[[openDic objectForKey:@"lightCellTem"] count]/2; i++) {
        NSString *deviceName=[[openDic objectForKey:@"lightCellTem"]  objectAtIndex:i*2+1];
        if ([deviceName rangeOfString:@"光"].location ==NSNotFound&&[deviceName rangeOfString:@"智能灯泡"].location ==NSNotFound&&[deviceName rangeOfString:@"Dim"].location ==NSNotFound&&[deviceName rangeOfString:@"Smart Bulb"].location ==NSNotFound) {
            //如果有一个是彩色灯，则跳到彩色界面了
            [[NSNotificationCenter defaultCenter] postNotificationName:@"MainPushNotification" object:nil];
            return;
        }
    }
    //循环完了都没有彩灯，则跳到白色界面
    UIViewController *MyWhiteVC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"WhiteLight"];
    [self.navigationController pushViewController:MyWhiteVC animated:YES];
}
//开关灯按钮事件
-(void)doSwitch:(UIButton *)sender
{
    NSMutableDictionary *groupDicData=[[NSMutableDictionary alloc]initWithDictionary:[self.peripheralArray objectAtIndex:sender.tag-1000]];
    NSArray *selectGroupArray=[groupDicData objectForKey:@"groupDic"];
    NSArray *LightGroupTempArray=[groupDicData objectForKey:@"lightIsOn"];
    
    char strcommand[8]={'A','T','#','L','E','1'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    
    if (![self CheckGroupLightIsOn:LightGroupTempArray]) {//当前是关着的，执行开操作
        strcommand[5] ='1';
    }else{//当前是开着的，执行关操作
        strcommand[5] ='0';
    }
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSMutableArray *MylightIsTemp=[[NSMutableArray alloc]init];
    for (int i=0 ;i<[selectGroupArray count]; i++)
    {
        //对每一个序号找到对应的蓝牙对象进行操作
        int m=[[selectGroupArray objectAtIndex:i] intValue];
        
        CBPeripheral *peripheral=[[groupDicData objectForKey:@"DataArray"] objectAtIndex:m];
        if ([self CheckGroupLightIsOn:LightGroupTempArray]) {//因为是关闭的，将其加入GroupISOpenArray
            [MylightIsTemp addObject:[NSNumber numberWithInt:0]];
            [GroupISOpenArray addObject:[peripheral.identifier UUIDString]];
        }else{
            [MylightIsTemp addObject:[NSNumber numberWithInt:1]];
            [GroupISOpenArray removeObject:[peripheral.identifier UUIDString]];
        }
        [self sendDatawithperipheral:peripheral characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:cmdData ];
    }
    
    if (MylightIsTemp.count>0) {
        [groupDicData setObject:MylightIsTemp forKey:@"lightIsOn"];
        NSLog(@"原数组：%@",self.peripheralArray);
        [self.peripheralArray replaceObjectAtIndex:sender.tag-1000 withObject:groupDicData];
        NSLog(@"更新数组：%@",self.peripheralArray);
        [_tableViewPeripheral reloadData];
    }
}
//分组界面的开关
-(void)doLightSwitch:(UIButton *)sender{
    NSMutableDictionary *groupDicData=[[NSMutableDictionary alloc]initWithDictionary:[self.peripheralArray objectAtIndex:sender.tag/1000]];
    CBPeripheral *peripheral=[[groupDicData objectForKey:@"lightCellTem"] objectAtIndex:(sender.tag%1000)*2];
    NSMutableArray *lightIsOnArrayTem=[groupDicData objectForKey:@"lightIsOn"];
    
    //    NSLog(@"%d,%d",sender.tag/1000,sender.tag%1000);
    char strcommand[8]={'A','T','#','L','E','1'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    
    if ([[lightIsOnArrayTem objectAtIndex:sender.tag%1000] boolValue]) {
        [lightIsOnArrayTem replaceObjectAtIndex:sender.tag%1000 withObject:[NSNumber numberWithInt:0]];
        strcommand[5] ='0';
        [GroupISOpenArray addObject:[peripheral.identifier UUIDString]];
    }else{
        [lightIsOnArrayTem replaceObjectAtIndex:sender.tag%1000 withObject:[NSNumber numberWithInt:1]];
        strcommand[5] ='1';
        [GroupISOpenArray removeObject:[peripheral.identifier UUIDString]];
    }
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    
    
    [self sendDatawithperipheral:peripheral characteristic:TRANSFER_CHARACTERISTIC_UUID_6 data:cmdData ];
    
    [groupDicData setObject:lightIsOnArrayTem forKey:@"lightIsOn"];
    [self.peripheralArray replaceObjectAtIndex:sender.tag/1000 withObject:groupDicData];
    [_tableViewPeripheral reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (segmentedContol.selectedSegmentIndex==0) {//所有灯模式
        return (self.peripheralArray.count/2-1)/2+1;
    }else{
        NSString *string = [NSString stringWithFormat:@"%ld",(long)section];
        
        if ([selectedArr containsObject:string]) {
//            NSLog(@"=====%@",[self.peripheralArray objectAtIndex:section]);
            return [[[self.peripheralArray objectAtIndex:section]objectForKey:@"groupDic"] count];
        }else{
            return 0;
        }
    }
}

//设置view，将替代titleForHeaderInSection方法
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSDictionary *groupDicData=[self.peripheralArray objectAtIndex:section];
    int seachedArrayNumber=0;
    int groupDicNumber=0;
    if ([groupDicData objectForKey:@"seachedArray"]!=nil) {
        seachedArrayNumber=(int)[[groupDicData objectForKey:@"seachedArray"] count];
    }
    if ([groupDicData objectForKey:@"groupDic"]!=nil) {
        groupDicNumber=(int)[[groupDicData objectForKey:@"groupDic"] count];
    }
    
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, 30)];
    view.backgroundColor = [UIColor colorWithRed:10/255.0 green:51/255.0 blue:134/255.0 alpha:1];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 15, tableView.frame.size.width-80, 30)];
    titleLabel.text = [NSString stringWithFormat:@"%@:%@%d%@,%@%d,%@%d",[groupDicData objectForKey:@"groupName"],NSLocalizedStringFromTable(@"LampsView_GroupOne", @"Localizable", nil),(int)[[groupDicData objectForKey:@"allGroupNumber"] count],NSLocalizedStringFromTable(@"LampsView_GroupTwo", @"Localizable", nil),NSLocalizedStringFromTable(@"LampsView_GroupThree", @"Localizable", nil),seachedArrayNumber,NSLocalizedStringFromTable(@"LampsView_GroupFour", @"Localizable", nil),groupDicNumber];
    titleLabel.textColor=[UIColor whiteColor];
    [view addSubview:titleLabel];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 22, 15, 15)];
    imageView.tag = 20000+section;
    
    //判断是不是选中状态
    NSString *string = [NSString stringWithFormat:@"%ld",(long)section];
    
    if ([selectedArr containsObject:string]) {
        imageView.image = [UIImage imageNamed:@"buddy_header_arrow_down@2x.png"];
    }else{
        imageView.image = [UIImage imageNamed:@"buddy_header_arrow_right@2x.png"];
    }
    [view addSubview:imageView];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 60, 60);
    button.tag = 100+section;
    [button addTarget:self action:@selector(doButton:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    
    UIButton *buttonGroup = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonGroup.frame = CGRectMake(60, 0, SCREENWIDTH-120, 60);
    buttonGroup.tag = 200+section;
    [buttonGroup addTarget:self action:@selector(doGroup:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:buttonGroup];
    
    UIImageView *lineImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 59, 320, 1)];
    lineImage.image = [UIImage imageNamed:@"line.png"];
    [view addSubview:lineImage];
    
    UIButton *buttonSwitch = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonSwitch.frame = CGRectMake(SCREENWIDTH-80, 0, 80, 60);
    if([self CheckGroupLightIsOn:[groupDicData objectForKey:@"lightIsOn"]]){
        [buttonSwitch setImage:[UIImage imageNamed:@"kaiguan-p-xiao.png"] forState:UIControlStateNormal];
    }else{
        [buttonSwitch setImage:[UIImage imageNamed:@"kaiguan-n-xiao.png"] forState:UIControlStateNormal];
    }
    
    buttonSwitch.tag = 1000+section;
    [buttonSwitch addTarget:self action:@selector(doSwitch:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:buttonSwitch];
    
    UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(cellPressAction:)];
    view.tag=section;
    [view addGestureRecognizer:longPress];
    return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (segmentedContol.selectedSegmentIndex==0) {//所有灯模式
        return 160;
    }else{
        return 60;
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (segmentedContol.selectedSegmentIndex==0) {
        return;
    }
    CBPeripheral * peripheral = [[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightCellTem"] objectAtIndex:indexPath.row*2];
    NSLog(@"++++++%@",[[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightCellTem"] objectAtIndex:indexPath.row*2]);
    
    if (peripheral.state==2) {
        
        peripheralOpration =peripheral;
        [openDic removeAllObjects];
        //NSLog(@"=========%@",[self.peripheralArray objectAtIndex:tag*2+1]);
        NSString *deviceName=[[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightCellTem"] objectAtIndex:indexPath.row*2+1];
        NSLog(@"已连接：%@",deviceName);
        if (deviceName.length==0) {
            NSLog(@"断开连接:%@",self.peripheralArray);
            return;
        }
        if ([deviceName rangeOfString:@"光"].location !=NSNotFound||[deviceName rangeOfString:@"智能灯泡"].location !=NSNotFound||[deviceName rangeOfString:@"Dim"].location !=NSNotFound||[deviceName rangeOfString:@"Smart Bulb"].location !=NSNotFound){
            
            UIViewController *MyWhiteVC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"WhiteLight"];
            [self.navigationController pushViewController:MyWhiteVC animated:YES];
        }else{
            NSLog(@"没有包含白灯");
            [[NSNotificationCenter defaultCenter] postNotificationName:@"MainPushNotification" object:nil];
        }
    }else{
        NSLog(@"=====未连接");
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (segmentedContol.selectedSegmentIndex==1) {//分组模式下
        NSString *indexStr = [NSString stringWithFormat:@"%ld",(long)indexPath.section];
        static NSString *CellIdentifier = @"MainCell";
        MainCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[MainCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
        
        if ([selectedArr containsObject:indexStr]) {
            
            CBPeripheral * peripheral=[[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightCellTem"] objectAtIndex:indexPath.row*2];
            NSString *nameStr=[NSString stringWithFormat:@"%@,%@",[[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightCellTem"] objectAtIndex:indexPath.row*2+1],[lightNameArray objectForKey:[peripheral.identifier UUIDString]]?[lightNameArray objectForKey:[peripheral.identifier UUIDString]]:NSLocalizedStringFromTable(@"twenty-Nine", @"Localizable", nil)];
            
            cell.nameLabel.text =nameStr ;
            
            [cell.buttonCellSwitch  addTarget:self action:@selector(doLightSwitch:) forControlEvents:UIControlEventTouchUpInside];
            cell.buttonCellSwitch.tag=indexPath.section*1000+indexPath.row;
            if ([[[[self.peripheralArray objectAtIndex:indexPath.section] objectForKey:@"lightIsOn"] objectAtIndex:indexPath.row] integerValue]) {
                [cell.buttonCellSwitch setImage:[UIImage imageNamed:@"kaiguan-p-xiao.png"] forState:UIControlStateNormal];
            }else{
                [cell.buttonCellSwitch setImage:[UIImage imageNamed:@"kaiguan-n-xiao.png"] forState:UIControlStateNormal];
            }
        }
        
        if (indexPath.row == dataArray.count-1) {
            cell.imageLine.image = nil;
        }else{
            cell.imageLine.image = [UIImage imageNamed:@"line.png"];
        }
        
        return cell;
    }else{
        static NSString *CellIdentifier1 = @"Cell1";
        SubCollectionsCell2 *cell =(SubCollectionsCell2 *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
        if (cell == nil){
            cell = [[SubCollectionsCell2 alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier1];
            cell.backgroundColor=[UIColor clearColor];
        }
        NSUInteger row=[indexPath row];
        for (NSInteger i = 0; i < 2; i++){
            //奇数，cell2需要刷新数据，需要设置隐藏
            if (row*2+i>self.peripheralArray.count/2-1){
                cell.cellView2.hidden=YES;
                break;
            }
            //如果是ALL模式下所有灯泡的操作，判断是CBPeripheral对象
            if ([[self.peripheralArray objectAtIndex:row*2*2 + i*2] isKindOfClass:[CBPeripheral class]]) {
                //获取单个灯泡的蓝牙对象
                CBPeripheral * peripheral=[self.peripheralArray objectAtIndex:row*2*2 + i*2];
                //单个灯泡第一个cell
                if (i==0){
                    if (peripheral.state==2){
                        [cell.cellView1.nameLabel setTextColor:[UIColor whiteColor]];
                        [cell.cellView1.titleLabel setTextColor:[UIColor whiteColor]];
                        [cell.cellView1.iconImageView setImage:[UIImage imageNamed:@"cell_blu"]];
                    }else{
                        [cell.cellView1.nameLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
                        [cell.cellView1.titleLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
                        [cell.cellView1.iconImageView setImage:[UIImage imageNamed:@"cell_gray"]];
                    }
                    [cell.cellView1.titleLabel setText:[self.peripheralArray objectAtIndex:row*2*2 + i*2+1] ];
                    NSString *nameStr=[NSString stringWithFormat:@"%@,%@",[self seachLightConnectGroup:[peripheral.identifier UUIDString]],[lightNameArray objectForKey:[peripheral.identifier UUIDString]]?[lightNameArray objectForKey:[peripheral.identifier UUIDString]]:NSLocalizedStringFromTable(@"twenty-Nine", @"Localizable", nil)];
                    
                    
                    [cell.cellView1.nameLabel setText:nameStr];
                    cell.cellView1.tag=8000+row*2 + i;
                    
                    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cellviewTaped:)];
                    [ cell.cellView1 addGestureRecognizer:tapRecognizer];
                    
                    UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAction:)];
                    [cell.cellView1 addGestureRecognizer:longPress];
                }else{//单个灯泡第二个cell
                    cell.cellView2.hidden=NO;
                    if (peripheral.state==2){
                        [cell.cellView2.nameLabel setTextColor:[UIColor whiteColor]];
                        [cell.cellView2.titleLabel setTextColor:[UIColor whiteColor]];
                        [cell.cellView2.iconImageView setImage:[UIImage imageNamed:@"cell_blu"]];
                    }else{
                        [cell.cellView2.nameLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
                        [cell.cellView2.titleLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
                        [cell.cellView2.iconImageView setImage:[UIImage imageNamed:@"cell_gray"]];
                    }
                    [cell.cellView2.titleLabel setText:[self.peripheralArray objectAtIndex:row*2*2 + i*2+1] ];
                    
                    NSString *nameStr=[NSString stringWithFormat:@"%@,%@",[self seachLightConnectGroup:[peripheral.identifier UUIDString]],[lightNameArray objectForKey:[peripheral.identifier UUIDString]]?[lightNameArray objectForKey:[peripheral.identifier UUIDString]]:NSLocalizedStringFromTable(@"twenty-Nine", @"Localizable", nil)];
                    [cell.cellView2.nameLabel setText:nameStr];
                    cell.cellView2.tag=8000+row*2+i;
                    
                    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cellviewTaped:)];
                    [ cell.cellView2 addGestureRecognizer:tapRecognizer];
                    
                    UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAction:)];
                    [cell.cellView2 addGestureRecognizer:longPress];
                }
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
}

//这里区分白灯，判断名字中是否包含”白“
-(void)cellviewTaped:(UITapGestureRecognizer *)recognizer{
    NSLog(@"cellviewTaped");
    int tag=(int)[recognizer view].tag-8000;
    if (tag<0) {
        //如果是分组
        tag=(int)[recognizer view].tag-1000;
        openDic=[NSMutableDictionary dictionaryWithDictionary:[self.peripheralArray objectAtIndex:tag]];

        [[NSNotificationCenter defaultCenter] postNotificationName:@"MainPushNotification" object:nil];
    }else{
        //如果是单个灯
        if (self.peripheralArray.count/2<tag+1) {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:NSLocalizedStringFromTable(@"LampsView_DeviceOntFound", @"Localizable", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            return;
        }
        
        CBPeripheral * peripheral = [self.peripheralArray objectAtIndex:tag*2];
        
        if (peripheral.state==2) {
            tag=(int)[recognizer view].tag-8000;
            peripheralOpration =[self.peripheralArray objectAtIndex:tag*2];
            [openDic removeAllObjects];
            NSLog(@"deviceName：%@",[self.peripheralArray objectAtIndex:tag*2+1]);
            NSString *deviceName=[self.peripheralArray objectAtIndex:tag*2+1];
            if ([deviceName rangeOfString:@"光"].location !=NSNotFound||[deviceName rangeOfString:@"智能灯泡"].location !=NSNotFound||[deviceName rangeOfString:@"Dim"].location !=NSNotFound||[deviceName rangeOfString:@"Smart Bulb"].location !=NSNotFound) {
                NSLog(@"是白灯");
                UIViewController *MyWhiteVC = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"WhiteLight"];
                [self.navigationController pushViewController:MyWhiteVC animated:YES];
            }else{
                NSLog(@"是彩灯");
                [[NSNotificationCenter defaultCenter] postNotificationName:@"MainPushNotification" object:nil];
            }
            
        }else{
            //未连接，判断当前连接数
            if ([dataArray count]/2>10) {
                int countConnected=0;
                for (int i=0; i<[dataArray count]/2; i++){
                    CBPeripheral * peripheral = [self.peripheralArray objectAtIndex:i*2];
                    if (peripheral.state!=0){
                        countConnected++;
                        if (countConnected>=10)
                        {
                            PopupView  *popUpView;
                            popUpView = [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
                            popUpView.ParentView = self.view;
                            [popUpView setText: NSLocalizedStringFromTable(@"Max_connect_number", @"Localizable", nil)];
                            [self.view addSubview:popUpView];
                            return;
                        }
                    }
                }
            }
            [self.cbCentralMgr connectPeripheral:peripheral options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
        }
    }
}

-(void)longPressAction:(UILongPressGestureRecognizer*)sender{
    NSLog(@"sender:%@",sender);
    if(UIGestureRecognizerStateBegan == sender.state) {
        UIAlertView *actionSheet=[[UIAlertView alloc]initWithTitle:nil message:NSLocalizedStringFromTable(@"LampsView_SetGroupName", @"Localizable", nil) delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil];
        actionSheet.alertViewStyle=UIAlertViewStylePlainTextInput;
        actionSheet.tag=[sender view].tag;
        [actionSheet show];
    }
}
-(void)cellPressAction:(UILongPressGestureRecognizer*)sender{
    
    if(UIGestureRecognizerStateBegan == sender.state) {
        UIActionSheet *actionSheet=[[UIActionSheet alloc]initWithTitle:NSLocalizedStringFromTable(@"Your_operation", @"Localizable", nil) delegate:self cancelButtonTitle:NSLocalizedStringFromTable(@"Cancel", @"Localizable", nil) destructiveButtonTitle:nil otherButtonTitles:NSLocalizedStringFromTable(@"Delete_Group", @"Localizable", nil),NSLocalizedStringFromTable(@"Batch_Rename", @"Localizable", nil), nil];
        actionSheet.tag=[sender view].tag;
        [actionSheet showInView:self.view];
    }
}

-(void)groupLongPressAction:(UILongPressGestureRecognizer*)sender{
    NSLog(@"sender:%@",sender);
    if(UIGestureRecognizerStateBegan == sender.state) {
        UIActionSheet *as=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedStringFromTable(@"Cancel", @"Localizable", nil) destructiveButtonTitle:nil otherButtonTitles:NSLocalizedStringFromTable(@"Delete", @"Localizable", nil), nil ];
        as.tag=[sender view].tag;
        [as showInView:self.view];
    }
}


#pragma mark ----------ActionSheet 按钮点击-------------
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
//    NSLog(@"用户点击的是第%d个按钮",buttonIndex);
    int tag=(int)actionSheet.tag-1000;
//    NSLog(@"tag:%d",tag);
    if(tag<0){
        NSLog(@"buttonIndex:%ld",(long)buttonIndex);
        if (buttonIndex==2) {
//            NSLog(@"quxiao");
        }else if (buttonIndex==1){
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:NSLocalizedStringFromTable(@"Batch_Rename", @"Localizable", nil) message:NSLocalizedStringFromTable(@"All_names_will_be", @"Localizable", nil) delegate:self cancelButtonTitle:NSLocalizedStringFromTable(@"Cancel", @"Localizable", nil) otherButtonTitles:NSLocalizedStringFromTable(@"OK", @"Localizable", nil), nil];
            alert.tag=actionSheet.tag;
            alert.alertViewStyle=UIAlertViewStylePlainTextInput;
            [alert show];
        }else{
            [lightConnectGroupArray removeObjectAtIndex:actionSheet.tag];
            [userDefaults setObject:lightConnectGroupArray forKey:@"lightConnectGroup"];
            [self groupButtonAction];
        }
        return;
    }
    
    switch (buttonIndex) {
        case 0:
            //照一张
        {
            //如果是临时分组,删除GroupArray中的对应元素，如果不是临时分组，删除对应的
            NSLog(@"self.peripheralArray:%@",self.peripheralArray );
            
            
            NSLog(@"groupName:%@",[[self.peripheralArray objectAtIndex:tag] objectForKey:@"groupName"]);
            NSLog(@"lightConnectGroupArray:%@",lightConnectGroupArray);
            for (int i=0; i<lightConnectGroupArray.count; i++) {
                if ([[[lightConnectGroupArray objectAtIndex:i] objectForKey:@"groupName"] isEqualToString:[[self.peripheralArray objectAtIndex:tag] objectForKey:@"groupName"]]) {
                    [lightConnectGroupArray removeObjectAtIndex:i];
                }
            }
            //加入新分组
            [userDefaults setObject:lightConnectGroupArray forKey:@"lightConnectGroup"];
            [self.peripheralArray removeObjectAtIndex:tag];
            NSLog(@"加入新分组 self.peripheralArray:%@",self.peripheralArray);
            [self.tableViewPeripheral reloadData];
            
        }
            break;
        default:
            break;
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==100){
//        NSLog(@"退出");
        if (isExit) {
            exit(0);
        }else{
            
        }
        return;
    }
    if (!buttonIndex) {
        return;
    }
    NSString *str=[alertView textFieldAtIndex:0].text;
    int tag=(int)alertView.tag-8000;
    if (tag<0) {
        NSLog(@"分组一键改名");
        if(str.length==0){
            str=NSLocalizedStringFromTable(@"LampsView_NOName", @"Localizable", nil);
        }
        NSArray *getDic=[[self.peripheralArray objectAtIndex:alertView.tag] objectForKey:@"allGroupNumber"];
        
        for (int i=0; i<getDic.count; i++) {
            [self ChangeGroupName:str uuid:[getDic objectAtIndex:i]];
        }
        NSLog(@"alertView delegate");
        self.peripheralArray=[[NSMutableArray alloc]initWithArray:GroupArray];//显示分组信息
        [self getGroupFromAllConnection];
        
        [self.tableViewPeripheral reloadData];//刷新表视图
    }else{
        NSLog(@"进入单个灯改名");
        if (self.peripheralArray.count<tag+1) {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:NSLocalizedStringFromTable(@"LampsView_DeviceOntFound", @"Localizable", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
            return;
        }
        
        CBPeripheral * peripheral = [self.peripheralArray objectAtIndex:tag*2];
        [lightNameArray setObject:str forKey:[peripheral.identifier UUIDString]];
        [userDefaults setObject:lightNameArray forKey:@"lightNameArray"];
        [self.tableViewPeripheral reloadData];
    }
    
    
}
-(void)ChangeGroupName:(NSString*)name uuid:(NSString*)uuid{
    //查找当前是否已经对这个灯分过组，已分组则移除之前的分组
    [self deleteLightConnectGroup:uuid];
    
    //加入新分组
    for (int i=0; i<[lightConnectGroupArray count]; i++) {
        
        if ([[[lightConnectGroupArray objectAtIndex:i] objectForKey:@"groupName"] isEqualToString:name]) {
            
            NSMutableDictionary *dic=[[NSMutableDictionary alloc]initWithDictionary:[lightConnectGroupArray objectAtIndex:i]];
            
            NSMutableArray *array=[[NSMutableArray alloc]initWithArray:[dic objectForKey:@"uuidArray"]];
            [array addObject:uuid];
            
            [dic setObject:array forKey:@"uuidArray"];
            
            [lightConnectGroupArray replaceObjectAtIndex:i withObject:dic];
            
            [userDefaults setObject:lightConnectGroupArray forKey:@"lightConnectGroup"];
            
            [self.tableViewPeripheral reloadData];
            return;
        }
    }
    //如果没分过，则新增
    NSMutableArray *array=[[NSMutableArray alloc]initWithObjects:uuid, nil];
    NSDictionary *dicTem=[[NSDictionary alloc]initWithObjectsAndKeys:array,@"uuidArray",name,@"groupName",[NSNumber numberWithInteger:[lightConnectGroupArray count]],@"groupID",nil];
    [lightConnectGroupArray addObject:dicTem];
    [userDefaults setObject:lightConnectGroupArray forKey:@"lightConnectGroup"];
    
}
//根据uuid删除之前的分组
-(void)deleteLightConnectGroup:(NSString*)uuid{
    for (int i=0; i<[lightConnectGroupArray count]; i++) {
        NSMutableDictionary *dic=[lightConnectGroupArray objectAtIndex:i];
        NSMutableArray *array=[[NSMutableArray alloc]initWithArray:[dic objectForKey:@"uuidArray"]];
        NSLog(@"array:%@",array);
        for (int j=0; j<[array count]; j++) {
            NSLog(@"[array objectAtIndex:j]:%@,uuid:%@",[array objectAtIndex:j],uuid);
            if ([[array objectAtIndex:j] isEqualToString:uuid]) {
                [array removeObjectAtIndex:j];

                if ([array count]) {
                    NSLog(@"Array:%@",array);
                    [dic setObject:array forKey:@"uuidArray"];
                    [lightConnectGroupArray replaceObjectAtIndex:i withObject:dic];
                }else{
                    [lightConnectGroupArray removeObjectAtIndex:i];
                }
            }
        }
    }
    NSLog(@"over");
}

//根据uuid查找到分组名
-(NSString*)seachLightConnectGroup:(NSString*)uuid{
    for (int i=0; i<[lightConnectGroupArray count]; i++) {
        NSArray *array=[[lightConnectGroupArray objectAtIndex:i] objectForKey:@"uuidArray"];
        for (int j=0; j<[array count]; j++) {
            if ([[array objectAtIndex:j] isEqualToString:uuid]) {
                return [[lightConnectGroupArray objectAtIndex:i] objectForKey:@"groupName"];
            }
        }
    }
    return NSLocalizedStringFromTable(@"LampsView_NOName", @"Localizable", nil) ;
}

//获取当前时间
- (NSString *)getCurrentTime
{
    NSDate *dateNow = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat : @"MM-dd HH:mm"];
    return  [formatter stringFromDate:dateNow];
}
#pragma mark - CBCentralManagerDelegate
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBCentralManagerStateUnsupported:
            {
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"State Unsupported！" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                [alert show];
                [self addLog:@"State Unsupported"];
            }
            break;
        case CBCentralManagerStatePoweredOff:
            [self addLog:@"State PoweredOff"];
        {
            isExit=YES;
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:NSLocalizedStringFromTable(@"AlertExit", @"Localizable", nil) delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            alert.tag=100;
            alert.delegate=self;
            [alert show];
        }
            break;
        case CBCentralManagerStatePoweredOn:
        {
//            NSLog(@"蓝牙已开启");
            isExit=NO;
//            UIAlertView *alertview = (UIAlertView *)[self.view viewWithTag:100];
//            NSLog(@"%@",alertview);
//            [alertview dismissWithClickedButtonIndex:0 animated:YES];
//            [alertview removeFromSuperview];
            [self seachAction];
        }
            break;
        default:
//            [self addLog:@"本设备支持蓝牙"];
            break;
    }
}
-(void)addLog:(NSString*)log{
//    NSLog(@"%@",log);
}

//1.发现设备，判断是否为优莱科产品   2.判断是否已存在相同UUID    3.判断属于哪一种类型  4.是否是已连接过的产品
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
//    NSLog(@"发现设备广播:%@",advertisementData);
    NSLog(@"发现设备:%@",peripheral.name);
    NSString *ADUUIDSTr=[[[advertisementData objectForKey:@"kCBAdvDataServiceUUIDs"] objectAtIndex:0] UUIDString];
    if (!([ADUUIDSTr hasPrefix:@"AD"]||[[advertisementData objectForKey:@"kCBAdvDataLocalName"]  hasPrefix:@"ULK"]||[[advertisementData objectForKey:@"kCBAdvDataLocalName"]  hasPrefix:@"SmartBulb"])) {
//        NSLog(@"收到不属于本公司的蓝牙4.0设备：%@",peripheral.name);
        return;
    }
    
    for (int i=0;i<dataArray.count;i=i+2) {
        if ([dataArray objectAtIndex:i]==peripheral) {
            return;
        }
    }
    
    [dataArray addObject:peripheral];
    
    if ([ADUUIDSTr hasSuffix:@"387"]) {//903  音乐灯泡  Music Bulb  （彩灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_Music_Bulb", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"38E"]){//910  智能音乐树Smart Tree （彩灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_Fibre_Optic_Tree", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"399"]){//921 音乐灯具 Music Lamps  （彩灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_Downlight", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"39B"]){//923 调光电源 Dimming Power （白灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"For_White_LED", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"39F"]){//927 RGB电源 RGB Power（彩灯，发送音乐数据）
        [dataArray addObject:NSLocalizedStringFromTable(@"For_RGB_LED", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"39C"]){//924 白炽灯调光器 Incandescent Lamp Dimmer （白灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_Filament_Lamp", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"39D"]){//925 智能灯泡 Smart Bulb （白灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_Lighting_Bulb", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"39E"]){//926 智能RGB灯泡  Smart RGB Bulb（彩灯，发送音乐数据）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_RGB_Bulb", @"Localizable", nil)];
    }else if ([ADUUIDSTr hasSuffix:@"3A0"]){//928 灯带控制器 LED Strip Controller    （彩灯）
        [dataArray addObject:NSLocalizedStringFromTable(@"Usmart_LED_Strip_Light_Controller", @"Localizable", nil)];
    }else{
        [dataArray addObject:peripheral.name];
    }
    
    
    
    [self thisLightGroupName:peripheral.name uuid:[peripheral.identifier UUIDString]];
    
    //如果当前是
    if (segmentedContol.selectedSegmentIndex==0) {
        //如果是ALL灯泡界面将当泡信息更新到界面
        self.peripheralArray=dataArray;
        if([AlreadyConnectedArray indexOfObject:[peripheral.identifier UUIDString]] != NSNotFound){
            [self.cbCentralMgr connectPeripheral:peripheral options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
        }
        
        [self.tableViewPeripheral reloadData];
    }else{
        //如果是group模式，将最新信息刷新到group界面
    }
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"设备已连接:%@",peripheral.name);
    if([AlreadyConnectedArray indexOfObject:[peripheral.identifier UUIDString]] == NSNotFound){
        [AlreadyConnectedArray addObject:[peripheral.identifier UUIDString]];
        [userDefaults setObject:AlreadyConnectedArray forKey:@"AlreadyConnected"];
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            char strcommand1[9]={'A','T','#','A','*','*','*','*','*'};
            strcommand1[4] = 0;
            strcommand1[5] = 0;
            strcommand1[6] = 0;
            strcommand1[7] =0X0D;
            strcommand1[8] =0X0A;
            NSData *cmdData1 = [NSData dataWithBytes:strcommand1 length:9];
            NSDictionary *dic1=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData1,@"tempData",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic1];
            [NSThread sleepForTimeInterval:0.5];
            char strcommand2[9]={'A','T','#','A','*','*','*','*','*'};
            strcommand2[4] = 255;
            strcommand2[5] = 255;
            strcommand2[6] = 255;
            strcommand2[7] =0X0D;
            strcommand2[8] =0X0A;
            NSData *cmdData2 = [NSData dataWithBytes:strcommand2 length:9];
            NSDictionary *dic2=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData2,@"tempData",nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic2];
        });
        
        
        
    }
    [self.tableViewPeripheral reloadData];
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    [self addLog:@"失去连接"];
//    segmentedContol.selectedSegmentIndex=0;
//    [self allButtonAction];
//    NSLog(@"断开连接：%@",peripheral.name);
//    [self.tableViewPeripheral reloadData];
//    PopupView  *popUpView;
//    popUpView = [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
//    popUpView.ParentView = self.view;
//    [popUpView setText: NSLocalizedStringFromTable(@"FOUR", @"Localizable", nil)];
//    [self.view addSubview:popUpView];
    
    [central connectPeripheral:peripheral options:nil];
}


//返回的蓝牙特征值通知代理
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
//    [self addLog:@"获取到设备特性"];
    NSLog(@"获取到设备特性:%@",peripheral.name);
    for (CBCharacteristic * characteristic in service.characteristics) {
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID_6]])
        {
//            NSLog(@"发送开机指令------");
            char strcommand[8]={'A','T','#','O','N','0','*','*'};
            strcommand[6] =0X0D;
            strcommand[7] =0X0A;
            NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
            
            [peripheral writeValue:cmdData forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
        }
    }
    
    
}


//peripheral:didUpdateValueForCharacteristic:error
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
//    NSLog(@"%@读取到值，接收到数据：%@",peripheral.name,characteristic);
    NSString *str=[[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];
//    NSLog(@"特性的值：%@",str);
    if ([str rangeOfString:@"Mode"].location!=NSNotFound) {
//        NSLog(@"响铃");
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ShowModeNotification" object:str];
    }
    
    if ([[str substringToIndex:5] isEqualToString:@"UL007"]) {
        //发送开机指令
        for (CBCharacteristic * characteristic in [[peripheral.services objectAtIndex:1] characteristics]) {
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID_6]])
            {
                //发送当前时间与以往定时
                [peripheral writeValue:[self SendNowTime] forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
                
                NSMutableArray *ClockDataArray=[[NSMutableArray alloc]initWithArray:[userDefaults objectForKey:@"ClockDataData"]];
                for (NSInteger i=0; i<[ClockDataArray count]; i++) {
//                    NSLog(@"-------%@",[ClockDataArray objectAtIndex:i]);
                    
                    //如果开关是开着，代表是有效的闹钟
                    if([[[ClockDataArray objectAtIndex:i] objectForKey:@"type"] boolValue]){
                        
                        //判断是否是单次闹钟
                        NSArray *WeekArray=[[[[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] objectAtIndex:1] objectAtIndex:0] objectForKey:@"Data"];
                        int n=0;//一周有多少天
                        for (NSInteger i=0; i<7; i++) {
                            if([[WeekArray objectAtIndex:i] boolValue]){
                                n++;
                            }
                        }
                        if (n) {
                            //如果不是单次闹钟
                            [self addLocalNotification:[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] ClockID:i];
                        }else{
                            //如果是单次闹钟
                            NSDate *localDate=[[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] objectAtIndex:2];
                            NSLog(@"[localDate timeIntervalSinceNow]:%f",[localDate timeIntervalSinceNow]);
                            //判断闹钟时间是否过期
                            if([localDate timeIntervalSinceNow]<0){
                                //已过期
                                NSMutableDictionary *ClockDic=[[NSMutableDictionary alloc]initWithDictionary:[ClockDataArray objectAtIndex:i]];
                                NSMutableDictionary *dataClockArray=[[NSMutableDictionary alloc]initWithDictionary:[ClockDic objectForKey:@"dataArray"]];
                                //改变本地数据
                                [ClockDic setObject:@"0" forKey:@"type"];
                                [dataClockArray setObject:[NSNumber numberWithBool:NO] forKey:@"Switch"];
                                [ClockDic setObject:dataClockArray forKey:@"dataArray"];
                                
                                [ClockDataArray removeObjectAtIndex:i];
                                [ClockDataArray addObject:ClockDic];
                                [userDefaults setObject:ClockDataArray forKey:@"ClockDataData"];
                                i--;
                            }else{
                                //未过期
                                [self addLocalNotification:[[ClockDataArray objectAtIndex:i] objectForKey:@"selectArray"] ClockID:i];
                            }
                        }
                        
                        
                    }else{
                        //开关是关着的，不能在此处排序，否则会死循环
                        break;
                    }
                }
            }
        }
    }
}
-(NSData *)SendNowTime{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *nowDate=[NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    comps = [calendar components:unitFlags fromDate:nowDate];
    NSInteger week = [comps weekday];
    if (week==1) {
        week=7;
    }else{
        week--;
    }
    //Week:1 －－星期天 2－－星期一 3－－星期二 4－－星期三 5－－星期四 6－－星期五 7－－星期六
    
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"HH"];
    int n2=[[dateformat stringFromDate:nowDate] intValue];
    [dateformat setDateFormat:@"mm"];
    int n3=[[dateformat stringFromDate:nowDate] intValue];
    [dateformat setDateFormat:@"ss"];
    int n4=[[dateformat stringFromDate:nowDate] intValue];
    NSInteger  n1=(week<<5)|n2;
    
    char strcommand[9]={'A','T','#','D','*','*','*','0','0'};
    strcommand[4] = n1;
    strcommand[5] = n3;
    strcommand[6] = n4;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    return cmdData;
}
//重新发送闹钟方法执行入口
-(void)addLocalNotification:(NSArray *)dataClockArray ClockID:(NSInteger)clockID{
    
    //    NSLog(@"dataArray:%@",dataArray);
    NSDate *localDate=[dataClockArray objectAtIndex:2];
    NSArray *WeekArray=[[[dataClockArray objectAtIndex:1] objectAtIndex:0] objectForKey:@"Data"];
    
    int n=0;//一周有多少天
    int weakO=0;//对周进行位运算的结果
    for (NSInteger i=0; i<7; i++) {
        if([[WeekArray objectAtIndex:i] boolValue]){
            weakO=weakO|(1<<i);
            NSLog(@"weakO:%d",weakO);
            n++;
        }
    }
    
    
    if (n) {
        n=1;//有重复
    }
    
    NSInteger  n1=(clockID<<3)|(n<<2)|(1<<1)|1;
    NSDateFormatter *dateformat = [[NSDateFormatter alloc] init];
    [dateformat setDateFormat:@"HH"];
    int n2=[[dateformat stringFromDate:localDate] intValue];
    [dateformat setDateFormat:@"mm"];
    int n3=[[dateformat stringFromDate:localDate] intValue];
    
    char strcommand[9]={'A','T','#','T','*','*','*','*','*'};
    strcommand[4] = n1;
    strcommand[5] = n2;
    strcommand[6] = n3;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
    //发送星期
    if (n) {
        //        AT#FFxx  Send（“AT#FF”,第几个闹钟,星期几, “\r\n”）；//星期1-5发送B00011111=0x1F.
        char strcommand1[9]={'A','T','#','F','F','*','*','*','*'};
        strcommand1[5] = clockID;
        strcommand1[6] = weakO;
        strcommand1[7] =0X0D;
        strcommand1[8] =0X0A;
        NSData *cmdData1 = [NSData dataWithBytes:strcommand1 length:9];
        NSDictionary *dic1=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData1,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic1];
    }
    
    
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
//    NSLog(@"%@写数据:%@",peripheral.name,characteristic.value);
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
//    [self addLog:@"收到特性状态的更新通知"];
}

//返回的蓝牙服务通知通过代理
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
//    [self addLog:@"发现蓝牙服务，启动特性搜索"];
    for (CBService* service in peripheral.services)
    {
        //查询服务所带的特征值
        [peripheral discoverCharacteristics:nil forService:service];
        //获取设备信息，保留，以后可能用到
        [peripheral discoverIncludedServices:nil forService:service];
    }
}
//与当前所有数组中的uuid比较，如果存在，则不添加，如果不存在，则添加到本地保存
-(void )thisLightGroupName:(NSString *)name uuid:(NSString *)uuidStr{
    NSLog(@"thisLightGroupName,%@,%@",name,uuidStr);
    NSMutableArray *allLightArray=[userDefaults objectForKey:@"allLight"];//用于实时获取搜索到得数据
    NSLog(@"allLightArray:%@",allLightArray);
    for (int i=0; i<[allLightArray count]; i++)
    {
        if ([[allLightArray objectAtIndex:i] objectForKey:@"uuid"]==uuidStr)
        {
            return ;
        }
    }
    NSDictionary *dicTem=[[NSDictionary alloc]initWithObjectsAndKeys:name,@"name",uuidStr,@"uuid", nil];
    [allLightArray addObject:dicTem];
    [userDefaults setObject:allLightArray forKey:@"allLight"];
}

//进入Group模式时，将对应关系数组添加到group数组后面作为固定部分组成显示数据源
-(void)getGroupFromAllConnection{
    
    for (int i=0; i<[lightConnectGroupArray count]; i++)
    {
        //组内所有成员UUIDArray数组
        NSArray *uuidArray=[[lightConnectGroupArray objectAtIndex:i] objectForKey:@"uuidArray"];
        //搜索到的uuid在所有灯泡中的序号数组,找到当前组中有的灯的蓝牙对象
        NSDictionary *arrayTem=[self arrayFromUUIDArray:uuidArray];
        
//        NSLog(@"----uuidArray:%@,%@",uuidArray,arrayTem);
        
        
        
        //如果搜索到有
        if ([arrayTem count])
        {
            //groupDic保存已连接的数组，seachedArray被搜索到的数组，allGroupNumber组内总成员数组
            NSMutableDictionary *groupMember=[[NSMutableDictionary alloc]initWithObjectsAndKeys:[[lightConnectGroupArray objectAtIndex:i] objectForKey:@"groupName"],@"groupName",[arrayTem objectForKey:@"groupDic"],@"groupDic",dataArray,@"DataArray",[arrayTem objectForKey:@"lightCellTem"],@"lightCellTem",[arrayTem objectForKey:@"seachedArray"],@"seachedArray",uuidArray,@"allGroupNumber",[arrayTem objectForKey:@"lightIsOn"],@"lightIsOn",nil];
            [self.peripheralArray addObject:groupMember];//将数据加入到显示数据源
        }
    }
    NSLog(@"getGroupFromAllConnection self.peripheralArray:%@",self.peripheralArray);
//    NSLog(@"getGroupFromAllConnection:%@",self.peripheralArray);
}
//组中只要有一个灯是开着的，组就是开着的,返回YES
-(BOOL)CheckGroupLightIsOn:(NSArray *)lightIsOnArray{
//    NSLog(@"lightIsOnArray:%@",lightIsOnArray);
    for (int i=0; i<[lightIsOnArray count]; i++) {
        if ([[lightIsOnArray objectAtIndex:i] boolValue] ) {
            return YES;
        }
    }
    return NO;
}
//将uuid数组返回对应于dataArray中的序号，已设定dataArray不会在失去连接时移除数组，只在重新搜索时移除
-(NSDictionary*)arrayFromUUIDArray:(NSArray*)uuidArray{
    //如果某个分组的灯都被删除，加入到了其他分组
    if ([uuidArray count]==0) {
        return nil;
    }
    //groupDicTem保存已连接的数组，seachedArrayTem被搜索到的数组
    NSMutableArray *groupDicTem=[[NSMutableArray alloc]initWithCapacity:0];
    NSMutableArray *seachedArrayTem=[[NSMutableArray alloc]initWithCapacity:0];
    NSMutableArray *lightIsOnArrayTem=[[NSMutableArray alloc]initWithCapacity:0];
    NSMutableArray *lightCellTem=[[NSMutableArray alloc]initWithCapacity:0];
//    NSLog(@"uuidArray:%@",uuidArray);
//    NSLog(@"dataArray:%@",dataArray);
    
    //找到序号数组
    for (int i=0; i<[uuidArray count]; i++) {
        for (int j=0; j<[dataArray count]; j=j+2) {
            CBPeripheral * peripheral=[dataArray objectAtIndex:j];
            if ([[uuidArray objectAtIndex:i] isEqualToString:[peripheral.identifier UUIDString]]) {
//                NSLog(@"搜索到：%@,%@",[uuidArray objectAtIndex:i],[peripheral.identifier UUIDString]);
                //找到相等的UUID，即加入seachedArrayTem
                [seachedArrayTem addObject:[NSNumber numberWithInt:j]];
                //如果是连接状态，加入groupDicTem
                if (peripheral.state==2) {
                    [groupDicTem addObject:[NSNumber numberWithInt:j]];
                    if ([GroupISOpenArray indexOfObject:[uuidArray objectAtIndex:i]]==NSNotFound) {
                        [lightIsOnArrayTem addObject:[NSNumber numberWithInt:1]];//开着的
                    }else{
                        [lightIsOnArrayTem addObject:[NSNumber numberWithInt:0]];//关着的
                    }
                    [lightCellTem addObject:peripheral];
                    [lightCellTem addObject:[dataArray objectAtIndex:j+1]];
                }
            }
        }
    }
    
    //groupDic保存已连接的数组，seachedArray被搜索到的数组
    NSDictionary *returnDic=[[NSDictionary alloc]initWithObjectsAndKeys:groupDicTem,@"groupDic",seachedArrayTem,@"seachedArray",lightIsOnArrayTem, @"lightIsOn",lightCellTem,@"lightCellTem",nil];
//    NSLog(@"lightIsOnArrayTem:%@",lightIsOnArrayTem);
    return returnDic;
}

#pragma mark - Button Handlers
-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}
-(MMDrawerController*)mm_drawerController{
    UIViewController *parentViewController = self.parentViewController;
    while (parentViewController != nil) {
        if([parentViewController isKindOfClass:[MMDrawerController class]]){
            return (MMDrawerController *)parentViewController;
        }
        parentViewController = parentViewController.parentViewController;
    }
    return nil;
}
-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
@end

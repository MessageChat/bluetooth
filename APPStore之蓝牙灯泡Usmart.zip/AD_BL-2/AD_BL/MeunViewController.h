//
//  MeunViewController.h
//  Foodspotting
//
//  Created by jetson  on 12-8-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeunViewController :UIViewController{
    NSMutableArray *list;
    NSMutableArray *imageList;
}
@property (weak, nonatomic) IBOutlet UIButton *powerButton;
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (assign, nonatomic)BOOL ISConnected;

- (IBAction)openOrClosePower:(id)sender;
-(void)ConectedAction;
@end

//
//  MeunViewController.m
//  Foodspotting
//
//  Created by jetson  on 12-8-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MeunViewController.h"
#import "DDMenuController.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "TableViewCell.h"
#import "MMDrawerController.h"
#import "MMNavigationController.h"

#import "MusicViewController.h"
#import "LampsViewController.h"
#import "ClockViewController.h"
#import "PopupView.h"

@interface MeunViewController (){
    NSInteger selectedId;
    NSIndexPath *lastCellIndexPath;
    NSUserDefaults *userDefaults;
    
    MusicViewController *misicViewController;
    
    ClockViewController *clockViewContrller;
    
    LampsViewController *lampsController;
    
}

@end

@implementation MeunViewController
@synthesize myTableView,ISConnected;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	userDefaults= [NSUserDefaults standardUserDefaults];
    
	list = [[NSMutableArray alloc]init];
   
    
    [list addObject:NSLocalizedStringFromTable(@"LISTOBJ1", @"Localizable", nil)];
    [list addObject:NSLocalizedStringFromTable(@"LISTOBJ2", @"Localizable", nil)];
    [list addObject:NSLocalizedStringFromTable(@"LISTOBJ4", @"Localizable", nil)];
    [list addObject:NSLocalizedStringFromTable(@"LISTOBJ3", @"Localizable", nil)];
    
    
    imageList =[[NSMutableArray alloc] initWithObjects:@"LED-N",@"yingyue-n",@"naozhong-n",@"lanyalian-n",@"LED-P",@"yingyue-P",@"naozhong-P",@"lanyalian-P",nil];
    
    lastCellIndexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    [myTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
    [myTableView deselectRowAtIndexPath:lastCellIndexPath animated:YES];
    
    misicViewController=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"musicViewController"];
    
    clockViewContrller=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"clockViewController"];
    
    lampsController=[[LampsViewController alloc]init];
    
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(MainPushAction) name:@"MainPushNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(DevicePushAction) name:@"DevicePushNotification" object:nil];
}
//-(void)BLEDisConnectAction:(NSNotification*)notification{
//    NSIndexPath *lastindexPath=[NSIndexPath indexPathForRow:3 inSection:0];
//    [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastindexPath]withRowAnimation:UITableViewRowAnimationFade];
//}
-(void)MainPushAction{
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    if (lastCellIndexPath&&selectedId!=indexPath.row) {
        selectedId=indexPath.row;
        [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastCellIndexPath]withRowAnimation:UITableViewRowAnimationNone];
    }
    lastCellIndexPath=indexPath;
    [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
    
    MMDrawerController *drawerController = (MMDrawerController*)((AppDelegate *)[[UIApplication sharedApplication] delegate]).drawerController;
    UIViewController *myViewController=((AppDelegate *)[[UIApplication sharedApplication] delegate]).viewController;
    UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:myViewController];
    [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
    
}
-(void)DevicePushAction{
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:3 inSection:0];
    if (lastCellIndexPath&&selectedId!=indexPath.row) {
        selectedId=indexPath.row;
        [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastCellIndexPath]withRowAnimation:UITableViewRowAnimationNone];
    }
    lastCellIndexPath=indexPath;
    [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationNone];
    
    MMDrawerController *drawerController = (MMDrawerController*)((AppDelegate *)[[UIApplication sharedApplication] delegate]).drawerController;
    UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:lampsController];
    [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
}
-(void)viewDidAppear:(BOOL)animated{
    
}

//改变行的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 72;
}
//返回TableView中有多少数据
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [list count];
    
}
//返回有多少个TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
//组装每一条的数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CustomCellIdentifier =@"CellIdentifier";
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: CustomCellIdentifier];
    if (cell ==nil) {
		cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CustomCellIdentifier];
    }
	cell.titleLabel.text = [list objectAtIndex:indexPath.row];
    if (indexPath.row==selectedId) {
        cell.titleImage.image = [UIImage imageNamed:[imageList objectAtIndex:indexPath.row+4]];
        cell.selectedBG.hidden=NO;
        
    }else{
        cell.titleImage.image = [UIImage imageNamed:[imageList objectAtIndex:indexPath.row]];
        cell.selectedBG.hidden=YES;
    }
//    if (indexPath.row==3) {
//        if (ISConnected) {
////            NSLog(@"cellForRowAtIndexPath蓝牙已连接");
////            cell.connectLabel.textColor=[UIColor blueColor];
////            cell.connectLabel.text=@"已连接";
//            cell.titleLabel.text =  NSLocalizedStringFromTable(@"FIVE", @"Localizable", nil);
//            cell.titleImage.image = [UIImage imageNamed:[imageList objectAtIndex:indexPath.row+4]];
//        }else{
////            cell.connectLabel.textColor=[UIColor whiteColor];
////            cell.connectLabel.text=@"未连接";
////            NSLog(@"cellForRowAtIndexPath蓝牙未连接");
//            cell.titleLabel.text =  NSLocalizedStringFromTable(@"SIX", @"Localizable", nil);
//            cell.titleImage.image = [UIImage imageNamed:[imageList objectAtIndex:indexPath.row]];
//        }
//    }
    
    
    return cell;
    
}
//选中Cell响应事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (indexPath.row==0) {
        if (lampsController.openDic.count==0&&lampsController.peripheralOpration==nil) {
            PopupView  *popUpView = [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
            popUpView.ParentView = self.view;
//            [popUpView setText:[NSString stringWithFormat:NSLocalizedStringFromTable(@"SEVEN", @"Localizable", nil)]];
            [popUpView setText:NSLocalizedStringFromTable(@"Please_select_bulb_or_group", @"Localizable", nil)];
            [[UIApplication sharedApplication].keyWindow addSubview:popUpView];
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            [self DevicePushAction];
            return;
        }
        
    }
    
    
    if (lastCellIndexPath&&selectedId!=indexPath.row) {
        selectedId=indexPath.row;
        [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastCellIndexPath]withRowAnimation:UITableViewRowAnimationNone];
    }
    lastCellIndexPath=indexPath;
    [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationFade];
    
    // set the root controller
    MMDrawerController *drawerController = (MMDrawerController*)((AppDelegate *)[[UIApplication sharedApplication] delegate]).drawerController;
    
    if(indexPath.row==0){
        UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:((AppDelegate *)[[UIApplication sharedApplication] delegate]).viewController];
        [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
    }else if (indexPath.row==1){
        UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:misicViewController];
        [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
    }else if (indexPath.row==2){
        UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:clockViewContrller];
        [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
        
    }else if (indexPath.row==3){
        UINavigationController * navigationController = [[MMNavigationController alloc] initWithRootViewController:lampsController];
        [drawerController setCenterViewController:navigationController withCloseAnimation:YES completion:nil];
        
    }
}

- (IBAction)openOrClosePower:(id)sender {
    char strcommand[8]={'A','T','#','O','F','0','E','1'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    if (![userDefaults boolForKey:@"powerOn"]) {
        strcommand[4] ='F';
        [userDefaults setBool:YES forKey:@"powerOn"];
        [_powerButton setImage:[UIImage imageNamed:@"kaiguan-n.png"] forState:UIControlStateNormal];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"MusicNotification" object:nil];
    }else{
        strcommand[4] ='N';
        [userDefaults setBool:NO forKey:@"powerOn"];
        [_powerButton setImage:[UIImage imageNamed:@"kaiguan-p.png"] forState:UIControlStateNormal];
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEAllDataNotification" object:nil userInfo:dic];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"openOrCloseNotification" object:nil userInfo:nil];
}
-(void)ConectedAction{
    ISConnected=YES;
    NSIndexPath *lastindexPath=[NSIndexPath indexPathForRow:3 inSection:0];
    [myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastindexPath]withRowAnimation:UITableViewRowAnimationFade];
}
@end

//
//  MusicViewController.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/7.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

@interface MusicViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,AVAudioPlayerDelegate,UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIButton *modleButton;
@property (weak, nonatomic) IBOutlet UIButton *playButton;
@property (weak, nonatomic) IBOutlet UITableView *musicTableView;
@property (weak, nonatomic) IBOutlet UITextField *MyTextField;

@property (strong, nonatomic) AVAudioPlayer *player;

- (IBAction)modleAction:(id)sender;
- (IBAction)preOneAction:(UIButton *)sender;
- (IBAction)playAction:(UIButton *)sender;
- (IBAction)nextAction:(UIButton *)sender;
- (IBAction)EditChangeAction:(id)sender;
- (IBAction)DidEndOnExitAction:(id)sender;

@end

//
//  MusicViewController.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/7.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "MusicViewController.h"
#import "MMDrawerController.h"
#import "MMDrawerBarButtonItem.h"
#import "PopupView.h"

@interface MusicViewController (){
    
    AVAudioSession *session;
    
    NSArray *mediaItems;
    NSMutableArray *showArray;//显示到表视图上的数据
    
    NSURL *urlOfSong;
    NSInteger modleNumber;
    
    BOOL HaveMusic;//本地播放库有没有音乐，有音乐为YES，没有音乐为NO。
    NSIndexPath *lastIndexPath;//最后选择的行,刷新界面的依据
    NSInteger lastMusicID;//内存中保存的最后一次播放的音乐ID
    BOOL ISChangeMusic;//是否重新初始化播放器.YES需要重新初始化播放器，NO不需要
    NSTimer *timer;
    BOOL ISSendMusic;
}
- (void)loadMediaItemsForMediaType:(MPMediaType)mediaType;
@end

@implementation MusicViewController
@synthesize player;
- (void)loadMediaItemsForMediaType:(MPMediaType)mediaType
{
    MPMediaQuery *query = [[MPMediaQuery alloc] init];
    NSNumber *mediaTypeNumber= [NSNumber numberWithInteger:mediaType];
    MPMediaPropertyPredicate *predicate = [MPMediaPropertyPredicate predicateWithValue:mediaTypeNumber forProperty:MPMediaItemPropertyMediaType];
    [query addFilterPredicate:predicate];
    mediaItems = [query items];
    showArray=[NSMutableArray arrayWithArray:mediaItems];
    
}
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag{
//    NSLog(@"播放完毕");
    if (mediaItems.count!=showArray.count) {
        showArray=[NSMutableArray arrayWithArray:mediaItems];
        lastIndexPath=[NSIndexPath indexPathForItem:lastMusicID inSection:0];
    }
    switch (modleNumber) {
        case 0:
            if(lastIndexPath.row!=[showArray count]-1){
                [self nextAction:nil];
            }else{
                [self StopAction];
            }
            break;
        case 1:
            [self playAction:nil];
            break;
        case 2:
        case 3:
            [self nextAction:nil];
            break;
        default:
//            NSLog(@"nothing");
            break;
    }
}

//当播放器遇到中断的时候（如来电），调用该方法
-(void)audioPlayerBeginInterruption:(AVAudioPlayer *)Myplayer{
//    NSLog(@"打断");
    [self pauseAction:nil];
}

//中断事件结束后调用下面的方法
-(void)audioPlayerEndInterruption:(AVAudioPlayer *)player withOptions:(NSUInteger)flags{
//    NSLog(@"结束打断");
    [self playAction:nil];
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error{
    NSLog(@"error:%@",error);
}
- (BOOL) canBecomeFirstResponder
{
    return YES;
}
// 最后定义 remoteControlReceivedWithEvent，处理具体的播放、暂停、前进、后退等具体事件
- (void) remoteControlReceivedWithEvent:(UIEvent *)event
{
    [super remoteControlReceivedWithEvent:event];
    if(event.type == UIEventTypeRemoteControl)
    {
        switch (event.subtype) {
            case UIEventSubtypeRemoteControlPlay:
                [self playAction:nil];
                break;
            case UIEventSubtypeRemoteControlPause:
                [self pauseAction:nil];
                break;
            case UIEventSubtypeRemoteControlNextTrack:
                NSLog(@"Next");
                [self nextAction:nil];
                break; 
            case UIEventSubtypeRemoteControlPreviousTrack: 
                NSLog(@"Previous");
                [self preOneAction:nil];
                break; 
            default:
                break; 
        } 
    } 
}
-(void)viewWillDisappear:(BOOL)animated{
    //视图将要消失时保存当前正在播放的ID，以便下次继续播放
    NSUserDefaults *userDefaults= [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:lastMusicID forKey:@"lastMusicKey"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //搜索图标
    UIImageView *leftSeachImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"信息-搜索icon"]];
    _MyTextField.leftView=leftSeachImageView;
    _MyTextField.leftViewMode=UITextFieldViewModeAlways;
    
    //初始化显示数组
    showArray=[[NSMutableArray alloc]initWithCapacity:0];
    //初始化状态下，不需要初始化播放器
    ISChangeMusic=NO;
    
    //获取上次播放的歌曲行数
    NSUserDefaults *userDefaults= [NSUserDefaults standardUserDefaults];
    lastMusicID=[[userDefaults objectForKey:@"lastMusicKey"] integerValue];
    
    //后台播放音频设置
    session = [AVAudioSession sharedInstance];
    [session setActive:YES error:nil];
    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
    
    [self becomeFirstResponder];
    //让app支持接受远程控制事件
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    
    
    // 设置标题，设置导航栏左侧按钮，视图背景色
    self.title = NSLocalizedStringFromTable(@"MUSICPAGE", @"Localizable", nil);
    [self setupLeftMenuButton];
    self.view.backgroundColor=[UIColor whiteColor];
    
    
    //加载本地音乐数据
    [self loadMediaItemsForMediaType:MPMediaTypeMusic];
    
    ISSendMusic=YES;
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(pauseAction:) name:@"MusicNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(playAction:) name:@"playMusicNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(MusicModeAction:) name:@"ModeNotification" object:nil];
    
    //如果没有本地音乐，默认加载一首音乐
    if([mediaItems count]==0){
        _MyTextField.enabled=NO;
        HaveMusic=NO;
        NSString *fileManage = [[NSBundle mainBundle]  resourcePath ];
        NSArray *fileNames = [[NSFileManager defaultManager] subpathsAtPath: fileManage ];
        for (int n = 0;n< fileNames.count; n++) {
            NSString*temp = [fileNames objectAtIndex:n];
            NSRange range = [temp rangeOfString:@"mp3"];
            if (range.length >0){
                NSString* path = [fileManage stringByAppendingPathComponent:temp];
                mediaItems=[[NSArray alloc]initWithObjects:path, nil];
            }
        }
    }else{
        HaveMusic=YES;
    }
}


-(void)MusicModeAction:(NSNotification*)notification{
    ISSendMusic=[[[notification userInfo] objectForKey:@"ISSendMusic"] boolValue];
    if (ISSendMusic) {
        NSLog(@"fasong");
    }else{
        NSLog(@"bufasong");
    }
}


#pragma mark - Table view data source
// 右边索引的标题数组
//- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
//{
//    NSMutableArray *array = [NSMutableArray array];
//    for(int section='A';section<='Z';section++)
//    {
//        [array addObject:[NSString stringWithFormat:@"%c",section]];
//    }
//    return array;
//}
//// 自定义索引与数组的对应关系
//- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
//{
//    return index+1;
////    return [ALPHA rangeOfString:title].location;
//}
//设置Section的Header的值
//- (NSString *)tableView:(UITableView *)aTableView titleForHeaderInSection:(NSInteger)section
//{
//    if ([[self.sectionArray objectAtIndex:section] count] == 0) return nil;
//    return [NSString stringWithFormat:@"Crayon names starting with '%@'", [[ALPHA substringFromIndex:section] substringToIndex:1]];
//}
//- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
//{
//    [self.searchBar setText:@""];
//}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return  showArray.count;
}
//改变行的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 54;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"MusicCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    if (HaveMusic) {
        NSUInteger row = [indexPath row];
        MPMediaItem *item = [showArray objectAtIndex:row];
        cell.textLabel.text = [item valueForProperty:MPMediaItemPropertyTitle];
        cell.detailTextLabel.text = [item valueForProperty:MPMediaItemPropertyArtist];
        cell.tag = row;
    }else{
        cell.textLabel.text =@"Music";
        cell.detailTextLabel.text =@"no name";
    }
    // Configure the cell...
    
    if(lastIndexPath&&indexPath.row==lastIndexPath.row){
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_MyTextField resignFirstResponder];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    ISChangeMusic=YES;//需要重新初始化服务器
    lastIndexPath = indexPath;
    //这里应该将lastMusicID转成对mediaItems的
    [self reSetlastMusicAction];
    [self playAction:nil];
    ISChangeMusic=NO;
}
-(void)reSetlastMusicAction{
    MPMediaItem *item = [showArray objectAtIndex:lastIndexPath.row];
    for (int i=0; i<mediaItems.count; i++) {
        if ([mediaItems objectAtIndex:i]==item) {
            lastMusicID=i;
//            NSLog(@"重新对应lastMusicID:%d",i);
        }
    }
    
}

#pragma mark - 播放器事件
- (IBAction)modleAction:(id)sender {
    //模式切换按钮事件，点击一次变换一个模式
    if (modleNumber<3) {
        modleNumber++;
    }else{
        modleNumber=0;
    }
    //弹出变换的提示
    PopupView  *popUpView;
    popUpView = [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
    popUpView.ParentView = self.view;
    switch (modleNumber) {
        case 0:
            [_modleButton setImage:[UIImage imageNamed:@"004"] forState:UIControlStateNormal];
            [popUpView setText: NSLocalizedStringFromTable(@"EIGHT", @"Localizable", nil)];
            break;
        case 1:
            [_modleButton setImage:[UIImage imageNamed:@"005"] forState:UIControlStateNormal];
            [popUpView setText: NSLocalizedStringFromTable(@"NINE", @"Localizable", nil)];
            break;
        case 2:
            [_modleButton setImage:[UIImage imageNamed:@"006"] forState:UIControlStateNormal];
            [popUpView setText:NSLocalizedStringFromTable(@"TEN", @"Localizable", nil)];
            break;
        case 3:
            [_modleButton setImage:[UIImage imageNamed:@"007"] forState:UIControlStateNormal];
            [popUpView setText: NSLocalizedStringFromTable(@"eleven", @"Localizable", nil)];
            break;
        default:
            break;
    }
    [self.view addSubview:popUpView];
}

- (void)pauseAction:(id)sender {
    [player pause]; //暂停播放
    [_playButton setImage:[UIImage imageNamed:@"0020"] forState:UIControlStateNormal];
    lastIndexPath=nil;//暂停时lastIndexPath=nil界面不会显示
    [_musicTableView reloadData];
    [timer invalidate];
}
-(void)StopAction{
    [player stop];
    [_playButton setImage:[UIImage imageNamed:@"0020"] forState:UIControlStateNormal];
    lastIndexPath=nil;//暂停时lastIndexPath=nil界面不会显示
    [_musicTableView reloadData];
    [timer invalidate];
}
- (IBAction)playAction:(UIButton *)sender {
    //如果是点击界面按钮
    if (sender.selected) {
        //暂停
        sender.selected=!sender.selected;
        [self pauseAction:nil];
    }else{
        //播放
        [_playButton setImage:[UIImage imageNamed:@"0021"] forState:UIControlStateNormal];
        _playButton.selected=YES;
        
        if (ISChangeMusic==NO&&player!=nil&&urlOfSong!=nil) {
//            NSLog(@"继续播放");
            //如果有播放记录不需要重新初始化
            [player play]; //播放音乐
            [timer invalidate];
            timer=[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(updateMeter) userInfo:nil repeats:YES];
        }else{
            NSError *error;
            //重新初始化播放器URL
            if (HaveMusic) {
                //如果有本地音乐，播放音乐
                urlOfSong=[[mediaItems objectAtIndex:lastMusicID] valueForProperty:MPMediaItemPropertyAssetURL];
                player=[[AVAudioPlayer alloc]initWithContentsOfURL:urlOfSong error:&error];
            }else{
//                NSLog(@"没有本地音乐");
                NSString *path= [[NSBundle mainBundle] pathForResource:@"1" ofType:@"mp3"];
                if (![[NSFileManager defaultManager] fileExistsAtPath:path]) return ;
                player=[[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL URLWithString:path] error:&error];
            }
            
            if (!player) {
                return;
            }
            [player prepareToPlay];
            player.meteringEnabled=YES;
            player.delegate = self;
            [player play]; //播放音乐
            [timer invalidate];
            timer=[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(updateMeter) userInfo:nil repeats:YES];
        }
        if (!lastIndexPath) {
            lastIndexPath=[NSIndexPath indexPathForRow:lastMusicID inSection:0];
        }
        
        [_musicTableView reloadData];
    }
    
}
-(void)updateMeter{
    [player updateMeters];
    NSLog(@"peakPowerForChannel:%.0f,averagePowerForChannel:%.0f",-[player peakPowerForChannel:0],-[player averagePowerForChannel:0]);
    if (ISSendMusic) {
        NSLog(@"fasong");
        
        char strcommand[9]={'A','T','#','E','C','0','0','0','0'};
        strcommand[5] = -[player averagePowerForChannel:0];
        strcommand[7] =0X0D;
        strcommand[8] =0X0A;
        NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEMusicDataDataNotification" object:nil userInfo:dic];
    }else{
        NSLog(@"bufangfa");
    }
}
- (IBAction)preOneAction:(UIButton *)sender {
    if (mediaItems.count!=showArray.count) {
        showArray=[NSMutableArray arrayWithArray:mediaItems];
        lastIndexPath=[NSIndexPath indexPathForItem:lastMusicID inSection:0];
    }
    ISChangeMusic=YES;
    NSInteger oldRow;
    if(modleNumber==3){
        oldRow = (int) (arc4random() % ([showArray count]));
    }else if (!lastIndexPath) {
        if(showArray.count==0)return;
        oldRow= 0;
    }else if(lastIndexPath.row==0){
        oldRow = [showArray count]-1;
    }else if(lastIndexPath.row>0){
        oldRow = [lastIndexPath row]-1;
    }
    lastIndexPath=[NSIndexPath indexPathForRow:oldRow inSection:0];
    lastMusicID=oldRow;
    [_musicTableView reloadData];
    [_musicTableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
    [self playAction:nil];
    ISChangeMusic=NO;
}

- (IBAction)nextAction:(UIButton *)sender{
    if (mediaItems.count!=showArray.count) {
        showArray=[NSMutableArray arrayWithArray:mediaItems];
        lastIndexPath=[NSIndexPath indexPathForItem:lastMusicID inSection:0];
    }
    ISChangeMusic=YES;
    NSLog(@"下一首");
    NSInteger oldRow;
    if(modleNumber==3){
        oldRow = (int) (arc4random() % ([showArray count]));
    }else if (!lastIndexPath) {
        if(showArray.count==0)return;
        oldRow= 0;
    }else if(lastIndexPath.row==[showArray count]-1){
        oldRow = 0;
    }else if(lastIndexPath.row>=0){
        oldRow = [lastIndexPath row]+1;
    }
    NSLog(@"oldRow:%ld",(long)oldRow);
    lastIndexPath=[NSIndexPath indexPathForRow:oldRow inSection:0];
    lastMusicID=oldRow;
    [_musicTableView reloadData];
    [_musicTableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
    
    [self playAction:nil];
    
    ISChangeMusic=NO;
}

- (IBAction)EditChangeAction:(id)sender {
//    _MyTextField.enabled=NO;
    MPMediaItem *OldItem;
    //ID可能要重新对应到所有的数组中
    if (player.isPlaying) {
        if (lastIndexPath.row+1>showArray.count) {
//            NSLog(@"直接return");
            OldItem=[mediaItems objectAtIndex:lastMusicID];
        }else {
            if(lastIndexPath){
//                NSLog(@"lastIndexPath存在");
                OldItem=[showArray objectAtIndex:lastIndexPath.row];
            }else{
                OldItem=[mediaItems objectAtIndex:lastMusicID];
            }
        }
    }
//    NSLog(@"正在播放的:%@",[OldItem valueForProperty:MPMediaItemPropertyTitle]);
    
    lastIndexPath=nil;
    //现在选择的一行在新列表中对应哪一行，lastIndexPath重建，ID要重新对应
//    NSLog(@"输入的内容:%@",_MyTextField.text);
    if(_MyTextField.text.length==0){
        showArray=[NSMutableArray arrayWithArray:mediaItems];
        
        for (int i=0; i<mediaItems.count; i++) {
            if ([mediaItems objectAtIndex:i]==OldItem) {
                lastIndexPath=[NSIndexPath indexPathForRow:i inSection:0];
//                NSLog(@"其中这个项正在播放:%d",i);
            }
        }
    }else{
        [showArray removeAllObjects];
        MPMediaItem *item;
        for (int i=0; i<mediaItems.count; i++) {
            item = [mediaItems objectAtIndex:i];
            if ([[item valueForProperty:MPMediaItemPropertyTitle] rangeOfString:_MyTextField.text].location!=NSNotFound||([[item valueForProperty:MPMediaItemPropertyArtist] rangeOfString:_MyTextField.text].location!=NSNotFound&&[item valueForProperty:MPMediaItemPropertyArtist])) {
                
                NSLog(@"zhaodao：%@",[item valueForProperty:MPMediaItemPropertyTitle]);
                [showArray addObject:item];
                
                if (item==OldItem) {
//                    NSLog(@"其中这个项正在播放");
                    lastIndexPath=[NSIndexPath indexPathForRow:showArray.count-1 inSection:0];
                }
            }
        }
    }
    
    
    
    [_musicTableView reloadData];
    [_musicTableView scrollToRowAtIndexPath:lastIndexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
//    _MyTextField.enabled=YES;
}

- (IBAction)DidEndOnExitAction:(id)sender {
    [_MyTextField resignFirstResponder];
}

#pragma mark - Button Handlers
-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
}
-(MMDrawerController*)mm_drawerController{
    UIViewController *parentViewController = self.parentViewController;
    while (parentViewController != nil) {
        if([parentViewController isKindOfClass:[MMDrawerController class]]){
            return (MMDrawerController *)parentViewController;
        }
        parentViewController = parentViewController.parentViewController;
    }
    return nil;
}
-(void)leftDrawerButtonPress:(id)sender{
    [_MyTextField resignFirstResponder];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
@end

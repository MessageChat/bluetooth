//
//  RepeatViewController.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/23.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "RepeatViewController.h"

@interface RepeatViewController (){
    NSArray *repeatDataArray;
    NSMutableArray *selectArray;
}

@end

@implementation RepeatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    selectArray =[[NSMutableArray alloc] initWithObjects:@"0",@"0",@"0",@"0",@"0",@"0",@"0",nil];
    repeatDataArray=[[NSArray alloc]initWithObjects:NSLocalizedStringFromTable(@"Eveweek1", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek2", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek3", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek4", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek5", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek6", @"Localizable", nil),
                     NSLocalizedStringFromTable(@"Eveweek7", @"Localizable", nil),nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillDisappear:(BOOL)animated{
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:selectArray,@"selectArray",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RepeatNotification" object:nil userInfo:dic];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
//返回TableView中有多少数据
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
//返回有多少个TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//组装每一条的数据
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"RepeatCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text=[repeatDataArray objectAtIndex:indexPath.row];
    return cell;
}
//选中Cell响应事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell.accessoryType == UITableViewCellAccessoryNone) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [selectArray replaceObjectAtIndex:indexPath.row withObject:@"1"];
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
        [selectArray replaceObjectAtIndex:indexPath.row withObject:@"0"];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
@end

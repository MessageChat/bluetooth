//
//  SceneViewController.h
//  Usmart
//
//  Created by 陈双超 on 15/6/1.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface SceneViewController : UIViewController<UIAccelerometerDelegate>
- (IBAction)changeSenceAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIImageView *BGImageView;

@end

//
//  SceneViewController.m
//  Usmart
//
//  Created by 陈双超 on 15/6/1.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//

#import "SceneViewController.h"

@interface SceneViewController (){
    BOOL isStopAcc;
}
@property (nonatomic,strong)CMMotionManager *motionManager;
@property (nonatomic,strong)NSOperationQueue *queue;
@end

@implementation SceneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.motionManager = [[CMMotionManager alloc] init];
    self.queue = [[NSOperationQueue alloc] init];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    isStopAcc=YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)changeSenceAction:(UIButton *)sender {
    
    _BGImageView.image=[UIImage imageNamed:[NSString stringWithFormat:@"%ld-%ld",(long)sender.tag,(long)sender.tag ]];
    char strcommand[9]={'A','T','#','A','*','*','*','*','*'};
    isStopAcc=YES;
    switch (sender.tag) {
        case 1:
            strcommand[4] = 75 ;
            strcommand[5] = 145;
            strcommand[6] = 203;
            break;
        case 2:
            strcommand[4] = 193 ;
            strcommand[5] = 220;
            strcommand[6] = 226;
            break;
        case 3:
            strcommand[4] = 120 ;
            strcommand[5] = 197;
            strcommand[6] = 56;
            break;
        case 4:
            strcommand[4] = 201;
            strcommand[5] = 172;
            strcommand[6] = 137;
            break;
        case 5:
            isStopAcc=NO;
            if (self.motionManager.accelerometerAvailable) {
                
                self.motionManager.accelerometerUpdateInterval = 1.0 / 10.0; //回调周期为10Hz
                //设置回调block
                [self.motionManager startAccelerometerUpdatesToQueue:self.queue withHandler: ^(CMAccelerometerData *accelerometerData, NSError *error) {
                    if (error||isStopAcc) {
                        [self.motionManager stopAccelerometerUpdates];
                        NSLog(@"tingzhi");
                    } else {
                        char strcommand[9]={'A','T','#','A','*','*','*','*','*'};
                        
                        int x=fabs(accelerometerData.acceleration.x*255);
                        int y=fabs(accelerometerData.acceleration.y*255);
                        int z=fabs(accelerometerData.acceleration.z*255);
                        if (x>255) {
                            x=255;
                        }
                        if (y>255) {
                            y=255;
                        }
                        if (z>255) {
                            z=255;
                        }
                        strcommand[4] = x;
                        strcommand[5] = y;
                        strcommand[6] = z;
                        strcommand[7] =0X0D;
                        strcommand[8] =0X0A;
                        NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
                        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
                    }
                }];
            }
            break;
            return;
        case 6:
            strcommand[4] = 221 ;
            strcommand[5] = 199;
            strcommand[6] = 155;
            break;
        case 7:
            strcommand[4] = 239 ;
            strcommand[5] = 168;
            strcommand[6] = 68;
            break;
        case 8:
            strcommand[4] = 249 ;
            strcommand[5] = 216;
            strcommand[6] = 198;
            break;
        case 9:
            strcommand[4] = 229 ;
            strcommand[5] = 226;
            strcommand[6] = 120;
            break;
        default:
            break;
    }
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

@end

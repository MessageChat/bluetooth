//
//  SubCollectionCellView.h
//  TestZJMuseumIpad
//
//  Created by 胡 jojo on 13-10-11.
//  Copyright (c) 2013年 tracy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubCollectionCellView : UIView


@property(strong,nonatomic) UIImageView *iconImageView;

@property(strong,nonatomic) UILabel *titleLabel;
@property(strong,nonatomic) UILabel *nameLabel;


-(void) initUI;

@end

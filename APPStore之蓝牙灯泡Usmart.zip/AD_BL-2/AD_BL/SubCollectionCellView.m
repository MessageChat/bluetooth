//
//  SubCollectionCellView.m
//  TestZJMuseumIpad
//
//  Created by 胡 jojo on 13-10-11.
//  Copyright (c) 2013年 tracy. All rights reserved.
//

#import "SubCollectionCellView.h"

@implementation SubCollectionCellView

@synthesize iconImageView=_iconImageView;
@synthesize titleLabel=_titleLabel;
@synthesize nameLabel=_nameLabel;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}

-(void) initUI
{
    self.userInteractionEnabled=YES;
    self.backgroundColor=[UIColor clearColor];
    //圆圈亮度条
    _iconImageView=[[UIImageView alloc] init];
    [_iconImageView setFrame:CGRectMake(10, self.frame.size.height/2-140/2, 140, 140)];
    [self addSubview:_iconImageView];

    
    // 灯硬件名称
     _titleLabel=[[UILabel alloc] initWithFrame:CGRectMake(10, 40, 120, 40)];
    _titleLabel.numberOfLines=0;
    [_titleLabel setBackgroundColor:[UIColor clearColor]];
    [_titleLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
    [_titleLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:16]];
    [_titleLabel setTextAlignment:NSTextAlignmentCenter];
    [_iconImageView addSubview:_titleLabel];
    
    // name
    _nameLabel=[[UILabel alloc] init];
    [_nameLabel setFrame:CGRectMake(20,_titleLabel.frame.origin.y+_titleLabel.frame.size.height, 100, 20)];
    [_nameLabel setBackgroundColor:[UIColor clearColor]];
    [_nameLabel setTextColor:[UIColor colorWithRed:26.0/255.0 green:134.0/255.0 blue:239.0/255.0 alpha:1.0]];
    [_nameLabel setFont:[UIFont fontWithName:@"Helvetica-Bold" size:14]];
    [_nameLabel setTextAlignment:NSTextAlignmentCenter];
    [_iconImageView addSubview:_nameLabel];



}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end

//
//  TableViewCell.h
//  ADMBL
//
//  Created by 陈双超 on 14/12/5.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView *titleImage;
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIView *selectedBG;
@end

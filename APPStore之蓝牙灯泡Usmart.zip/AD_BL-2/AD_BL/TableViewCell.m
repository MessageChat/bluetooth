//
//  TableViewCell.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/5.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell


- (void)awakeFromNib {
    // Initialization code
    self.selectedBG=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 72)];
    self.selectedBG.backgroundColor=[UIColor whiteColor];
        self.selectedBG.alpha=0.2;
    [self addSubview:self.selectedBG];
    
    UIImageView *fenggexian;
    
    fenggexian=[[UIImageView alloc]initWithFrame:CGRectMake(0, 71, [UIScreen mainScreen].bounds.size.width, 1)];
    fenggexian.image=[UIImage imageNamed:@"fengexian"];
    [self addSubview:fenggexian];
    
    self.titleImage =[[UIImageView alloc]init];
    self.titleImage.frame = CGRectMake(30, 14, 44, 44);
    [self addSubview:self.titleImage];
    
    
    self.titleLabel  = [[UILabel alloc]init];
    self.titleLabel.frame = CGRectMake(90, 0, 200, 72);
    self.titleLabel.backgroundColor = [UIColor clearColor];
    self.titleLabel.numberOfLines=0;
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    self.titleLabel.textColor=[UIColor whiteColor];
    self.titleLabel.font =[UIFont fontWithName:@"Helvetica" size:18];
    [self addSubview:self.titleLabel];
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
    
}

@end

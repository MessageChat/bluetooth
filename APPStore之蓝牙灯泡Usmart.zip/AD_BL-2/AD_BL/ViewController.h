//
//  ViewController.h
//  AD_BL
//
//  Created by 3013 on 14-6-5.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonUsedDefine.h"



@protocol ColorVCDelegate <NSObject>
-(void)colorDidChange:(UIColor*)color;
@end

@interface ViewController : UIViewController{
    UIButton *mainBtn;
    BOOL isLightOpen;
    
}
@property (assign,nonatomic) id <ColorVCDelegate> delegate;

@property (weak, nonatomic) IBOutlet UIImageView *BGView;

@property (weak, nonatomic) IBOutlet UIButton *dishigaoButton;
@property (weak, nonatomic) IBOutlet UIButton *langmanButton;
@property (weak, nonatomic) IBOutlet UIButton *yaogunButton;
@property (weak, nonatomic) IBOutlet UIButton *wenxinButton;


@property (weak, nonatomic) IBOutlet UIImageView *colorImageView;
@property (weak, nonatomic) IBOutlet UIButton *onOFFButton;
@property (weak, nonatomic) IBOutlet UIButton *powerButton;

@property (strong,nonatomic)UIView *NoBLView;


- (IBAction)dishigaoAction:(id)sender;
- (IBAction)langmanAction:(id)sender;
- (IBAction)yaogunAction:(id)sender;
- (IBAction)wenxinAction:(id)sender;


- (IBAction)onOFFAction:(id)sender;
- (IBAction)powerOnOffAction:(id)sender;

- (IBAction)colorBrightChangeAction:(id)sender;
- (IBAction)xiaoguoChangeAction:(id)sender;

@end

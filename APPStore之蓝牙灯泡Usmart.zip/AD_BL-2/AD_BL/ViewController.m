//
//  ViewController.m
//  AD_BL
//
//  Created by 3013 on 14-6-5.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "ViewController.h"
#import "EFCircularSlider.h"
#import "MMDrawerBarButtonItem.h"
#import "UIViewController+MMDrawerController.h"
#import "PopupView.h"
#import "SceneViewController.h"
CGRect CGRectMakeWithCenter (CGPoint center, CGFloat diameter)
{
    return CGRectMake (center.x - diameter / 2, center.y - diameter / 2, diameter, diameter);
}

@interface ViewController (){
    EFCircularSlider *colorSlider;
    
    int iWhite;
    int iReg;
    int igreen;
    int iBlue;
    
    int colorBright;
    int xiaoguo;
    
    BOOL isSelectWhite;
   
    NSUserDefaults *userDefaults;
    NSDate *LastSendTime;
    NSInteger selectMusicType;//选择的哪种音乐的ID，迪士高为0，浪漫为1，摇滚为2，温馨为3；
    NSInteger lastMusicType;//选择的哪种音乐的ID，迪士高为0，浪漫为1，摇滚为2
//    UIImageView *xiaoquanImageView;
    
}

@end

@implementation ViewController
@synthesize BGView,NoBLView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:NO completion:nil];
    
    [self setRestorationIdentifier:@"MMExampleCenterControllerRestorationKey"];
    
    userDefaults= [NSUserDefaults standardUserDefaults];
    LastSendTime= [[NSDate alloc]init];
    
    self.view.tag=10001;
    self.colorImageView.tag=10001;
    
    [self setupLeftMenuButton];
    
//    self.title = NSLocalizedStringFromTable(@"MAINPAGE", @"Localizable", nil);
    UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:[NSString stringWithFormat:@"%@➡️",NSLocalizedStringFromTable(@"Wallpaper", @"Localizable", nil)] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(PushToSence) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.titleView=button;
    
    if (SCREENHIGHT==480) {
        [BGView setImage:[UIImage imageNamed:@"bg02-960.png"]];
    }else if (SCREENHIGHT==568){
        [BGView setImage:[UIImage imageNamed:@"bg2-1136.jpg"]];
    }else{
        [BGView setImage:[UIImage imageNamed:@"bg2-1242.jpg"]];
    }
    BGView.frame=CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    
    //slider控制器
    CGRect minuteSliderFrame =CGRectMake(30,30,180,180);
//    NSLog(@"========%f,%f",self.colorImageView.frame.size.width*0.8,self.colorImageView.frame.size.width*0.8);
    colorSlider = [[EFCircularSlider alloc] initWithFrame:minuteSliderFrame];
    
    colorSlider.unfilledColor = [UIColor clearColor];
    colorSlider.filledColor = [UIColor clearColor];
    colorSlider.lineWidth = 18;
    colorSlider.minimumValue = 0;
    colorSlider.maximumValue = 360;
    colorSlider.labelColor = [UIColor colorWithRed:76/255.0f green:111/255.0f blue:137/255.0f alpha:1.0f];
    colorSlider.handleType = bigCircle;
    colorSlider.handleColor = [UIColor whiteColor];
//    [self.colorImageView addSubview:colorSlider];
    [colorSlider addTarget:self action:@selector(colorDidChange:) forControlEvents:UIControlEventValueChanged];
    [colorSlider addTarget:self action:@selector(colorDidChange:) forControlEvents:UIControlEventTouchUpInside];
    
    
    self.colorImageView.userInteractionEnabled=YES;
//    xiaoquanImageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 100, 40, 40)];
//    [xiaoquanImageView setImage:[UIImage imageNamed:@"xiaoquanquan.png"]];
//    [self.colorImageView addSubview:xiaoquanImageView];
    
    
    
//    NoBLView=[[UIView alloc]initWithFrame:CGRectMake(0, 0,SCREENWIDTH , SCREENHIGHT)];
//    NoBLView.backgroundColor=[UIColor blueColor];
//    UIImageView *LoadImageView=[[UIImageView alloc]initWithFrame:NoBLView.frame];
//    LoadImageView.image=[UIImage imageNamed:@"yinfaoye1136"];
//    [NoBLView addSubview:LoadImageView];
//    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake((SCREENWIDTH-100)/2, 450, 100, 30)];
//    label.text=NSLocalizedStringFromTable(@"FOUR", @"Localizable", nil);
//    label.textAlignment=NSTextAlignmentCenter;
//    label.textColor=[UIColor whiteColor];
//    [NoBLView addSubview:label];
    [[[UIApplication sharedApplication] delegate].window addSubview:NoBLView];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(openOrCloseAction) name:@"openOrCloseNotification" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(ShowModeAction:) name:@"ShowModeNotification" object:nil];
}
-(void)ShowModeAction:(NSNotification*) notification{
    
    PopupView  *popUpView= [[PopupView alloc]initWithFrame:CGRectMake(100, 240, 0, 0)];
    popUpView.ParentView = self.view;
    [popUpView setText: (NSString*)[notification object]];
    [self.view addSubview:popUpView];
}
-(void)PushToSence{
    NSLog(@"PushToSence");
    UIButton *button=[[UIButton alloc]init];
    button.tag=3;
    [self wenxinAction:button];
    UIViewController *SenceVC=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"SceneView"];
    [self.navigationController pushViewController:SenceVC animated:YES];
}

-(void)tapColorAction:(UITapGestureRecognizer *)gesterue{
    NSLog(@"%@",gesterue);
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    CGPoint touched=[[[touches allObjects] objectAtIndex:0] locationInView:self.view];
    [self tochAction:touched];
    //    NSLog(@"----%f,%f,%f,%f",touched.x,touched.y,self.colorImageView.frame.origin.x,self.colorImageView.frame.origin.y);
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    if ([LastSendTime timeIntervalSinceNow]<-0.05) {
        LastSendTime=[[NSDate alloc]init];
        CGPoint touched=[[[touches allObjects] objectAtIndex:0] locationInView:self.view];
        [self tochAction:touched];
    }
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    CGPoint touched=[[[touches allObjects] objectAtIndex:0] locationInView:self.view];
    [self tochAction:touched];
}

-(void)tochAction:(CGPoint)touched{
//    CGRect mCenterRect=CGRectMakeWithCenter(self.colorImageView.center, self.colorImageView.bounds.size.height-40);
    BOOL pointInRound = [self touchPointInsideCircle:self.colorImageView.center radius:120 targetPoint:touched];
    if (!pointInRound) {
//        NSLog(@"不在区域");
    }else{
        [self colorAtPixel:touched];
    }
}
- (BOOL)touchPointInsideCircle:(CGPoint)center radius:(CGFloat)radius targetPoint:(CGPoint)point
{
    CGFloat dist = sqrtf((point.x - center.x) * (point.x - center.x) +
                         (point.y - center.y) * (point.y - center.y));
    return (dist <= radius);
}
- (UIColor *)colorAtPixel:(CGPoint)point {
    point=CGPointMake(point.x-self.colorImageView.frame.origin.x, point.y-self.colorImageView.frame.origin.y);
    
    NSInteger pointX = trunc(point.x);
    NSInteger pointY = trunc(point.y);
    NSLog(@"point:%ld,%ld",(long)pointX,(long)pointY);
    CGImageRef cgImage = self.colorImageView.image.CGImage;
    NSUInteger width = self.colorImageView.bounds.size.width;
    NSUInteger height =self.colorImageView.bounds.size.height;
    CGColorSpaceRef colorSpace =CGColorSpaceCreateDeviceRGB();
    int bytesPerPixel = 4;
    int bytesPerRow = bytesPerPixel * 1;
    NSUInteger bitsPerComponent = 8;
    unsigned char pixelData[4] = {0, 0, 0, 0 };
    CGContextRef context = CGBitmapContextCreate(pixelData, 1, 1, bitsPerComponent, bytesPerRow, colorSpace, kCGImageAlphaPremultipliedLast |kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    CGContextSetBlendMode(context,kCGBlendModeCopy);
    
    // Draw the pixel we are interested in onto the bitmap context
    CGContextTranslateCTM(context, -pointX, pointY-(CGFloat)height);
    CGContextDrawImage(context, CGRectMake(0.0f, 0.0f, (CGFloat)width, (CGFloat)height), cgImage);
    CGContextRelease(context);
    
    // Convert color values [0..255] to floats [0.0..1.0]
    CGFloat red   = (CGFloat)pixelData[0] ;
    CGFloat green = (CGFloat)pixelData[1] ;
    CGFloat blue  = (CGFloat)pixelData[2] ;
    CGFloat alpha = (CGFloat)pixelData[3] ;
    NSLog(@"R:%.0f,G:%.0f,B:%.0f,A:%.0f",(CGFloat)pixelData[0],(CGFloat)pixelData[1],(CGFloat)pixelData[2],alpha);
    
    
    char strcommand[9]={'A','T','#','A','*','*','*','*','*'};
    strcommand[4] = red;
    strcommand[5] = green;
    strcommand[6] = blue;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    
    

    return [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
}

//开灯关灯
-(void)openOrCloseAction{
    
    if ([userDefaults boolForKey:@"ColorOnOff"]) {
        NSLog(@"1111");
        if (![userDefaults boolForKey:@"powerOn"]) {//开着的时候才执行
            [_powerButton setImage:[UIImage imageNamed:@"kaiguan-p-xiao.png"] forState:UIControlStateNormal];
            [userDefaults setBool:NO forKey:@"ColorOnOff"];
        }
        
    }else{
        NSLog(@"2222");
        [_powerButton setImage:[UIImage imageNamed:@"kaiguan-n-xiao.png"] forState:UIControlStateNormal];
        [userDefaults setBool:YES forKey:@"ColorOnOff"];
    }
}

-(void)awakeFromNib{
    [self setRestorationIdentifier:@"MMExampleCenterControllerRestorationKey"];
}
#pragma 音乐选择
- (IBAction)dishigaoAction:(id)sender {
    [self deselectenButton:sender];
}

- (IBAction)langmanAction:(id)sender {
    [self deselectenButton:sender];
}

- (IBAction)yaogunAction:(id)sender {
    [self deselectenButton:sender];
}

- (IBAction)wenxinAction:(id)sender {
    [self deselectenButton:sender];
}
-(void)deselectenButton:(id)sender{
//    if (selectMusicType==((UIButton*)sender).tag) {
//        return;
//    }
    char strcommand[8]={'A','T','#','C','B','5','*','*'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    
    switch (selectMusicType) {//让之前选择的模式按钮恢复正常
        case 0:
            [_dishigaoButton setImage:[UIImage imageNamed:@"discos-n.png"] forState:UIControlStateNormal];
            break;
        case 1:
            [_langmanButton setImage:[UIImage imageNamed:@"langman-n.png"] forState:UIControlStateNormal];
            break;
        case 2:
            [_yaogunButton setImage:[UIImage imageNamed:@"yaogun-n.png"] forState:UIControlStateNormal];
            break;
        case 3:
            [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-n.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    switch (((UIButton*)sender).tag) {
        case 0:
            strcommand[5] ='2';
            [_dishigaoButton setImage:[UIImage imageNamed:@"discos-p.png"] forState:UIControlStateNormal];
            break;
        case 1:
            strcommand[5] ='3';
            [_langmanButton setImage:[UIImage imageNamed:@"langman-p.png"] forState:UIControlStateNormal];
            break;
        case 2:
            strcommand[5] ='4';
            [_yaogunButton setImage:[UIImage imageNamed:@"yaogun-p.png"] forState:UIControlStateNormal];
            break;
        case 3:
            strcommand[5] ='5';
            [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-p.png"] forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    selectMusicType=((UIButton*)sender).tag;
    
    if (selectMusicType==3) {
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:NO],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }else{
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:YES],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }
    
    if (iWhite==255) {
        iWhite=0;
        [_onOFFButton setImage:[UIImage imageNamed:@"deng-caise.png"] forState:UIControlStateNormal];
        char strcommand[8]={'A','T','#','C','O','0','E','1'};
        strcommand[6] =0X0D;
        strcommand[7] =0X0A;
        strcommand[5] ='1';
        NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
        
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}
-(void)deselectenButtonImage{
    
    
    if (iWhite==255) {
        switch (selectMusicType) {
            case 0:
                [_dishigaoButton setImage:[UIImage imageNamed:@"discos-n.png"] forState:UIControlStateNormal];
                break;
            case 1:
                [_langmanButton setImage:[UIImage imageNamed:@"langman-n.png"] forState:UIControlStateNormal];
                break;
            case 2:
                [_yaogunButton setImage:[UIImage imageNamed:@"yaogun-n.png"] forState:UIControlStateNormal];
                break;
            case 3:
                [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-n.png"] forState:UIControlStateNormal];
                break;
            default:
                break;
        }
        selectMusicType=3;
        [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-p.png"] forState:UIControlStateNormal];
    }else{
        [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-n.png"] forState:UIControlStateNormal];
        switch (lastMusicType) {
            case 0:
                
                [_dishigaoButton setImage:[UIImage imageNamed:@"discos-p.png"] forState:UIControlStateNormal];
                break;
            case 1:
                [_langmanButton setImage:[UIImage imageNamed:@"langman-p.png"] forState:UIControlStateNormal];
                break;
            case 2:
                [_yaogunButton setImage:[UIImage imageNamed:@"yaogun-p.png"] forState:UIControlStateNormal];
                break;
            case 3:
                [_wenxinButton setImage:[UIImage imageNamed:@"wenxing-p.png"] forState:UIControlStateNormal];
                break;
            default:
                break;
        }
    }
    if (selectMusicType==3) {
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:NO],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }else{
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:YES],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }
}

#pragma 其他按钮事件
- (IBAction)onOFFAction:(id)sender {
    
    if(iWhite==0){
//        NSLog(@"切换到白");
        lastMusicType=selectMusicType;
        iWhite=255;
        [_onOFFButton setImage:[UIImage imageNamed:@"deng-baise.png"] forState:UIControlStateNormal];
        
        char strcommand2[9]={'A','T','#','A','*','*','*','*','*'};
        strcommand2[4] = 255;
        strcommand2[5] = 255;
        strcommand2[6] = 255;
        strcommand2[7] =0X0D;
        strcommand2[8] =0X0A;
        NSData *cmdData2 = [NSData dataWithBytes:strcommand2 length:9];
        NSDictionary *dic2=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData2,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic2];
    }else{
        selectMusicType=lastMusicType;
        iWhite=0;
        [_onOFFButton setImage:[UIImage imageNamed:@"deng-caise.png"] forState:UIControlStateNormal];
        
        
        char strcommand[8]={'A','T','#','C','O','0','E','1'};
        strcommand[6] =0X0D;
        strcommand[7] =0X0A;
        strcommand[5] ='1';
        NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    }
    
    
    char strcommand1[8]={'A','T','#','C','B','5','0','0'};
    strcommand1[6] =0X0D;
    strcommand1[7] =0X0A;
    if(iWhite!=255){
//        NSLog(@"白色切换到彩色");
        strcommand1[5] =lastMusicType+'2';
    }
    NSData *cmdData3 = [NSData dataWithBytes:strcommand1 length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData3,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    [self deselectenButtonImage];
    
    if (selectMusicType==3) {
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:NO],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }else{
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:[NSNumber numberWithBool:YES],@"ISSendMusic",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ModeNotification" object:nil userInfo:dic];
    }
}

- (IBAction)powerOnOffAction:(id)sender {
//    if ([userDefaults boolForKey:@"powerOn"]) {
//        return;
//    }
    char strcommand[8]={'A','T','#','L','E','1'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    if (![userDefaults boolForKey:@"ColorOnOff"]) {
        NSLog(@"====");
        strcommand[5] ='0';
        [userDefaults setBool:YES forKey:@"ColorOnOff"];
        [_powerButton setImage:[UIImage imageNamed:@"kaiguan-n-xiao.png"] forState:UIControlStateNormal];
    }else{
        NSLog(@"---");
        strcommand[5] ='1';
        [userDefaults setBool:NO forKey:@"ColorOnOff"];
        [_powerButton setImage:[UIImage imageNamed:@"kaiguan-p-xiao.png"] forState:UIControlStateNormal];
        
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

- (IBAction)colorBrightChangeAction:(id)sender {
    if (colorBright==(int)(((UISlider*)sender).value*8)) {
        return;
    }
    colorBright=(int)(((UISlider*)sender).value*8);
    char strcommand[8]={'A','T','#','L','0','*','0','*'};
    strcommand[5]= '0'+ colorBright;
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSLog(@"cmdData:%@",cmdData);
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

- (IBAction)xiaoguoChangeAction:(id)sender {
    if (xiaoguo==(int)(((UISlider*)sender).value*12)) {
        return;
    }
    xiaoguo=(int)(((UISlider*)sender).value*12);
    char strcommand[9]={'A','T','#','L','R','0','1','0','1'};
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    if (xiaoguo>=10) {
        xiaoguo=xiaoguo-10;
        strcommand[5]='1';
    }
    strcommand[6]='0'+ xiaoguo;
    
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}
//转动中心圆时触发此委托
-(void)colorDidChange:(EFCircularSlider*)slider {
    int newVal = (int)slider.currentValue < 360 ? (int)slider.currentValue : 0;
    if (iWhite==255) {
        return;
    }
    
    if (0<=newVal&&newVal<=45) {
        iReg=255,igreen=0;
        iBlue=newVal*255/45;        //0度到45度，蓝色的值改变
    }
    if (45<=newVal&&newVal<=135) {
        iReg=255-(newVal-45)*255/90;  //45度到135度，红色的值改变
    }
    if (135<=newVal&&newVal<=180) {
        iReg=0,iBlue=255;
        igreen=(newVal-135)*255/45;                         //135度到180度，绿色的值改变
    }
    if (180<=newVal&&newVal<=225) {
        iReg=0,igreen=255;
        iBlue=255-(newVal-180)*255/45;                         //180度到225度，蓝色的值改变
    }
    if (225<=newVal&&newVal<=315) {
        iBlue=0,igreen=255;
        iReg=(newVal-225)*255/90;                               //225度到315度，红色的值改变
    }
    if (315<=newVal&&newVal<=360)
    {
        iReg=255,iBlue=0;
        igreen=255-(newVal-315)*255/45;                         //315度到360度，绿色的值改变
    }
    NSLog(@"%d,%d,%d",iReg,igreen,iBlue);
    
    if ([LastSendTime timeIntervalSinceNow]<-0.05) {
        LastSendTime=[[NSDate alloc]init];
        NSLog(@"fasong");
    }else{
        return;
    }
    char strcommand[9]={'A','T','#','A','*','*','*','*','*'};
    strcommand[4] = iReg;
    strcommand[5] = igreen;
    strcommand[6] = iBlue;
    strcommand[7] =0X0D;
    strcommand[8] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

#pragma mark - Button Handlers
-(void)setupLeftMenuButton{
    MMDrawerBarButtonItem * leftDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(leftDrawerButtonPress:)];
    [self.navigationItem setLeftBarButtonItem:leftDrawerButton animated:YES];
    
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"ic_cfg"] style:UIBarButtonItemStylePlain target:self action:@selector(rightDrawerButtonPress:)];
    self.navigationItem.rightBarButtonItem.tintColor=[UIColor whiteColor];
//    MMDrawerBarButtonItem * rightDrawerButton = [[MMDrawerBarButtonItem alloc] initWithTarget:self action:@selector(rightDrawerButtonPress:)];
//    [self.navigationItem setRightBarButtonItem:rightDrawerButton animated:YES];
}
-(MMDrawerController*)mm_drawerController{
    UIViewController *parentViewController = self.parentViewController;
    while (parentViewController != nil) {
        if([parentViewController isKindOfClass:[MMDrawerController class]]){
            return (MMDrawerController *)parentViewController;
        }
        parentViewController = parentViewController.parentViewController;
    }
    return nil;
}
-(void)leftDrawerButtonPress:(id)sender{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}
-(void)rightDrawerButtonPress:(id)sender{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"DevicePushNotification" object:nil];
}
@end

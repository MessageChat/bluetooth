//
//  WhiteLightVC.h
//  Usmart
//
//  Created by 陈双超 on 15/6/6.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WhiteLightVC : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *MyImageView;

@property (weak, nonatomic) IBOutlet UIImageView *MyBreathImage;
@property (weak, nonatomic) IBOutlet UIImageView *MyPanImageView;
@property (weak, nonatomic) IBOutlet UILabel *MyLabel;
@property (weak, nonatomic) IBOutlet UIButton *OpenOrCloseButton;
- (IBAction)YeDengAction:(UIButton *)sender;

- (IBAction)OpenOrCloseLightAction:(UIButton *)sender;

@end

//
//  WhiteLightVC.m
//  Usmart
//
//  Created by 陈双超 on 15/6/6.
//  Copyright (c) 2015年 com.aidian. All rights reserved.
//
//
#import "WhiteLightVC.h"
#import "KTOneFingerRotationGestureRecognizer.h"

#define ScreenHeight ([UIScreen mainScreen].bounds.size.height)
#define ScreenWidth ([UIScreen mainScreen].bounds.size.width)

@interface WhiteLightVC (){
    CGFloat MyRotation;//色盘旋转的角度
    CGPoint curTickleStart;//开始或者上一次触摸百分比的位置
    NSInteger LightPercent;
    
    NSDate *LastSendTime;
    NSUserDefaults *userDefaults;
}

@end

@implementation WhiteLightVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    LightPercent=100;
    self.title=NSLocalizedStringFromTable(@"Lighting_Bulb", @"Localizable", nil);
    [self addRotationGestureToView:[self MyImageView]];
    
    userDefaults= [NSUserDefaults standardUserDefaults];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        int ChangeTag=0;
        BOOL ChangeAdd=YES;
        while (YES) {
            //通知主线程刷新
            ChangeTag=ChangeTag+1;
            if(ChangeTag>44){
                ChangeTag=0;
                ChangeAdd=!ChangeAdd;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                //回调或者说是通知主线程刷新
                if (ChangeAdd) {
                    [_MyBreathImage setFrame:CGRectMake(ScreenWidth*0.5-50-ChangeTag*0.5, ScreenHeight*0.5-50-ChangeTag*0.5, 100+ChangeTag, 100+ChangeTag)];
                }else{
                    [_MyBreathImage setFrame:CGRectMake(ScreenWidth*0.5-72+ChangeTag*0.5, ScreenHeight*0.5-72+ChangeTag*0.5, 144-ChangeTag, 144-ChangeTag)];
                }
            });
            [NSThread sleepForTimeInterval:0.05];
        }
    });
    
    UIPanGestureRecognizer *panGesture=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    [self.MyPanImageView addGestureRecognizer:panGesture];
    MyRotation=M_PI/16+M_PI*2;
    
    LastSendTime= [[NSDate alloc]init];
    
}
- (void)panAction:(UIPanGestureRecognizer *)recognizer{
    if (recognizer.state==UIGestureRecognizerStateBegan) {
        NSLog(@"start");
        curTickleStart = [recognizer translationInView:self.view];
    }else if(recognizer.state==UIGestureRecognizerStateChanged){
        NSLog(@"changed");
        CGPoint point = [recognizer translationInView:self.view];

        LightPercent+=(curTickleStart.y-point.y)/4;
        if (LightPercent>100) {
            LightPercent=100;
        }else if(LightPercent<0){
            LightPercent=0;
        }
        _MyLabel.text=[NSString stringWithFormat:@"%ld",(long)LightPercent];
    }else if (recognizer.state==UIGestureRecognizerStateEnded) {
        NSLog(@"end ");
        char strcommand[8]={'A','T','#','L','1','*','*','*'};
        strcommand[5] = LightPercent;
        strcommand[6] =0X0D;
        strcommand[7] =0X0A;
        NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    }else if(recognizer.state==UIGestureRecognizerStateCancelled){
        NSLog(@"cancel");
    }
    curTickleStart = [recognizer translationInView:self.view];
    
}
- (void)addRotationGestureToView:(UIView *)view
{
    KTOneFingerRotationGestureRecognizer *rotation = [[KTOneFingerRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotating:)];
    [view addGestureRecognizer:rotation];
}

- (void)rotating:(KTOneFingerRotationGestureRecognizer *)recognizer
{
    UIView *view = [recognizer view];
    CGFloat nowRotation=[recognizer rotation];
    MyRotation+=nowRotation;
    [view setTransform:CGAffineTransformRotate([view transform], [recognizer rotation])];
    
    if (MyRotation>M_PI*2) {
        MyRotation-=M_PI*2;
    }else if (MyRotation<0){
        MyRotation+=M_PI*2;
    }
    int lengbai=MyRotation*0.5/M_PI*255;//L2X
    int nuanbai=255-lengbai;//L3X
//    NSLog(@"%d,%d",lengbai,nuanbai);
    
    if ([LastSendTime timeIntervalSinceNow]<-0.1) {
        LastSendTime=[[NSDate alloc]init];
        char strcommand[9]={'A','T','#','L','2','*','*','*','*'};
        strcommand[5] = lengbai;
        strcommand[6] = nuanbai;
        strcommand[7] =0X0D;
        strcommand[8] =0X0A;
        NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
        NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
    }else{
        return;
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)YeDengAction:(UIButton *)sender {
    _MyLabel.text=@"10";
    char strcommand[8]={'A','T','#','L','1','*','*','*'};
    strcommand[5] = 10;
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

- (IBAction)OpenOrCloseLightAction:(UIButton *)sender {
    char strcommand[8]={'A','T','#','L','E','1'};
    strcommand[6] =0X0D;
    strcommand[7] =0X0A;
    if (![userDefaults boolForKey:@"ColorOnOff"]) {
        NSLog(@"====");
        strcommand[5] ='0';
        [userDefaults setBool:YES forKey:@"ColorOnOff"];
        [_OpenOrCloseButton setImage:[UIImage imageNamed:@"Edit_Onoff_Icon_Off_White"] forState:UIControlStateNormal];
    }else{
        NSLog(@"---");
        strcommand[5] ='1';
        [userDefaults setBool:NO forKey:@"ColorOnOff"];
        [_OpenOrCloseButton setImage:[UIImage imageNamed:@"Edit_Onoff_Icon_On_White"] forState:UIControlStateNormal];
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}
@end

//
//  tb_2_graphic.h
//  xiangmu_1
//
//  Created by liu xiaotao008 on 12-3-14.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface draw_graphic : UIView

@end

//
//  tb_2_graphic.m
//  xiangmu_1
//
//  Created by liu xiaotao008 on 12-3-14.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "draw_graphic.h"
#define  radius 84

@implementation draw_graphic
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    return self;
}
//当调用setNeedsDisplay时由系统调用

-(void)drawRect:(CGRect)rect
{
    
    //CG绘制三角形
    CGContextRef ctx=UIGraphicsGetCurrentContext();
    CGContextBeginPath(ctx);
    CGContextMoveToPoint(ctx, radius+radius, radius);
    CGContextAddArc(ctx, radius, radius, radius, 0,2*M_PI, 0);
    CGContextAddLineToPoint(ctx,radius, radius);
    CGContextClosePath(ctx);
    [[UIColor colorWithRed:244.0/255.0 green:244.0/255.0 blue:244.0/255.0 alpha:1] setFill];
    [[UIColor clearColor] setStroke];//设置边框颜色
    CGContextDrawPath(ctx, kCGPathFillStroke);
  
}


@end

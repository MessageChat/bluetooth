//
//  AppDelegate.h
//  wenyeBLE
//
//  Created by 陈双超 on 15/1/4.
//  Copyright (c) 2015年 陈双超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  AppDelegate.h
//  BabyTestStub
//
//  Created by ZTELiuyw on 16/3/14.
//  Copyright © 2016年 liuyanwei. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end


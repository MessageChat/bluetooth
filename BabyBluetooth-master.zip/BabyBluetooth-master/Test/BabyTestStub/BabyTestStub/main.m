//
//  main.m
//  BabyTestStub
//
//  Created by ZTELiuyw on 16/3/14.
//  Copyright © 2016年 liuyanwei. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}

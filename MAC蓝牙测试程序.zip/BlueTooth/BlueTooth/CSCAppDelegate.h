//
//  CSCAppDelegate.h
//  BlueTooth
//
//  Created by apple on 14-8-5.
//  Copyright (c) 2014年 ___FULLUSERNAME___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CSCAppDelegate : NSObject <NSApplicationDelegate,CBCentralManagerDelegate,CBPeripheralDelegate,NSTableViewDataSource,NSTableViewDelegate>{
    BOOL canSendMes;//判断是否找到了发送信息的特性
    BOOL isLightOpen;
    NSDateFormatter *formatter;
}

@property (assign) IBOutlet NSWindow *window;

@property (strong,nonatomic) CBCentralManager * cbCentralMgr;//蓝牙中心管理器

@property (strong,nonatomic)NSMutableArray *blueToothArray;
@property (weak) IBOutlet NSScrollView *myScrollView;
@property (weak) IBOutlet NSTableView *myNSTableView;
@property (weak) IBOutlet NSTextField *logString;

- (IBAction)searchAction:(id)sender;
- (IBAction)selectAll:(id)sender;
- (IBAction)openOrClose:(id)sender;
- (IBAction)colorSet:(NSButton*)sender;
- (IBAction)autoAction:(id)sender;

@end

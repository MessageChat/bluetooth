//
//  CSCAppDelegate.m
//  BlueTooth
//
//  Created by apple on 14-8-5.
//  Copyright (c) 2014年 ___FULLUSERNAME___. All rights reserved.
//

#import "CSCAppDelegate.h"

#import "CheckBoxCell.h"
#import "ProgressCell.h"
#import "TextCell.h"

@implementation CSCAppDelegate
@synthesize myNSTableView;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    _blueToothArray=[[NSMutableArray alloc]initWithCapacity:0];
    // Insert code here to initialize your application
    self.cbCentralMgr = [[CBCentralManager alloc] initWithDelegate:self queue:nil];//蓝牙操作中心
    self.cbCentralMgr.delegate=self;
    isLightOpen=YES;
    
    formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat : @"HH:mm:ss SSS"];
    
    
    [myNSTableView setDelegate:self];
    [myNSTableView setDataSource:self];
    
    [myNSTableView.window setAcceptsMouseMovedEvents:YES];
    [myNSTableView setUsesAlternatingRowBackgroundColors:NO];//取消行与行之间蓝白交替显示的背景
    
    [_myScrollView setDocumentView:myNSTableView];
    [_myScrollView setHasVerticalScroller:YES];
}

/* Returns the column index at 'point', or -1 if 'point' is outside of all table columns.
 */
-(void)awakeFromNib{
    
    
}

//     其次是在高度返回值中处理：
- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row
{
    return 30;
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    return [self.blueToothArray count];
}


////显示每行的视图,这个改变文字的颜色viewForTableColumn。我从界面生成器读取tableCellView。
- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    
    float height = [tableView rowHeight];
    NSTableCellView * cell = [tableView makeViewWithIdentifier:[tableColumn identifier] owner:self];
    if([[tableColumn identifier] intValue] == 1001) {
        cell = [[CheckBoxCell alloc]initWithFrame:NSMakeRect(0, 0, 100, height)];
        if (((CBPeripheral *)([self.blueToothArray objectAtIndex:(int)row])).state==0)
        {
            ((CheckBoxCell*)cell).checkBox.title=@"未连接";
            [((CheckBoxCell*)cell).checkBox setAction:@selector(selectAction:)];
        }else if (((CBPeripheral *)([self.blueToothArray objectAtIndex:(int)row])).state==1){
            ((CheckBoxCell*)cell).checkBox.title=@"连接中";
            ((CheckBoxCell*)cell).checkBox.state=1;
        }else{
            ((CheckBoxCell*)cell).checkBox.title=@"已连接";
            ((CheckBoxCell*)cell).checkBox.state=1;
        }
        
        ((CheckBoxCell*)cell).checkBox.tag=row;
        
    }else if([[tableColumn identifier] intValue] == 1002) {
        cell = [[TextCell alloc]initWithFrame:NSMakeRect(0, 0, 250, height)];
        ((TextCell*)cell).text.stringValue=[((CBPeripheral *)[self.blueToothArray objectAtIndex:row]).identifier UUIDString];
        ((TextCell*)cell).text.frame=NSMakeRect(0, 0, 350, 24);
    }else if([[tableColumn identifier] intValue] == 1003) {
        cell = [[TextCell alloc]initWithFrame:NSMakeRect(0, 0, 108, height)];
        ((TextCell*)cell).text.stringValue=((CBPeripheral *)[self.blueToothArray objectAtIndex:row]).name;
        ((TextCell*)cell).text.frame=NSMakeRect(0, 0, 108, 24);
    }
    return cell;
}

-(void)selectAction:(NSButton *)sender{
    NSLog(@"是否选中:%d",(int)sender.state);
    NSLog(@"点击行数:%d",(int)sender.tag);
    if (((CBPeripheral *)([self.blueToothArray objectAtIndex:(int)sender.tag])).state==0) {
        [self.cbCentralMgr connectPeripheral:[self.blueToothArray objectAtIndex:(int)sender.tag] options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
    }
}

/*==========================================================================================
 *    设置某行是否可以被选中，返回YES,则可以选中，返回NO 则不可选中，即没有高亮选中
 *    用于控制某一行是否可以被选中，前提是selectionShouldChangeInTableView:必须返回YES
 *===========================================================================================*/

- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row
{
    NSLog(@"I'm allow you to select:%ld",row);
    return YES;
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBCentralManagerStateUnknown:
        {
            [self addLog:@"State Unknown"];
        }
            break;
        case CBCentralManagerStateResetting:{
            [self addLog:@"State Resetting"];
        }
            break;
        case CBCentralManagerStateUnsupported:
        {
            [self addLog:@"State Unsupported"];
        }
            break;
        case CBCentralManagerStateUnauthorized:{
            [self addLog:@"State Unauthorized"];
        }
            break;
        case CBCentralManagerStatePoweredOff:
        {
            [self addLog:@"State PoweredOff"];
        }
            break;
        case CBCentralManagerStatePoweredOn:
        {
            [self addLog:@"State PoweredOn"];
            [self searchAction:nil];
        }
            break;
        default:
            break;
    }
}





-(void)addLog:(NSString*)log{
    NSDate *date=[NSDate date];
    _logString.stringValue=[NSString stringWithFormat:@"%@ %@",[formatter stringFromDate:date],log];
    NSLog(@"%@ %@",date,log);
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    if ([[advertisementData allKeys] count]==1) {
        [self addLog:[NSString stringWithFormat:@"发现设备:%@",peripheral.name]];
        [self.blueToothArray addObject:peripheral];
        [self.myNSTableView reloadData];
    }else{
        NSLog(@"设备信息不完整");
    }
    
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    [self.myNSTableView reloadData];
    [self addLog:@"设备已连上，设置委托为当前视图"];
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
    
}
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    [self addLog:@"失去连接"];
    [self.myNSTableView reloadData];
    [self addLog:peripheral.name];
   
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error
{
    //这个方法不会被调用，不获取设备相关信息，近获取通信特性信息
    [self addLog:[NSString stringWithFormat:@"获取到%@设备相关信息",peripheral.name]];
    for (CBService * server in service.includedServices) {
        NSLog(@"设备信息:%@",server);
    }
    
}

//返回的蓝牙特征值通知代理
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    [self addLog:@"获取到设备特性"];
    
    for (CBCharacteristic * characteristic in service.characteristics) {
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        Byte byteData[20] = {0x10, 0x52, 0x90, 0xe8, 0x08, 0x02, 0x18, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0xb4, 0xf2, 0xd3, 0xd6, 0xd0};
        NSData * data = [NSData dataWithBytes:byteData length:20];
        [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
        [NSThread sleepForTimeInterval:0.1];
        
        Byte byteData1[13] = {0x10, 0xcb, 0xde, 0x4d, 0xa0, 0x9c, 0x26, 0x8c, 0x95, 0x7f, 0xf8, 0x97, 0x94};
        data = [NSData dataWithBytes:byteData1 length:20];
        [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
    }
    
    for (CBCharacteristic * characteristic in service.characteristics) {
        
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID_5]])
        {
            char strcommand[12]={'c','*','1','2','3','4','5','6','7','8','h'};
            strcommand[1]=1;
            NSData *cmdData = [NSData dataWithBytes:strcommand length:12];
            NSLog(@"发送认证密码");
            [peripheral writeValue:cmdData forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
        }
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:TRANSFER_CHARACTERISTIC_UUID_4]])
        {
            NSLog(@"设置可以双向处理");
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
    }
}
//peripheral:didUpdateValueForCharacteristic:error
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"%@读取到值，接收到数据",peripheral.name);
}
- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    NSLog(@"%@写数据:%@",peripheral.name,characteristic.value);
    [self addLog:[NSString stringWithFormat:@"%@写数据",peripheral.name]];
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    
    [self addLog:@"收到特性状态的更新通知"];
}

//返回的蓝牙服务通知通过代理
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    [self addLog:@"发现蓝牙服务，启动特性搜索"];
    for (CBService* service in peripheral.services)
    {
        //查询服务所带的特征值
        [peripheral discoverCharacteristics:nil forService:service];
        //获取设备信息，保留，以后可能用到
//        [peripheral discoverIncludedServices:nil forService:service];
    }
}
- (IBAction)searchAction:(id)sender {
    //将当前所有连接的蓝牙断开重新搜索
    for (int i=0; i<[self.blueToothArray count]; i++) {
        CBPeripheral * peripheral=[self.blueToothArray objectAtIndex:i];
        if (peripheral.state!=0) {
            [self.cbCentralMgr cancelPeripheralConnection:peripheral];
        }
    }
    [self.blueToothArray removeAllObjects];
    
    [self.cbCentralMgr stopScan];
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO],CBCentralManagerScanOptionAllowDuplicatesKey, nil];
    [self.cbCentralMgr scanForPeripheralsWithServices:nil options:dic];
}

- (IBAction)selectAll:(id)sender {
    for (int i=0 ;i<[self.blueToothArray count]; i++)
    {
        if (((CBPeripheral *)([self.blueToothArray objectAtIndex:i])).state==0) {
            [self.cbCentralMgr connectPeripheral:[self.blueToothArray objectAtIndex:i] options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
        }
    }
}

- (IBAction)openOrClose:(id)sender {
    isLightOpen=!isLightOpen;
    char strcommand[9]={'s','*','*','*','*','*','1','e'};
    if (isLightOpen)
    {
        strcommand[6]=2;
    }else
    {
        strcommand[6]=1;
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:9];
    [self sendDatawithCharacteristic:TRANSFER_CHARACTERISTIC_UUID_1 data:cmdData];
}

- (IBAction)colorSet:(NSButton*)sender {
    
    char strcommand[8]={'s','*','*','*','*','*','1','e'};
    if ([sender.title isEqualToString:@"绿色"]){
        
        strcommand [1] =255-0;
        strcommand [2] =255-255;
        strcommand [3] =255-0;
        strcommand [4] =255-0;
        strcommand[6] =3;
    }else if ([sender.title rangeOfString:@"红"].length  > 0){
        
        strcommand [1] =255-255;
        strcommand [2] =255-0;
        strcommand [3] =255-0;
        strcommand [4] =255-0;
        strcommand[6] =3;
    }else if ([sender.title rangeOfString:@"蓝"].length  > 0){
        
        strcommand [1] =255-0;
        strcommand [2] =255-0;
        strcommand [3] =255-255;
        strcommand [4] =255-0;
        strcommand[6] =3;
    }
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    
    //即使数据发送失败，也依然是开关灯执行后的状态
    [self sendDatawithCharacteristic:TRANSFER_CHARACTERISTIC_UUID_1 data:cmdData];
    
}

- (IBAction)autoAction:(id)sender {
    NSLog(@"autoAction");
    double delayInSeconds = 2.0;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void)
    {
        isLightOpen=YES;
        NSLog(@"dispatch_after1");
        [self openOrClose:nil];
        
    });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2*delayInSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void)
   {
       NSLog(@"dispatch_after2");
       isLightOpen=NO;
       [self openOrClose:nil];
       
   });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 3*delayInSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void)
   {
       NSLog(@"dispatch_after3");
       NSButton *btn=[[NSButton alloc]init];
       btn.title=@"红色";
       [self colorSet:btn];
       
   });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 4*delayInSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void)
   {
       NSLog(@"dispatch_after4");
       NSButton *btn=[[NSButton alloc]init];
       btn.title=@"绿色";
       [self colorSet:btn];
   });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 5*delayInSeconds * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void)
   {
       NSLog(@"dispatch_after5");
       NSButton *btn=[[NSButton alloc]init];
       btn.title=@"蓝色";
       [self colorSet:btn];
   });

    
   
}
//根据蓝牙对象和特性发送数据
-(void)sendDatawithCharacteristic:(NSString*)characteristicStr data:(NSData*)data {
    
    for (int i=0 ;i<[self.blueToothArray count]; i++)
    {
        //对每一个序号找到对应的蓝牙对象进行操作
        CBPeripheral *peripheral=(CBPeripheral *)[self.blueToothArray objectAtIndex:i];
        if (((CBPeripheral *)([self.blueToothArray objectAtIndex:i])).state!=2)
        {
            continue;
        }
        for (CBCharacteristic *characteristic in [[peripheral.services objectAtIndex:3] characteristics])
        {
            if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:characteristicStr]])
            {
                [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
            }
        }
    }
}
@end

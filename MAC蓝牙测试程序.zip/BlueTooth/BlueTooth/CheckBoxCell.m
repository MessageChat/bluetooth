//
//  CheckBoxCell.m
//  TestTableView
//
//  Created by caobin on 12-12-21.
//  Copyright (c) 2012年 caobin. All rights reserved.
//

#import "CheckBoxCell.h"

@implementation CheckBoxCell
@synthesize checkBox;

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
        checkBox= [[NSButton alloc]initWithFrame:NSMakeRect(10, 0, 100, 30)];
        [checkBox setButtonType:NSSwitchButton];
        [checkBox setAutoresizesSubviews:YES];
        [checkBox setFont:[NSFont systemFontOfSize:14]];
        [checkBox setTitle:@"Click me"];
        
        [self addSubview:checkBox];
    }
    
    return self;
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Drawing code here.
}

@end

//
//  ProgressCell.h
//  TestTableView
//
//  Created by caobin on 12-12-21.
//  Copyright (c) 2012年 caobin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ProgressCell : NSTableCellView

@end

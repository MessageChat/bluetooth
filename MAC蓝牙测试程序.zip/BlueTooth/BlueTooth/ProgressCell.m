//
//  ProgressCell.m
//  TestTableView
//
//  Created by caobin on 12-12-21.
//  Copyright (c) 2012年 caobin. All rights reserved.
//

#import "ProgressCell.h"

@implementation ProgressCell

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.

        
        NSImageView * progress1View = [[NSImageView alloc]initWithFrame:NSMakeRect(60,10, 130 , 7)];
        [progress1View setImageScaling:NSImageScaleAxesIndependently];
        [progress1View setImage:[NSImage imageNamed:@"progress1"]];
        
        NSImageView * progress2View = [[NSImageView alloc] initWithFrame:NSMakeRect(10, 10, 50 , 7)];
        [progress2View setImageScaling:NSImageScaleAxesIndependently];
        [progress2View setImage:[NSImage imageNamed:@"progress2"]];
        
        [self addSubview:progress1View];
        [self addSubview:progress2View];
    }
    
    return self;
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Drawing code here.
}

-(void)mouseDown:(NSEvent *)theEvent
{
    
}

@end

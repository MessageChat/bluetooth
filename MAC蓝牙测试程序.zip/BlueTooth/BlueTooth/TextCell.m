//
//  TextCell.m
//  TestTableView
//
//  Created by caobin on 12-12-21.
//  Copyright (c) 2012年 caobin. All rights reserved.
//

#import "TextCell.h"

@implementation TextCell
@synthesize text;

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
        text = [[NSTextField alloc]initWithFrame: NSMakeRect(0, 0, 350, 14)];
        [text setFont:[NSFont systemFontOfSize:12]];
        [text setBackgroundColor:[NSColor clearColor]];
        [text setAlignment:NSCenterTextAlignment];
        [text setAutoresizesSubviews:YES];
        [text setEditable:NO];
        [text setSelectable:NO];
        
        [text setBezeled:NO];
        
        [self addSubview:text];
    }
    return self;
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Drawing code here.
    [super drawRect:dirtyRect];
}


@end


//
//  Test1.m
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test1.h"

@implementation Test1


- (void)testProtocols{
    NSLog(@"遵守了这个协议的一个类%s",__func__);
}

@end

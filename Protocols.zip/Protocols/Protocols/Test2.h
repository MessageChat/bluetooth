//
//  Test2.h
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Test_Protocols.h"

@interface Test2 : NSObject<Test_Protocols>

@end

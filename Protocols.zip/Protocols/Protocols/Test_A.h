//
//  Test_A.h
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test1.h"

@interface Test_A : Test1

@end

//
//  Test_A.m
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_A.h"

@implementation Test_A


- (void)testProtocols{
    [super testProtocols];
    NSLog(@"重写了这个协议的一个类%s",__func__);
}

@end

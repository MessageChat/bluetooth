//
//  Test_Protocols.h
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import <Foundation/Foundation.h>


///这是一个协议
@protocol Test_Protocols <NSObject>

@required

- (void)testProtocols;

@end


///这是一个类
@interface Test_Protocols : NSObject<Test_Protocols>

@end

//
//  Test_Protocols.m
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "Test_Protocols.h"


@interface Test_Protocols ()

@end

@implementation Test_Protocols


- (void)testProtocols{
    NSLog(@"即是一个协议,又是一个类%s",__func__);
}

@end

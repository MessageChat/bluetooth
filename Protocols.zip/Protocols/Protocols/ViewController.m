//
//  ViewController.m
//  Protocols
//
//  Created by 郑冰津 on 16/8/31.
//  Copyright © 2016年 IceGod. All rights reserved.
//

#import "ViewController.h"
#import "Test_Protocols.h"
#import "Test_A.h"
#import "Test2.h"
#import "Test1.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    Test_Protocols *tp = [Test_Protocols new];
    [tp testProtocols];
    Test1 *t1 = [Test1 new];
    [t1 testProtocols];
    Test2 *t2 = [Test2 new];
    [t2 testProtocols];
    Test_A *tA = [Test_A new];
    [tA testProtocols];
}



@end

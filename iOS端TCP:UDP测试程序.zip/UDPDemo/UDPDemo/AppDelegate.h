//
//  AppDelegate.h
//  UDPDemo
//
//  Created by Leo Lin on 3/12/14.
//  Copyright (c) 2014 Leo Lin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

//
//  CommonClass.h
//  newProject2
//
//  Created by csc on 14-1-20.
//  Copyright (c) 2014年 csc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CommonClass : NSObject

//发送数据时,16进制数－>Byte数组->NSData
+(NSData *)hexToByteToNSData:(NSString *)str;

//接收数据时,NSData－>Byte数组->16进制数
+(NSString *)NSDataToByteTohex:(NSData *)data;

//发送数据时,16进制数－>Byte数组->NSArray
+(NSArray *)hexToByteToNSArray:(NSString *)str;

//发送数据时,16进制数－>Byte数组->NSString
+(NSString *)hexToByteToNSString:(NSString *)str;

//将汉字字符串转换成UTF8字符串
+(NSString *)chineseToUTf8Str:(NSString*)chineseStr;

//将十六进制字符串转换成汉字
+(NSString*)changeLanguage:(NSString*)chinese;

//正则表达式
+(BOOL)isValidateString:(NSString *)matchStr pattern:(NSString*)pattern;

//对字符串进行MD5加密
+ (NSString *)md5:(NSString *)str;

//将汉字字符串转换成16进制字符串
+(NSString *)chineseToHex:(NSString*)chineseStr;




//将十进制转化为十六进制
+ (NSString *)ToHex:(uint16_t)tmpid;

//十六进制数转十进制数,个数不一样
+(int)TotexHex1:(NSString*)tmpid;

//十六进制数转十进制数
+(int)TotexHex:(NSString*)tmpid;




@end

//
//  CommonClass.m
//  newProject2
//
//  Created by csc on 14-1-20.
//  Copyright (c) 2014年 csc. All rights reserved.
//

#import "CommonClass.h"
#import <CommonCrypto/CommonCrypto.h>

@implementation CommonClass


//将十进制转化为十六进制
+ (NSString *)ToHex:(uint16_t)tmpid
{
    NSString *nLetterValue;
    NSString *str =@"";
    uint16_t ttmpig;
    for (int i = 0; i<9; i++) {
        ttmpig=tmpid%16;
        tmpid=tmpid/16;
        switch (ttmpig)
        {
            case 10:
                nLetterValue =@"A";break;
            case 11:
                nLetterValue =@"B";break;
            case 12:
                nLetterValue =@"C";break;
            case 13:
                nLetterValue =@"D";break;
            case 14:
                nLetterValue =@"E";break;
            case 15:
                nLetterValue =@"F";break;
            default:
                nLetterValue = [NSString stringWithFormat:@"%u",ttmpig];
                
        }
        str = [nLetterValue stringByAppendingString:str];
        if (tmpid == 0) {
            break;
        }
    }
    if ([str length]==2) {
        str=[NSString stringWithFormat:@"%@00",str];
    }else if ([str length]==1){
        str=[NSString stringWithFormat:@"0%@00",str];
    }else if ([str length]==3){
        str=[NSString stringWithFormat:@"%@0%@",[str substringFromIndex:1],[str substringToIndex:1]];
    }
    return str;
}



//接收数据时,NSData－>Byte数组->16进制数
+(NSString *)NSDataToByteTohex:(NSData *)data{
    Byte *bytes = (Byte *)[data bytes];
    NSString *hexStr=@"";
    for(int i=0;i<[data length];i++)
    {
        NSString *newHexStr= [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr;
}
//发送数据时,16进制数－>Byte数组->NSString
+(NSString *)hexToByteToNSString:(NSString *)str{
    int j=0;
    Byte bytes[[str length]/2];
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        j++;
    }
    NSString *astr=[[NSString alloc]initWithBytes:bytes length:[str length]/2 encoding:NSASCIIStringEncoding];
    return astr;
}

//发送数据时,16进制数－>Byte数组->NSArray
+(NSArray *)hexToByteToNSArray:(NSString *)str{
    
    int j=0;
    Byte bytes[[str length]/2];
    NSMutableArray *astr=[[NSMutableArray alloc]initWithCapacity:0];
    if ([str length]%2!=0) {
        return nil;
    }
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        if (bytes[j]==0) {
            NSStringEncoding encodingGB18030= CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            NSString* TemStr=[[NSString alloc]initWithBytes:bytes length:j encoding:encodingGB18030];
            
            
            [astr addObject:TemStr];
            
            j=-1;
            
        }
        j++;
    }
    
    
    return astr;
}



//将时间戳转换成NSDate
+(NSDate *)changeSpToTime:(NSString*)spString{
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[spString intValue]];
    return confromTimesp;
}

//将汉字字符串转换成UTF8字符串
+(NSString *)chineseToUTf8Str:(NSString*)chineseStr{
    NSStringEncoding encodingUTF8 = NSUTF8StringEncoding;
    NSData *responseData2 =[chineseStr dataUsingEncoding:encodingUTF8 ];
    NSString *string=[CommonClass NSDataToByteTohex:responseData2];
    return string;
}


//将十六进制字符串转换成汉字
+(NSString*)changeLanguage:(NSString*)chinese{
    NSString *strResult;
    if (chinese.length%2==0) {
        //第二次转换
        NSData *newData = [CommonClass hexToByteToNSData:chinese];
        unsigned long encode = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        strResult = [[NSString alloc] initWithData:newData encoding:encode];
    }else{
        NSString *strResult = @"已假定是汉字的转换，所传字符串的长度必须是2的倍数!";
        NSLog(@"strResult:%@",strResult);
        return NULL;
    }
    return strResult;
}

//正则表达式
+(BOOL)isValidateString:(NSString *)matchStr pattern:(NSString*)pattern
{
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",pattern];
    return [emailTest evaluateWithObject:matchStr];
}

////将汉字字符串转换成16进制字符串
+(NSString *)chineseToHex:(NSString*)chineseStr{
    NSStringEncoding encodingGB18030= CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *responseData =[chineseStr dataUsingEncoding:encodingGB18030 ];
    NSString *string=[CommonClass NSDataToByteTohex:responseData];
    return string;
}
+ (NSString *)md5:(NSString *)str
{
    if(str == nil || [str length] == 0)
        return nil;
    
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, (int)strlen(cStr), result); // This is the md5 call
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}




//发送数据时,16进制数－>Byte数组->NSData
+(NSData *)hexToByteToNSData:(NSString *)str{
    int j=0;
    Byte bytes[[str length]/2];
    for(int i=0;i<[str length];i++)
    {
        int int_ch;  ///两位16进制数转化后的10进制数
        unichar hex_char1 = [str characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        unichar hex_char2 = [str characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        int_ch = int_ch1+int_ch2;
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        
        j++;
    }
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:[str length]/2 ];
    return newData;
}





//十六进制数转十进制数
+(int)TotexHex1:(NSString*)tmpid
{
    int int_ch;  ///两位16进制数转化后的10进制数
    unichar hex_char1 = [tmpid characterAtIndex:0]; ////两位16进制数中的第一位(高位*16)
    int int_ch1;
    if(hex_char1 >= '0' && hex_char1 <='9')
        int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
    else if(hex_char1 >= 'A' && hex_char1 <='F')
        int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
    else
        int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
    unichar hex_char2 = [tmpid characterAtIndex:1]; ///两位16进制数中的第二位(低位)
    int int_ch2;
    if(hex_char2 >= '0' && hex_char2 <='9')
        int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
    else if(hex_char2 >= 'A' && hex_char2 <='F')
        int_ch2 = (hex_char2-55); //// A 的Ascll - 65
    else
        int_ch2 = (hex_char2-87); //// a 的Ascll - 97
    int_ch = int_ch1+int_ch2;
    
    return int_ch;
}
//十六进制数转十进制数
+(int)TotexHex:(NSString*)tmpid
{
    int int_ch;  ///两位16进制数转化后的10进制数
    unichar hex_char1 = [tmpid characterAtIndex:0]; ////两位16进制数中的第一位(高位*16)
    int int_ch1;
    if(hex_char1 >= '0' && hex_char1 <='9')
        int_ch1 = (hex_char1-48)*16*16;   //// 0 的Ascll - 48
    else if(hex_char1 >= 'A' && hex_char1 <='F')
        int_ch1 = (hex_char1-55)*16*16; //// A 的Ascll - 65
    else
        int_ch1 = (hex_char1-87)*16*16; //// a 的Ascll - 97
    unichar hex_char2 = [tmpid characterAtIndex:1]; ///两位16进制数中的第二位(低位)
    int int_ch2;
    if(hex_char2 >= '0' && hex_char2 <='9')
        int_ch2 = (hex_char2-48)*16; //// 0 的Ascll - 48
    else if(hex_char2 >= 'A' && hex_char2 <='F')
        int_ch2 = (hex_char2-55)*16; //// A 的Ascll - 65
    else
        int_ch2 = (hex_char2-87)*16; //// a 的Ascll - 97
    
    unichar hex_char3 = [tmpid characterAtIndex:2]; ///两位16进制数中的第二位(低位)
    int int_ch3;
    if(hex_char3 >= '0' && hex_char3 <='9')
        int_ch3 = (hex_char3-48); //// 0 的Ascll - 48
    else if(hex_char3 >= 'A' && hex_char3 <='F')
        int_ch3 = (hex_char3-55); //// A 的Ascll - 65
    else
        int_ch3 = (hex_char3-87); //// a 的Ascll - 97
    
    int_ch = int_ch1+int_ch2 +int_ch3;
    
    return int_ch;
}


@end

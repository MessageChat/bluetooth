//
//  UDPDemoViewController.h
//  UDPDemo
//
//  Created by Leo Lin on 3/12/14.
//  Copyright (c) 2014 Leo Lin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CFNetwork/CFNetwork.h>
#import "AsyncUdpSocket.h"
#import "AsyncSocket.h"

@interface UDPDemoViewController : UIViewController
{
    AsyncSocket  *sendSocket;
    AsyncUdpSocket *udpSocket;
    NSDateFormatter *formatter;
}
@property (nonatomic, strong)AsyncSocket  *sendSocket;

@property (weak, nonatomic) IBOutlet UITextField *MyTextField;
@property (weak, nonatomic) IBOutlet UITextField *IPTextField;
@property (weak, nonatomic) IBOutlet UITextField *PortTextField;
@property (weak, nonatomic) IBOutlet UITextView *MyTextView;
@property (assign)long tag;
@property (weak, nonatomic) IBOutlet UIImageView *myImage;

- (IBAction)SendUDPMessage;
- (IBAction)clearAction:(id)sender;
- (IBAction)connectTCPSocket:(id)sender;
- (IBAction)sendMessage:(id)sender;


@end

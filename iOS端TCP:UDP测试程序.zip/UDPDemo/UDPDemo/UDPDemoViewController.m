//
//  UDPDemoViewController.m
//  UDPDemo
//
//  Created by Leo Lin on 3/12/14.
//  Copyright (c) 2014 Leo Lin. All rights reserved.
//

#import "UDPDemoViewController.h"
#import <ifaddrs.h>
#include <sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import "CommonClass.h"


//#define HOST_IP @"192.168.1.114"
//5001

//"UG1#"   拍摄一副320*240
//"UG2#"   拍摄一副640*480
//"UG3#"   拍摄一副1280*720
//"UG4#"   拍摄一副1920*1080

//SQ


@interface UDPDemoViewController (){
    NSMutableString *nowStr;
    NSMutableString *IPString;
    
    NSMutableString *resultStr;
    float Port;
}

@end

@implementation UDPDemoViewController
@synthesize MyTextView,MyTextField,IPTextField,PortTextField;
@synthesize sendSocket = _sendSocket;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        formatter = [[NSDateFormatter alloc] init];
        NSTimeZone *timeZone = [NSTimeZone localTimeZone];
        [formatter setTimeZone:timeZone];
        [formatter setDateFormat : @"HH:mm:ss SSS"];
        
//        udpSocket = [[AsyncUdpSocket alloc] initWithDelegate:self];
//        
//        NSError *error = nil;
//        
//        if (![udpSocket bindToPort:988 error:&error])
//        {
//            [self logString:[NSString stringWithFormat:@"UDP绑定接收端口错误: %@", error]];
//        }
//        
//        if (![udpSocket enableBroadcast:YES error:&error]) {
//            [self logString:[NSString stringWithFormat:@"UDP发送使能错误: %@", error]];
//        }
//        
//        
//        [udpSocket receiveWithTimeout:-1 tag:0];
//        
//        [self logString:@"Ready"];
        nowStr=[[NSMutableString alloc]initWithCapacity:0];
    }
    return self;
}
-(void)logString:(NSString*)str{
    NSLog(@"%@",str);
    NSDate *date=[NSDate date];
    [nowStr appendString:[NSString stringWithFormat:@"%@:%@",[formatter stringFromDate:date],str]];
    [nowStr appendString:@"\n"];
    MyTextView.text=nowStr;
}
//
-(void)viewWillAppear:(BOOL)animated
{
//    NSString *routerStr=[self routerIp];
//    NSLog(@"routerStr:%@",routerStr);
//    IPString=routerStr;
//    [self connectTCPSocket:nil];
    
    //设置委托为自身
//    [udpSocket setDelegate: self];
//    //启动接受线程,,同时开启TCP服务监听，以便后面建立TCP连接
//    [udpSocket receiveWithTimeout:-1 tag:0];
}

//- (NSString *) routerIp
//{
//    NSString *address = @"error";
//    struct ifaddrs *interfaces = NULL;
//    struct ifaddrs *temp_addr = NULL;
//    int success = 0;
//    
//    // retrieve the current interfaces - returns 0 on success
//    success = getifaddrs(&interfaces);
//    if (success == 0)
//    {
//        // Loop through linked list of interfaces
//        temp_addr = interfaces;
//        //*/
//        while(temp_addr != NULL)
//            
//        {
//            if(temp_addr->ifa_addr->sa_family == AF_INET)
//            {
//                // Check if interface is en0 which is the wifi connection on the iPhone
//                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"])
//                {
//                    NSString *broadcastAddress;
//                    NSString *devicesIp;
//                    NSString *netMask;
//                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
//                    broadcastAddress =[[NSString alloc ]initWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_dstaddr)->sin_addr)];
//                    devicesIp =[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
//                    netMask = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_netmask)->sin_addr)];
//                     NSLog(@"broadcastAddress:%@,devicesIp:%@,netMask:%@",broadcastAddress,devicesIp,netMask);
//                }
//            }
//            
//            temp_addr = temp_addr->ifa_next;
//        }
//    }
//    
//    // Free memory
//    freeifaddrs(interfaces);
//    
//    return address;
//}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    IPString=[NSMutableString  stringWithString:@"192.168.1.125"];
    Port=5001;
//    [self SendUDPMessage];
    
    
    UIImage *img = [UIImage imageNamed:@"ico_make.png"];
    NSData *dataObj = UIImageJPEGRepresentation(img, 1.0);
    UIImage *myimg = [UIImage imageWithData:dataObj];
    _myImage.image=myimg;
    
    
    resultStr=[[NSMutableString alloc]init];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [MyTextView resignFirstResponder];
    [MyTextField resignFirstResponder];
    [IPTextField resignFirstResponder];
    [PortTextField resignFirstResponder];
}

-(IBAction)SendUDPMessage
{
//    NSString *host = @"192.168.16.255";
//    int port = 988;
////    NSString *msg = @"getadmip";
//    NSString *msg = @"{(WHO)}";
//    if (IPTextField.text.length>10) {
//        host=IPTextField.text;
//    }
//    if (PortTextField.text.length) {
//        port=[PortTextField.text intValue];
//    }
//    if (MyTextField.text.length) {
//        msg = MyTextField.text;
//    }
//    
//    NSData *data = [msg dataUsingEncoding:NSUTF8StringEncoding];
//    [udpSocket sendData:data toHost:host port:port withTimeout:-1 tag:self.tag];
    
    UIImage *img = [UIImage imageWithData:[CommonClass hexToByteToNSData:resultStr]];
    NSLog(@"img:%@",img);
    _myImage.image=img;
    
}

- (IBAction)clearAction:(id)sender {
    [nowStr setString:@""];
    MyTextView.text=nowStr;
}

- (IBAction)connectTCPSocket:(id)sender {
    if(IPTextField.text.length>7){
        IPString=[NSMutableString stringWithString:IPTextField.text];
        
    }if (PortTextField.text.length>3) {
        Port=[PortTextField.text floatValue];
    }
    
    [self logString:[NSString stringWithFormat:@"IP:%@,端口:%.0f",IPString,Port]];
    
    BOOL connectOK = NO;
    
//    if (!_sendSocket)
//    {
    self.sendSocket = [[AsyncSocket alloc] initWithDelegate: self] ;
    
    NSError *error;
    connectOK = [_sendSocket connectToHost:IPString onPort:Port error: &error];
    if (!connectOK)
    {
        [self logString:[NSString stringWithFormat:@"TCP连接错误: %@", error]];
    }
    [_sendSocket setRunLoopModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
//    }
    NSLog(@"连接TCP");
   
}

- (IBAction)sendMessage:(id)sender {
    NSData *newData;
    if (MyTextField.text.length>0) {
        newData=[MyTextField.text dataUsingEncoding:NSUTF8StringEncoding];
        [self logString:[NSString stringWithFormat:@"发送:%@",MyTextField.text]];
    }else{
        newData = [@"UH1#" dataUsingEncoding:NSUTF8StringEncoding];
        [self logString:@"UH1#"];
    }
    
    [_sendSocket writeData: newData withTimeout: -1 tag: 0];
}

#pragma mark - UDP
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock didReceiveData:(NSData *)data withTag:(long)tag fromHost:(NSString *)host port:(UInt16)port{
    
    NSString* result;
    
    result = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    [self logString:[NSString stringWithFormat:@"Received:%@",result]];
    
    return NO;
}

- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error
{
    [self logString:@"UDP接收数据包时发生错误，原因可能是超时或者系统错误，如锁屏或者程序退到后台。"];
    
}
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error{
    [self logString:[NSString stringWithFormat:@"UDP试图发送数据包时发生错误 ！！！%@",error]];
}
- (void)onUdpSocket:(AsyncUdpSocket *)sock didSendDataWithTag:(long)tag{
    [self logString:@"udp send"];
}

- (void)onUdpSocketDidClose:(AsyncUdpSocket *)sock{
    [self logString:@"Udp closed"];
}

#pragma mark - tcp
- (void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port
{
    [self logString:[NSString stringWithFormat:@"TCP连接成功：%@",host]];
    [sock readDataWithTimeout: -1 tag: 0];
}
- (void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag
{
    [self logString:@"TCP发送数据完成"];
    [sock readDataWithTimeout: -1 tag: 0];
}
//将要断开时
-(void) onSocket:(AsyncSocket *) sock willDisConnectWithError:(NSError *)err{
    [self logString:[NSString stringWithFormat:@"将要失去连接，错误原因：%@",err]];
}
-(void)onSocket:(AsyncSocket *)sock didReadPartialDataOfLength:(NSUInteger)partialLength tag:(long)tag{
    [self logString:[NSString stringWithFormat:@"收到数据长度%d",(int)partialLength]];
}
- (NSRunLoop *)onSocket:(AsyncSocket *)sock wantsRunLoopForNewSocket:(AsyncSocket *)newSocket{
    [self logString:@"wants runloop for new socket."];
    return [NSRunLoop currentRunLoop];
}
- (BOOL)onSocketWillConnect:(AsyncSocket *)sock{
    [self logString:@"委托底层，将要连接TCP"];
    return YES;
}

// 接受数据
// 这里必须要使用流式数据
- (void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
//    [self logString:[NSString stringWithFormat:@"%@",data]];
//    [self logString:[NSString stringWithFormat:@"收到数据:%@",[[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding]]];
    [self logString:[NSString stringWithFormat:@"%lu",(unsigned long)data.length]];
    NSString *hexStr=[CommonClass NSDataToByteTohex:data];
    NSLog(@"hexStr:%@",hexStr);
//    if ([hexStr hasPrefix:@"4242"]) {
//        NSLog(@"BB");
//        resultStr=[[NSMutableString alloc]initWithString:hexStr];
//    }else if ([hexStr hasPrefix:@"4241"]){
//        NSLog(@"BA");
//        [resultStr appendString:hexStr];
//    }else if ([hexStr hasPrefix:@"4246"]){
//        NSLog(@"BF");
//        [resultStr appendString:hexStr];
//        UIImage *img = [UIImage imageWithData:[CommonClass hexToByteToNSData:resultStr]];
//        _myImage.image=img;
//    }
//    if ([hexStr rangeOfString:@"ffd8"].location!=NSNotFound) {
//        NSLog(@"ffd8:%lu,%lu",(unsigned long)[hexStr rangeOfString:@"ffd8"].location,(unsigned long)[hexStr rangeOfString:@"ffd8"].length);
//    }
//    if ([hexStr rangeOfString:@"ffd9"].location!=NSNotFound){
//        NSLog(@"ffd9:%lu,%lu",(unsigned long)[hexStr rangeOfString:@"ffd9"].location,(unsigned long)[hexStr rangeOfString:@"ffd9"].length);
//    }
    
//    UIImage *img = [UIImage imageWithData:data];
//    NSLog(@"img:%@",img);
//    _myImage.image=img;
}
- (void)onSocketDidSecure:(AsyncSocket *)sock{
    [self logString:@"onSocketDidSecure"];
}

- (void)onSocketDidDisconnect:(AsyncSocket *)sock
{
    [self logString:[NSString stringWithFormat:@"已经断开连接"]];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self logString:@"收到内存警告"];
}
- (void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket{
    [self logString:@"didAcceptNewSocket"];
}


@end

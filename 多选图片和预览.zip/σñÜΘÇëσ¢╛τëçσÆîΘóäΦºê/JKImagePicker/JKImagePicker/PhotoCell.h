//
//  PhotoCell.h
//  JKImagePicker
//
//  Created by Jecky on 15/1/16.
//  Copyright (c) 2015年 Jecky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JKAssets.h"

@interface PhotoCell : UICollectionViewCell

@property (nonatomic, strong) JKAssets  *asset;

@end

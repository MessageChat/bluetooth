//
//  ViewController.h
//  BleTest
//
//  Created by 群雄 on 15/9/21.
//  Copyright © 2015年 群雄. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreBluetooth/CoreBluetooth.h"

@interface ViewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>

@property (strong,nonatomic) CBCentralManager * MyCentralManager;

@end


//
//  ViewController.h
//  TestADData
//
//  Created by 陈双超 on 15/4/7.
//  Copyright (c) 2015年 陈双超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreBluetooth/CoreBluetooth.h"

@interface ViewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>

//CBCentralManager对象负责管理外设的发现或连接，包括扫描、发现、连接正在广播的外设。
@property (strong,nonatomic) CBCentralManager *cbCentralMgr;
@property (weak, nonatomic) IBOutlet UITextView *MyTextView;

@end


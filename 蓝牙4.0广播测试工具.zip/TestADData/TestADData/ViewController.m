//
//  ViewController.m
//  TestADData
//
//  Created by 陈双超 on 15/4/7.
//  Copyright (c) 2015年 陈双超. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    UIBarButtonItem *AllButton;
    NSDateFormatter *formatter;
    NSMutableString *MyResultStr;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    MyResultStr=[[NSMutableString alloc]init];
    formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat : @"HH:mm:ss SSS"];
    
    AllButton=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStylePlain target:self action:@selector(seachAction)];
    AllButton.tintColor=[UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = AllButton;
    
    self.cbCentralMgr = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    self.navigationController.navigationBar.backgroundColor=[UIColor darkGrayColor];
}
- (void)ClearAction{
    MyResultStr =[[NSMutableString alloc]init];
}
-(void)seachAction{
    NSLog(@"搜索");
    [self ClearAction];
    [self.cbCentralMgr stopScan];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO],CBCentralManagerScanOptionAllowDuplicatesKey, nil];
    [self.cbCentralMgr scanForPeripheralsWithServices:nil options:dic];
    
}
#pragma mark - Navigation
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
//    [self addLog:@"------------centralManagerDidUpdateState---------------"];
    switch (central.state) {
        case CBCentralManagerStateUnknown:
        breakcenterMgrStateCentralManagerStateResetting:
            [self addLog:@"State Resetting"];
            break;
        case CBCentralManagerStateUnsupported:
            [self addLog:@"State Unsupported"];
            break;
        case CBCentralManagerStateUnauthorized:
            [self addLog:@"State Unauthorized"];
            break;
        case CBCentralManagerStatePoweredOff:
            [self addLog:@"系统蓝牙被关闭"];
            break;
        case CBCentralManagerStatePoweredOn:
            [self addLog:@"系统蓝牙已开启"];
            [self seachAction];
            break;
        default:
            [self addLog:@"State  未知"];
            break;
    }
    
}
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
//    [self addLog:@"------------didDiscoverPeripheral---------------"];
    NSLog(@"能发现设备:%@，%@",peripheral.name,peripheral);
    [self addLog:[NSString stringWithFormat:@"%@",peripheral]];
    [self addLog:[NSString stringWithFormat:@"%@",advertisementData]];
}
-(void)addLog:(NSString*)log{
    
    NSDate *date=[NSDate date];
    NSString *StringTemp=[NSString stringWithFormat:@"\n%@ :%@\n",[formatter stringFromDate:date],log];
    NSLog(@"------------%@",MyResultStr);
    NSLog(@"============:%@",StringTemp);
    [MyResultStr appendString:StringTemp];
    _MyTextView.text=MyResultStr;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

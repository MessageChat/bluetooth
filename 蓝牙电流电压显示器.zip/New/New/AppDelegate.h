//
//  AppDelegate.h
//  New
//
//  Created by 陈双超 on 14/12/18.
//  Copyright (c) 2014年 陈双超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  BLEConnectVC.m
//  ADMBL
//
//  Created by 陈双超 on 14/12/7.
//  Copyright (c) 2014年 com.aidian. All rights reserved.
//

#import "BLEConnectVC.h"

@interface BLEConnectVC (){
    NSMutableArray *dataArray;
    UIBarButtonItem *AllButton;
}

@end

@implementation BLEConnectVC
@synthesize peripheralOpration;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"连接蓝牙";
   
    dataArray=[[NSMutableArray alloc] init];
    
    AllButton=[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"search"] style:UIBarButtonItemStylePlain target:self action:@selector(seachAction)];
    AllButton.tintColor=[UIColor blueColor];
    self.navigationItem.rightBarButtonItem = AllButton;
    self.cbCentralMgr = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(sendBLEData:) name:@"BLEDataNotification" object:nil];
}

-(void)seachAction{
    NSLog(@"搜索");
    for (int i=0; i<[dataArray count]; i++) {
        CBPeripheral * peripheral=[dataArray objectAtIndex:i];
        if (peripheral.state!=0) {
            [self.cbCentralMgr cancelPeripheralConnection:peripheral];
        }
    }
    
    self.cbCentralMgr.delegate=self;
    [self.cbCentralMgr stopScan];
    
    [dataArray removeAllObjects];
    NSDictionary * dic = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:NO],CBCentralManagerScanOptionAllowDuplicatesKey, nil];
    [self.cbCentralMgr scanForPeripheralsWithServices:nil options:dic];
}

-(void)sendBLEData:(NSNotification*) notification{
    if (peripheralOpration.state==2){
        //保留找到的特性6,实现跟定时器相关
        [self sendDatawithperipheral:self.peripheralOpration characteristic:TRANSFER_CHARACTERISTIC_UUID_F203 data:[[notification userInfo] objectForKey:@"tempData"] ];
        char strcommand1[2]={'A','T'};
        strcommand1[0] =0X0D;
        strcommand1[1] =0X0A;
        NSData *cmdData1 = [NSData dataWithBytes:strcommand1 length:2];
        [self sendDatawithperipheral:self.peripheralOpration characteristic:TRANSFER_CHARACTERISTIC_UUID_F203 data:cmdData1 ];
    }
}
//根据蓝牙对象和特性发送数据
-(void)sendDatawithperipheral:(CBPeripheral *)peripheral characteristic:(NSString*)characteristicStr data:(NSData*)data {
    NSLog(@"data:%@",data);
    for (CBCharacteristic *characteristic in [[peripheral.services objectAtIndex:1] characteristics]){
        //保留找到的特性6
        if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:characteristicStr]]){
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // Return the number of rows in the section.
    return dataArray.count;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]).state==2) {
       
    }else{
        int countConnected=0;
        for (int i=0; i<[dataArray count]; i++){
            CBPeripheral * peripheral = [dataArray objectAtIndex:i];
            if (peripheral.state!=0){
                countConnected++;
            }
        }
        peripheralOpration=(CBPeripheral*)[dataArray objectAtIndex:indexPath.row];
        [self.cbCentralMgr connectPeripheral:((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]) options:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBConnectPeripheralOptionNotifyOnDisconnectionKey]];
    }
    [self.bleTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellIdentifier = @"cell";
    UITableViewCell * cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    NSString *State=nil;
    if (((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]).state==0) {
        State=@"disconnected";
        cell.textLabel.textColor=[UIColor blackColor];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }else if (((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]).state==1){
        State=@"Connecting";
        cell.textLabel.textColor=[UIColor blackColor];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }else{
        State=@"Connected";
        cell.textLabel.textColor=[UIColor blueColor];
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%@  %@", ((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]).name ,State];
    cell.detailTextLabel.text = [((CBPeripheral*)[dataArray objectAtIndex:indexPath.row]).identifier UUIDString];
    return cell;
}

#pragma mark - Navigation
- (void)centralManagerDidUpdateState:(CBCentralManager *)central{
    switch (central.state) {
        case CBCentralManagerStateUnknown:
            [self addLog:@"State Resetting"];
            break;
        case CBCentralManagerStateUnsupported:
            [self addLog:@"State Unsupported"];
            break;
        case CBCentralManagerStateUnauthorized:
            [self addLog:@"State Unauthorized"];
            break;
        case CBCentralManagerStatePoweredOff:
            [self addLog:@"State PoweredOff"];
            break;
        case CBCentralManagerStatePoweredOn:
            [self addLog:@"State PoweredOn"];
            [self seachAction];
            break;
        case CBCentralManagerStateResetting:
            [self addLog:@"State Resetting"];
            break;
    }
}

-(void)addLog:(NSString*)log{
    NSLog(@"%@",log);
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI{
    [dataArray addObject:peripheral];
    [_bleTableView reloadData];
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    [_bleTableView reloadData];
    
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    
}
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(NSError *)error{
    
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    for (CBCharacteristic * characteristic in service.characteristics) {
        [peripheral setNotifyValue:YES forCharacteristic:characteristic];
    }
}

//peripheral:didUpdateValueForCharacteristic:error
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ChangePointerNotification" object:characteristic.value];
    NSString *str=[[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    NSLog(@"特性的值：%@",str);
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    NSLog(@"写数据委托完毕");
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    for (CBService* service in peripheral.services){
        [peripheral discoverCharacteristics:nil forService:service];
        [peripheral discoverIncludedServices:nil forService:service];
    }
}

@end

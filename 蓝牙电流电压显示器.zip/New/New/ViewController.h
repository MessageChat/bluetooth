//
//  ViewController.h
//  New
//
//  Created by 陈双超 on 14/12/18.
//  Copyright (c) 2014年 陈双超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *ImagePointerOne;
@property (weak, nonatomic) IBOutlet UIImageView *ImagePointerTwo;
@property (weak, nonatomic) IBOutlet UILabel *VoltLabel;
@property (weak, nonatomic) IBOutlet UILabel *AMPLabel;
@property (weak, nonatomic) IBOutlet UILabel *BottomLabel;
@property (weak, nonatomic) IBOutlet UIImageView *PanOneImageView;
@property (weak, nonatomic) IBOutlet UIView *BGVIew;
@property (weak, nonatomic) IBOutlet UIImageView *PanTwoImageView;


- (IBAction)ShowConnectionAction:(UIBarButtonItem *)sender;

@end


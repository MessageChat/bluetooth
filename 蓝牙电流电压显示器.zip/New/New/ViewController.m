//
//  ViewController.m
//  New
//
//  Created by 陈双超 on 14/12/18.
//  Copyright (c) 2014年 陈双超. All rights reserved.
//
#define IOS8_OR_LATER   ( [[[UIDevice currentDevice] systemVersion] compare:@"8.0"] != NSOrderedAscending )

#import "ViewController.h"
#import "BLEConnectVC.h"

@interface ViewController (){
    BLEConnectVC *bleConnectViewContrller;
    NSString *VoltString;
    NSString *AMPString;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
    bleConnectViewContrller=[[UIStoryboard storyboardWithName:@"Main" bundle:nil]  instantiateViewControllerWithIdentifier:@"bleConnectVC"];
    _ImagePointerOne.transform=CGAffineTransformMakeRotation(-3.1415926*122/180);
    _ImagePointerTwo.transform=CGAffineTransformMakeRotation(-3.1415926*122/180);
    [[NSNotificationCenter defaultCenter] addObserver: self selector:@selector(ChangePointer:) name:@"ChangePointerNotification" object:nil];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
    NSLog(@"self.view:%f,ImagePointerOne:%f,%f",self.view.frame.origin.y,[UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height);
    if(IOS8_OR_LATER){
        _VoltLabel.center=CGPointMake(_VoltLabel.center.x, (_PanOneImageView.frame.origin.y+_PanOneImageView.frame.size.height)*0.65) ;
        _AMPLabel.center=CGPointMake(_AMPLabel.center.x, _VoltLabel.center.y) ;
        if(_BGVIew.frame.size.height-52-_PanOneImageView.frame.size.height<_BottomLabel.frame.size.height){
            _BottomLabel.center=CGPointMake([UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height-78+_BottomLabel.frame.size.height/2);
        }else{
            _BottomLabel.center=CGPointMake([UIScreen mainScreen].bounds.size.width/2, (_BGVIew.frame.size.height-52+_PanOneImageView.frame.size.height)/2);
        }
        
    }else{
    }
    [self ChangeFontSize];
}

-(void)viewWillAppear:(BOOL)animated{
    [self ChangeFontSize];
}

-(void)ChangeFontSize{
    NSLog(@"_PanOneImageView.frame.size:%f,%f",_PanOneImageView.frame.size.width,_PanOneImageView.frame.size.height);
    if (_PanOneImageView.frame.size.height>450) {
        NSLog(@"设置大字体");
        _VoltLabel.font=[UIFont boldSystemFontOfSize:50];
        _AMPLabel.font=[UIFont boldSystemFontOfSize:50];
    }
}

-(void)ChangePointer:(NSNotification*)data{
    NSString *tmepStr=[NSString stringWithFormat:@"%@",data.object];
    if ([tmepStr length]!=17) {
        NSLog(@"数据长度不对");
        return;
    }
    
    NSString* tmepStr1=[tmepStr stringByReplacingOccurrencesOfString:@"a" withString:@"0"];
    tmepStr1=[tmepStr1 stringByReplacingOccurrencesOfString:@"A" withString:@"0"];
    VoltString=[NSString stringWithFormat:@"%@%@.%@",[tmepStr1 substringWithRange:NSMakeRange(4, 1)],[tmepStr1 substringWithRange:NSMakeRange(6, 1)],[tmepStr1 substringWithRange:NSMakeRange(8, 1)]];
    if ([[tmepStr substringWithRange:NSMakeRange(11, 1)] isEqualToString:@"A"]||[[tmepStr substringWithRange:NSMakeRange(11, 1)] isEqualToString:@"a"]) {
        AMPString=[NSString stringWithFormat:@"%@.%@",[tmepStr1 substringWithRange:NSMakeRange(13, 1)],[tmepStr1 substringWithRange:NSMakeRange(15, 1)]];
    }else{
        AMPString=[NSString stringWithFormat:@"%@%@.%@",[tmepStr1 substringWithRange:NSMakeRange(11, 1)],[tmepStr1 substringWithRange:NSMakeRange(13, 1)],[tmepStr1 substringWithRange:NSMakeRange(15, 1)]];
    }
    _ImagePointerOne.transform=CGAffineTransformMakeRotation(3.1415926/180*(([VoltString floatValue])/30*244-122));
    _ImagePointerTwo.transform=CGAffineTransformMakeRotation(3.1415926/180*([AMPString floatValue]/50*244-122));
    _VoltLabel.text=VoltString;
    _AMPLabel.text=AMPString;
    
    [self ChangeFontSize];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)SendMessage:(id)sender {
    char strcommand[8]={'1','2','3','4','5','6','7','8'};
    NSData *cmdData = [NSData dataWithBytes:strcommand length:8];
    NSDictionary *dic=[[NSDictionary alloc]initWithObjectsAndKeys:cmdData,@"tempData",nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BLEDataNotification" object:nil userInfo:dic];
}

- (IBAction)ShowConnectionAction:(UIBarButtonItem *)sender {
    [self.navigationController pushViewController:bleConnectViewContrller animated:YES];
}
@end

//
//  main.m
//  New
//
//  Created by 陈双超 on 14/12/18.
//  Copyright (c) 2014年 陈双超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
